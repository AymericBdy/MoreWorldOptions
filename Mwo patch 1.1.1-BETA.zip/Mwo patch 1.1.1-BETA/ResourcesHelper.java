package net.mystical.moreworldoptions.client.util;

import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.FileVisitResult;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import org.lwjgl.Sys;

import com.google.common.io.Files;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.Util;
import net.minecraft.world.storage.ISaveFormat;
import net.minecraft.world.storage.WorldInfo;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.mystical.moreworldoptions.client.gui.GuiSelectWorldWithOptions;
import net.mystical.moreworldoptions.mod.MoreWorldOptions;
import net.mystical.moreworldoptions.util.DataCollector;
import net.mystical.moreworldoptions.util.MwoUtil.ColorHelper;
import net.mystical.moreworldoptions.util.error.AdditionnalErrorInfo;
import net.mystical.moreworldoptions.util.error.ErrorsManager;

@SideOnly(Side.CLIENT)
public class ResourcesHelper implements Runnable
{
	public static Thread copyWorldThead;
	private static GuiSelectWorldWithOptions parent;
	private static String fileName;
	private static String copyFileName;
	private static boolean zipTheCopy;
	private static boolean deleteOld;
	
	private static int step;
	private static int stepNumber;
	
	private static int directoryStep;
	private static int directoryStepNumber;
	
	public static String s = System.getProperty("file.separator");
	public static File savesDir = FMLClientHandler.instance().getSavesDir();
	
	/**
	 * The processPID for the thread to run
	 * 
	 * 1 = for imgs
	 * 2 = for CopyWorld
	 */
	private int processPID = -1;
	
	private static DataCollector collector = new DataCollector("TRL_THREAD");
	
	/**
	 * @param PID
	 * 	The processPID for the thread to run <br />
	 * 	2 = for CopyWorld
	 */
	public ResourcesHelper(int PID)
	{
		this.processPID = PID;
	}

	@Override
	public void run() 
	{
		if(this.processPID == 2) //Copy button's (in list of world) action
		{
			collector.setName("World copier");
			collector.setFirst();
			copyWorld();
			collector.setEnd();
			
			//Liberate the memory
			parent = null;
			stepNumber = 0;
			step = 0;
			directoryStep = 0;
			directoryStepNumber = 0;
		}
		else
		{
			AdditionnalErrorInfo add = AdditionnalErrorInfo.createDefaultAddionnalInfo();
			ErrorsManager.thrownError("TRL_ILLEGAL_ACTION_PID", "TRL.run(), PID : " + this.processPID, add);
		}
	}
	
	/**
	 * Copy the save of an world <br />
	 * 
	 * Called by GuiSelectWorldEnergy
	 * @param parent_c The parent gui, for update progress status
	 * @param fileName_c The world name
	 * @param newWorldName_c The new world and folder name
	 * @param zipTheCopy_c Will zip the copy
	 * @param deleteOld_c Will delete the old file
	 */
	public static void launchWorldCopy(GuiSelectWorldWithOptions parent_c, String fileName_c, String newWorldName_c, boolean zipTheCopy_c, boolean deleteOld_c)
	{
		parent_c.setCopyStatus("PreparingCopy...");
		MoreWorldOptions.log.info("[TRL] Copying world : " + fileName_c);
		
		copyWorldThead = new Thread(new ResourcesHelper(2));
		parent = parent_c;
		fileName = fileName_c;
		copyFileName = newWorldName_c;
		zipTheCopy = zipTheCopy_c;
		deleteOld = deleteOld_c;
		
		copyWorldThead.setName("World_Copier");
		copyWorldThead.start();
	}
	
	private void copyWorld()
	{
		parent.setCopyStatus("Preparing...");

		File from = new File(savesDir, fileName);
		if(from.exists())
		{
			File dest = new File(savesDir, copyFileName + (zipTheCopy ? ".zip" : ""));
			try
			{
				ISaveFormat isaveformat = Minecraft.getMinecraft().getSaveLoader();
				if(!zipTheCopy)
				{
					copyDirectory(from, dest);
				
					parent.setCopyStatus("Renaming the world", ColorHelper.getRandomEnergyColor());
	                isaveformat.renameWorld(copyFileName, copyFileName);
				}
				else
				{
					boolean changed = !fileName.equals(copyFileName);
					String oldName = "";
					if(changed)
					{
						parent.setCopyStatus("Renaming the world for the copy", ColorHelper.getRandomEnergyColor());
						WorldInfo info = isaveformat.getWorldInfo(fileName);
						oldName = info.getWorldName();
						isaveformat.renameWorld(fileName, copyFileName);
					}
					parent.setCopyStatus("Zipping the world...", ColorHelper.TURQUOISEBLUE);
					zip(from, dest, true);
					if(changed && !deleteOld)
					{
						parent.setCopyStatus("Renaming the world to old name", ColorHelper.getRandomEnergyColor());
		                isaveformat.renameWorld(fileName, oldName);
					}
				}
				if(deleteOld)
				{
					isaveformat.flushCache();
					deleteFileOrDirectory(from);
				}
			}
			catch (Exception e) 
			{
				String status = parent.getCopyStatus();
		        parent.setCopyStatus("UnkownError, reloading worlds");
				parent.reloadWorlds();
		        parent.endLoading();
		        
		        parent.setCopyStatus("UnkownError occured, see the log", ColorHelper.RED);
		        
		        AdditionnalErrorInfo add = AdditionnalErrorInfo.createAddionnalInfo("Copying world, status when errored : " + status, e);
		        ErrorsManager.thrownError("RESS_LOAD&WORLD_COPY&PID2", "TemporaryRessourceLoader.copyWorld()", add);
		        return;
			}
		}
		else
		{
			MoreWorldOptions.log.err("[TRL] World " + fileName + " cannot be copied : not found in the saves directory");
	        parent.setCopyStatus("Error: World not found", ColorHelper.RED);
	        parent.endLoading();
	        return;
		}
		
		parent.setCopyStatus(I18n.format("gui.selectWorld.reloading"), ColorHelper.STEELGRAY);
		parent.showingZipsFiles = zipTheCopy;
		parent.reloadWorlds();
		
        MoreWorldOptions.log.info("[TRL] World copy finished : " + fileName);
		
        int cooldown = 20;
		while(parent.isLoading && --cooldown > 0)
		{
			try
			{
				copyWorldThead.sleep(500);
			} 
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}
        parent.setCopyStatus("Copy : Success", ColorHelper.GREEN);
        parent.setDefaultDisplayCooldown();
        
	}
	
	public static void copyDirectory(File src, File dest) throws IOException
	{
		copyDirectory(src, dest, false);
	}
	
	private static int copyDirectory(File src, File dest, boolean autoCalled) throws IOException
	{
		if(src.isDirectory()) //For an directory : gets all sub-directories and files
		{
			File dir;
			if(autoCalled)
			{
				dir = new File(dest, src.getName());
			}
			else
			{
				dir = dest;
			}
			dir.mkdir();
			
			File[] list = src.listFiles();
			if(list != null)
			{
				if(!autoCalled) stepNumber = list.length;
				directoryStepNumber = list.length;
				directoryStep = 0;
				for(File f : list)
				{
					copyDirectory(f, dir, true);
					if(!autoCalled)
						step++;
				}
			}
		}
		else
		{
			if(parent != null) parent.setCopyStatus("Copying : " + step + " / " + stepNumber + " (File progress : " + directoryStep + " / " + directoryStepNumber + ").");
			Files.copy(src, new File(dest, src.getName())); //For an unique file
			directoryStep++;
		}
		return 0;
	}
	
	public static void zip(File inputFile, File targetZippedFolder, boolean excludePrimaryFolderName)  throws IOException 
	{
        FileOutputStream fileOutputStream = new FileOutputStream(targetZippedFolder);
        ZipOutputStream zipOutputStream = new ZipOutputStream(fileOutputStream);
        
        if (inputFile.isFile()) zipFile(inputFile,"",zipOutputStream);
        else if (inputFile.isDirectory()) zipFolder(zipOutputStream,inputFile,"",excludePrimaryFolderName);

        zipOutputStream.close();
        fileOutputStream.close();
    }
	
    private static void zipFolder(ZipOutputStream zipOutputStream, File inputFolder, String parentName, boolean excludePrimaryFolderName)  throws IOException 
    {
        String myname = parentName + (!excludePrimaryFolderName ? inputFolder.getName() : "") +"\\";
        ZipEntry folderZipEntry = new ZipEntry(myname);
        zipOutputStream.putNextEntry(folderZipEntry);
        
        for (File f : inputFolder.listFiles())
        {
            if (f.isFile()) zipFile(f,myname,zipOutputStream);
            else if(f.isDirectory()) zipFolder(zipOutputStream,f,myname,false);
        }
        
        zipOutputStream.closeEntry();
    }

    private static void zipFile(File inputFile, String parentName, ZipOutputStream zipOutputStream) throws IOException
    {
        ZipEntry zipEntry = new ZipEntry(parentName+inputFile.getName());
        zipOutputStream.putNextEntry(zipEntry);

        FileInputStream fileInputStream = new FileInputStream(inputFile);
        byte[] buf = new byte[1024];
        int bytesRead;
        
        while ((bytesRead = fileInputStream.read(buf)) > 0) 
        {
            zipOutputStream.write(buf, 0, bytesRead);
        }
        
        zipOutputStream.closeEntry();
        fileInputStream.close();
    }

	
	public static void dezipFile(ZipFile from, File to) throws IOException
	{
		Enumeration enumm = from.entries();
		while(enumm.hasMoreElements())
		{
			ZipEntry zip = (ZipEntry) enumm.nextElement();
			//MoreWorldOptions.log.info("For entry : " + zip.getName());
			dezipZipEntry(from, zip, to, true);
		}
	}
	
	public static void dezipZipEntry(ZipFile owner, ZipEntry entry, File to, boolean keepHierarchy) throws IOException
	{
		byte[] buffer = new byte[1024];
		String name = entry.getName();
		String n = keepHierarchy ? name : name.substring(name.lastIndexOf("/"));
		File dest = new File(to, n);
		if(entry.isDirectory() || name.endsWith(s))//Is directory is returning false for unknow reason
		{
			dest.mkdirs();
		}
		else
		{
			InputStream in = owner.getInputStream(entry);
			FileOutputStream out = new FileOutputStream(dest);
			int read;
			while ((read = in.read(buffer)) > 0)
			{
				out.write(buffer, 0, read);
			}
			in.close();
			out.close();
		}
	}
	
	/**
	 * Deletes - a file, - a directory, - a zip
	 * 
	 * @param file
	 * @throws IOException
	 */
	public static void deleteFileOrDirectory(File file) throws IOException
	{
		java.nio.file.Files.walkFileTree(file.toPath(), new SimpleFileVisitor<Path>() 
		{
	         @Override
	         public FileVisitResult visitFile(Path file2, BasicFileAttributes attrs) throws IOException
	         {
	        	 java.nio.file.Files.delete(file2);
	             return FileVisitResult.CONTINUE;
	         }
	         @Override
	         public FileVisitResult postVisitDirectory(Path dir, IOException e) throws IOException
	         {
	             if (e == null) 
	             {
	            	 java.nio.file.Files.delete(dir);
	                 return FileVisitResult.CONTINUE;
	             }
	             else throw e;// directory iteration failed
	         }
	    });
	}
	
	/**
	 * Deletes - a file, - a directory, - a zip
	 * 
	 * @param file
	 * @throws IOException
	 */
	public static void deleteJarOnExit(File file) throws IOException
	{
		String s = file.getAbsolutePath();
        if (Util.getOSType() == Util.EnumOS.OSX)
        {
            try
            {
                MoreWorldOptions.log.info("Erasing dir on OSX : " + s);
                Runtime.getRuntime().exec(new String[] {"/usr/bin/erase", s}); //TODO delete or erase ?
                return;
            }
            catch (IOException e)
            {
            	MoreWorldOptions.log.err("Couldn\'t delete file on Mac OSX : " + e);
            }
        }
        else if (Util.getOSType() == Util.EnumOS.WINDOWS)
        {
            String s1 = String.format("cmd.exe /C start del /F /S /Q \"%s\"", new Object[] {s});
            MoreWorldOptions.log.info(s1);
            try
            {
                Runtime.getRuntime().exec(s1);
                return;
            }
            catch (IOException e)
            {
            	MoreWorldOptions.log.err("Couldn\'t delete file on Windows : " + e);
            }
        }
        /*
        try
        {
        	if(Desktop.isDesktopSupported())
        	{
        		Desktop.getDesktop().browse(ResourcesHelper.savesDir.toURI());
        	}
        	else
        	{
        		MoreWorldOptions.log.err("Couldn\'t open link via desktop : " + "Desktop isn't supported !");
            	MoreWorldOptions.log.info("Opening via system class!");
                Sys.openURL("file://" + s);
        	}
        }
        catch (IOException e)
        {
        	MoreWorldOptions.log.err("Couldn\'t open link via desktop : " + e);
        	MoreWorldOptions.log.info("Opening via system class!");
            Sys.openURL("file://" + s);
        }
        */
		/*
		JarFile file2 = new JarFile(file);
		Enumeration<JarEntry> en = file2.entries();
		while(en.hasMoreElements())
		{
			JarEntry entr = en.nextElement();
			File f = new File(file, entr.getName());
			MoreWorldOptions.log.info(f + " as " + entr.getName());
			f = new File(ResourcesHelper.class.getResource(entr.getName().substring(entr.getName().lastIndexOf("/"))).getFile());
			MoreWorldOptions.log.info(f + " as " + entr.getName());
			java.nio.file.Files.delete(f.toPath());
		}
		file2.close();
		/*
		MoreWorldOptions.log.info(file.isDirectory());
		final List<File> toDelete = new ArrayList<File>();
		java.nio.file.Files.walkFileTree(file.toPath(), new SimpleFileVisitor<Path>() 
		{
	         @Override
	         public FileVisitResult visitFile(Path file2, BasicFileAttributes attrs) throws IOException
	         {
	        	 MoreWorldOptions.log.info("File : " + file2);
	        	 toDelete.add(file2.toFile());
	             return FileVisitResult.CONTINUE;
	         }
	         @Override
	         public FileVisitResult postVisitDirectory(Path dir, IOException e) throws IOException
	         {
	             if (e == null) 
	             {
	            	 toDelete.add(dir.toFile());
	                 return FileVisitResult.CONTINUE;
	             }
	             else throw e;// directory iteration failed
	         }
	    });
		java.util.Collections.reverse(toDelete);
		for(File file1 : toDelete)
		{
			MoreWorldOptions.log.info(file1);
			file1.deleteOnExit();
		}
		*/
		FMLCommonHandler.instance().handleExit(0);
	}
	
	public static long calculateDirectoryLength(File file) throws IOException
	{
		if(!file.isDirectory()) return file.length();
		SizeFileVisitor visit;
		java.nio.file.Files.walkFileTree(file.toPath(), visit = new SizeFileVisitor());
		return visit.size;
	}
	
	public static class SizeFileVisitor extends SimpleFileVisitor<Path>
	{
		private long size = 0L;
		
        @Override
        public FileVisitResult visitFile(Path file2, BasicFileAttributes attrs) throws IOException
        {
       	 	File file = file2.toFile();
       	 	if(!file.isDirectory()) size += file.length();
       	 	return FileVisitResult.CONTINUE;
        }
        @Override
        public FileVisitResult postVisitDirectory(Path dir, IOException e) throws IOException
        {
            if (e == null) 
            {
                return FileVisitResult.CONTINUE;
            }
            else throw e;// directory iteration failed
        }
	}
}
