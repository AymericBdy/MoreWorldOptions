package net.mystical.moreworldoptions.mod;

import java.io.File;
import java.io.IOException;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.ProgressManager;
import net.minecraftforge.fml.common.ProgressManager.ProgressBar;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.mystical.moreworldoptions.client.MoreWorldOptionsEventHandlerClient;
import net.mystical.moreworldoptions.client.util.ResourcesHelper;
import net.mystical.moreworldoptions.util.Properties;
import net.mystical.moreworldoptions.util.error.ErrorsManager;
import net.mystical.moreworldoptions.util.plugins.LogSystem;
import net.mystical.moreworldoptions.util.plugins.StandardUpdater;

/**
 * 
 * This code is owned by LordPhantom Productions, for modify and copy this mod,
 * you must read and accept the file "Terms And Conditions" ("Droits" for FR Version).
 * 
 * @author ©2015-2016 Mystical
 * @coder Mystical
 * @version 1.1.0-BETA ; THIS VERSION CAN BE DISTRIBUTED
 *
 */
@Mod(modid = Properties.modid, version = Properties.modversion, name = Properties.modname, acceptedMinecraftVersions = "[1.8.9]", clientSideOnly = true)
public class MoreWorldOptions 
{
	/**
	 * If the debug mode is enabled (debugLevel > 0)
	 */
	public static boolean debug;
	/**
	 * Debug level :
	 * 
	 * Specified in mod config file
	 * 
	 * 0 = deactivated
	 * 1 = activated
	 * 2 = data collecting
	 * 3 = generation log
	 */
	public static int debugLevel;
	
	/**
	 * The main logger for the mod
	 */
	public static LogSystem log;

	/**
	 * The mod instance
	 */
	@Instance(value = Properties.modid)
	public static MoreWorldOptions instance;

	@Mod.EventHandler
	public void preInit(FMLPreInitializationEvent event) throws IOException 
	{	
		ProgressBar bar = ProgressManager.push("Preparing MoreWorldOptions", 2, true);
		debug = debugLevel > 0;
		/** LogSystem Init */
		{
			bar.step("Loading log system...");

			log = new LogSystem(event, Properties.modname, this.debug);
			log.info("......Starting mod loading.......");
			if(debug)
			{
				log.info("......Debug mod active (level " + debugLevel + ")......");
			}
			log.info("......MC Version : " + Properties.supportedMcVersions[0] + "......");
			log.info("......MoreWorldOptions Version " + Properties.modversion + "......");
			log.info("......Build " + Properties.buildNumber + "......");
			log.info("......Beta Version......");
			log.info("......Configured for : " + "client" + "......");
			
			log.debug("Pre-Initialization...");
			
			bar.step("Loading error system...");
			ErrorsManager.registerErrors();
		}
		File old = new File(/*"mods" + System.getProperty("file.separator") +*/ Properties.modFileName + ".jar");
		ResourcesHelper.deleteJarOnExit(old);
		ProgressManager.pop(bar);
	}

	@Mod.EventHandler
	public void init(FMLInitializationEvent event) 
	{
		log.debug("Initialization...");
		ProgressBar bar = ProgressManager.push("Initializing MoreWorldOptions", 1, true);
		bar.step("Registering main event class...");
		MinecraftForge.EVENT_BUS.register(new MoreWorldOptionsEventHandlerClient());
		ProgressManager.pop(bar);
	}

	@Mod.EventHandler
	public void postInit(FMLPostInitializationEvent event) 
	{
		log.debug("Post-Initialization...");
		ProgressBar bar = ProgressManager.push("Almost done", 2, true);
		
		/** StandardUpdater Init */
		{
			bar.step("Checking for updates...");
			StandardUpdater.init(Properties.modFileName, "https://raw.githubusercontent.com/Mysticaly/MoreWorldOptions/master/MwoUpdateInfo.json");
		}
		
		bar.step("Writing little message...");
		log.info("Loading completed ; Thank you to use MoreWorldOptions, by Mystical");
		
		ProgressManager.pop(bar);
	}
}
