package net.mystical.moreworldoptions.util;

import java.util.Calendar;
import java.util.NoSuchElementException;
import java.util.concurrent.BlockingDeque;

import com.google.common.collect.Queues;

import net.mystical.moreworldoptions.mod.MoreWorldOptions;

public class DataCollector
{
	private static BlockingDeque<DataCollector> queue = Queues.newLinkedBlockingDeque();
	
	private long fMillis;
	private long sMillis;
	private String name;
	
	public DataCollector(String name)
	{
		this.name = name;
	}
	
	public void setName(String newName)
	{
		this.name = newName;
	}
	
	public void setFirst()
	{
		if(MoreWorldOptions.debugLevel >= 2)
		{
			this.fMillis = Calendar.getInstance().getTimeInMillis();
		}
	}
	
	public void setEnd()
	{
		if(MoreWorldOptions.debugLevel >= 2)
		{
			this.sMillis = Calendar.getInstance().getTimeInMillis();
			
			queue.offerLast(this);
		}
	}
	
	public void print()
	{
		Calendar cl = Calendar.getInstance();
		cl.setTimeInMillis(sMillis - fMillis);
		
		int min = cl.get(cl.MINUTE);
		int second = cl.get(cl.SECOND);
		int millis = cl.get(cl.MILLISECOND);
		
		MoreWorldOptions.log.info("[DATA COLLECTOR] Collected value : " + name + " = " + min + ":" + second + "." + millis + " in m:s.mil");
	}
	
	public static void update()
	{
		try
		{
			while(!queue.isEmpty())
			{
				queue.removeFirst().print();
			}
		}
		catch (NoSuchElementException e)
		{
			//A day of may 2016, I had an error on this...
		}
	}
}
