package net.mystical.moreworldoptions.util.error;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.inventory.IInventory;
import net.minecraft.server.MinecraftServer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;
import net.mystical.moreworldoptions.mod.MoreWorldOptions;
import net.mystical.moreworldoptions.util.error.Error.ReportBuilder;
import net.mystical.moreworldoptions.util.plugins.LogSystem;

public class AdditionnalErrorInfo 
{
	private World world;
	private BlockPos pos;
	private Throwable e;
	
	private boolean cancelCrash;
	private boolean forceCrash;
	
	private Object objBeingUpdated;
	
	private AdditionnalErrorInfo(World world, BlockPos pos, Object objBeingTicked, boolean cancelCrash, boolean forceCrash, Throwable e)
	{
		this.world = world;
		this.pos = pos;
		this.objBeingUpdated = objBeingTicked;
		this.cancelCrash = cancelCrash;
		this.forceCrash = forceCrash;
		this.e = e;
		
		if(this.e == null)
		{
			this.e = new Throwable();
		}
	}
	
	/**
	 * @return New error info with no details
	 */
	public static AdditionnalErrorInfo createDefaultAddionnalInfo()
	{
		return new AdditionnalErrorInfo(null, null, null, false, false, null);
	}
	
	/**
	 * @param e The exception has occurred
	 * 
	 * @return New error info with no details except the exception
	 */
	public static AdditionnalErrorInfo createAddionnalInfo(Exception e)
	{
		return new AdditionnalErrorInfo(null, null, null, false, false, e);
	}
	
	/**
	 * @param objBeingTicked Can be an block, an tile entity, an entity, an string, the system will automatically say all he know about it
	 * @param e The exception has occurred
	 * 
	 * @return New error info with no details except the exception and the objBeingTicked
	 */
	public static AdditionnalErrorInfo createAddionnalInfo(Object objBeingTicked, Throwable e)
	{
		return new AdditionnalErrorInfo(null, null, objBeingTicked, false, false, e);
	}
	
	/**
	 * @param world The world of the error, or null
	 * @param pos The pos of the error, or null
	 * @param objBeingTicked Can be an block, an tile entity, an entity, an string, the system will automatically say all he know about it
	 * 
	 * @return New error info with all world details and the objBeingTicked
	 */
	public static AdditionnalErrorInfo createAddionnalInfo(World world, BlockPos pos, Object objBeingTicked)
	{
		return new AdditionnalErrorInfo(world, pos, objBeingTicked, false, false, null);
	}
	
	/**
	 * @param world The world of the error, or null
	 * @param pos The pos of the error, or null
	 * @param objBeingTicked Can be an block, an tile entity, an entity, an string, the system will automatically say all he know about it
	 * @param e The exception has occurred
	 * 
	 * @return New error info with all world details, the objBeingTicked and the exception
	 */
	public static AdditionnalErrorInfo createAddionnalInfo(World world, BlockPos pos, Object objBeingTicked, Throwable e)
	{
		return new AdditionnalErrorInfo(world, pos, objBeingTicked, false, false, e);
	}
	
	public AdditionnalErrorInfo setCancelCrash()
	{
		this.cancelCrash = true;
		return this;
	}
	
	public AdditionnalErrorInfo setForceCrash()
	{
		this.forceCrash = true;
		return this;
	}
	
	public ErrorAction.CrashCode getCrashCode(ErrorAction.CrashCode original)
	{
		if(this.cancelCrash)
		{
			original = ErrorAction.CrashCode.NO;
		}
		if(this.forceCrash)
		{
			original = ErrorAction.CrashCode.ALL;
		}
		return original;
	}
	
	public AdditionnalErrorInfo removeStackTrace()
	{
		if(e != null)
		{
			e.setStackTrace(new StackTraceElement[0]);
		}
		return this;
	}
	
	public Throwable getException()
	{
		return this.e;
	}
	
	public String getAdditionnalInfo()
	{
		ReportBuilder err = new ReportBuilder();
		
		if(world == null && pos == null && objBeingUpdated == null)
		{
			return "No additionnal info for this error";
		}
		
		if(world != null)
		{
			err.line("Current world : " + world.getWorldInfo().getWorldName());
			err.line("Current dimension : " + world.provider.getDimensionName() + " ; id : " + world.provider.getDimensionId());
		}
		
		if(pos != null)
		{
			err.line("Current postition : " + LogSystem.formatPosition(pos));
			
			if(world != null)
			{
				err.line("Block at this pos : " + world.getBlockState(pos).getBlock());
				err.line("Block (state) at this pos : " + world.getBlockState(pos));
				
				err.line("TileEntity at this pos : " + world.getTileEntity(pos));
			}
		}
		
		if(objBeingUpdated != null)
		{
			if(objBeingUpdated instanceof String)
			{
				err.line("Know error information : " + objBeingUpdated);
			}
			/*else if(objBeingUpdated instanceof BlockBase)
			{
				err.line("Block being ticked (this block is from MoreWorldOptions) : " + objBeingUpdated);
			}*/
			else if(objBeingUpdated instanceof Block)
			{
				err.line("Block being ticked : " + objBeingUpdated);
			}
			/*else if(objBeingUpdated instanceof IPipes)
			{
				err.line("It's an error with the power system. Pipe being ticked : " + objBeingUpdated);
			}
			else if(objBeingUpdated instanceof IInventory && objBeingUpdated instanceof TileEntityBase)
			{
				err.line("TileEntity being ticked (this tile entity is from MoreWorldOptions) : " + objBeingUpdated);
				err.line("Inventory name : " + ((IInventory)objBeingUpdated).getDisplayName().getUnformattedText());
			}
			else if(objBeingUpdated instanceof TileEntityBase)
			{
				err.line("TileEntity being ticked (this tile entity is from MoreWorldOptions) : " + objBeingUpdated);
			}*/
			else if(objBeingUpdated instanceof IInventory)
			{
				err.line("TileEntity being ticked : " + objBeingUpdated);
			}
			else if(objBeingUpdated instanceof TileEntity)
			{
				err.line("TileEntity being ticked : " + objBeingUpdated);
			}
			else if(objBeingUpdated instanceof Entity)
			{
				err.line("Entity being ticked : " + objBeingUpdated);
				err.line("Entity name : " + ((Entity)objBeingUpdated).getDisplayName().getUnformattedText());
			}
			/*else if(objBeingUpdated instanceof Basepacket)
			{
				err.line("Packet who created this error : " + ((Basepacket)objBeingUpdated).getIdentifier());
			}
			else if(objBeingUpdated instanceof StructurePartGenerator)
			{
				err.line("It's an error while generating an structure part, know info : " + ((StructurePartGenerator)objBeingUpdated).getPartInfo());
			}*/
			else
			{
				err.line("Unkown objBeingTicked : " + objBeingUpdated.toString());
			}
		}
		err.line("Displayed gui : " + Minecraft.getMinecraft().currentScreen);
		
		return err.toString();
	}
	
	public void removeAllErroredIfPossible()
	{
		MoreWorldOptions.log.info("Removing all potential errored blocks, tile entities and entities..");
		if(world == null)
		{
			world = Minecraft.getMinecraft().theWorld;
		}
		
		try 
		{
			if(world != null)
			{
				if(pos != null)
				{
					world.setBlockToAir(pos);
					world.removeTileEntity(pos);
					
					if(objBeingUpdated != null && objBeingUpdated instanceof Entity)
					{
						((Entity) objBeingUpdated).setDead();
						world.removeEntity((Entity) objBeingUpdated);
					}
				}
			}
		}
		catch (Exception e) 
		{
			MoreWorldOptions.log.fatal("Another error occured while removing all potential errored blocks, tile entities and entities from the current world (" + e.getMessage() + ") : ");
			e.printStackTrace();
		}
	}
}
