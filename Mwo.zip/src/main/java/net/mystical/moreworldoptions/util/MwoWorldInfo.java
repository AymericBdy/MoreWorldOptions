package net.mystical.moreworldoptions.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.resources.ResourcePackRepository.Entry;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.EnumChatFormatting;
import net.minecraftforge.common.ForgeVersion;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.common.ModContainer;
import net.mystical.moreworldoptions.client.gui.GuiSelectWorldWithOptions;
import net.mystical.moreworldoptions.client.util.ResourcesHelper;
import net.mystical.moreworldoptions.client.util.SaveFormatHelper;
import net.mystical.moreworldoptions.client.util.TexturesHelper;
import net.mystical.moreworldoptions.mod.MoreWorldOptions;
import net.mystical.moreworldoptions.util.error.AdditionnalErrorInfo;
import net.mystical.moreworldoptions.util.error.ErrorsManager;

public class MwoWorldInfo implements Comparable<MwoWorldInfo>
{
	public static final int currentSaveFormatVersion = 1; 
	
    /** the file name of this save (used by the comparator) */
    public final String fileName;
    private final long lastTimePlayed;
    
	private String mcVersion;
	private String forgeVersion;

	private final Map<String, String> modIdToVersion = new HashMap();
	
	private String description = "";
	private final List<Entry> usedResourcePacks = new ArrayList();
	
	private boolean ignoreVersionAdvertisment = false;
	
	private MwoWorldInfo(String fileName, long lastTimePlayed)
	{
		this.fileName = fileName;
		this.lastTimePlayed = lastTimePlayed;
	}
	
	public static MwoWorldInfo createForNewWorld(String fileName)
	{
		MwoWorldInfo inf = new MwoWorldInfo(fileName, 0L);
		inf.setDataToCurrentMcConfig();
		return inf;
	}
	
	public void setDataToCurrentMcConfig()
	{
		mcVersion = Loader.MC_VERSION;
		forgeVersion = ForgeVersion.getVersion();
		modIdToVersion.clear();
		List<ModContainer> mods = Loader.instance().getActiveModList();
		for(ModContainer mod : mods)
		{
			modIdToVersion.put(mod.getModId(), mod.getVersion());
		}
	}
	
	public static MwoWorldInfo createForExistingWorld(String fileName, long lastTimePlayed)
	{
		MwoWorldInfo inf = new MwoWorldInfo(fileName, lastTimePlayed);
		inf.mcVersion = "Unknown";
		inf.forgeVersion = "Unknown";
		return inf;
	}
	
	public static MwoWorldInfo createAndLoadFromNBT(NBTTagCompound tag, String fileName, long lastTimePlayed)
	{
		MwoWorldInfo inf = new MwoWorldInfo(fileName, lastTimePlayed);
		if(!tag.hasKey("SaveFormatVersion")) return null;
		
		int version = tag.getInteger("SaveFormatVersion");
		if(version != currentSaveFormatVersion) return null;
		
		inf.mcVersion = tag.getString("CreatedInVersionOfMinecraft");
		inf.forgeVersion = tag.getString("CreatedInForgeVersion");
		
		inf.description = tag.getString("MapDescription");
		inf.ignoreVersionAdvertisment = tag.getBoolean("IgnoreVersionChangedAdvertisment");
		
		NBTTagList mods = tag.getTagList("ModsList", 10);
		for(int i = 0 ; i < mods.tagCount() ; i++)
		{
			NBTTagCompound mod = mods.getCompoundTagAt(i);
			inf.modIdToVersion.put(mod.getString("ModId"), mod.getString("ModVersion"));
		}
		
		if(tag.hasKey("ResourcePacks", 9))
		{
			List<String> packs = new ArrayList<String>();
			NBTTagList pcks = tag.getTagList("ResourcePacks", 10);
			for(int i = 0 ; i < pcks.tagCount() ; i++)
			{
				NBTTagCompound pck = pcks.getCompoundTagAt(i);
				packs.add(pck.getString("PackName"));
			}
			Minecraft.getMinecraft().getResourcePackRepository().updateRepositoryEntriesAll();
			List<Entry> mcPacks = Minecraft.getMinecraft().getResourcePackRepository().getRepositoryEntriesAll();
			for(Entry entr : mcPacks)
			{
				if(packs.contains(entr.getResourcePack().getPackName()))
				{
					inf.usedResourcePacks.add(entr);
				}
			}
		}
		
		return inf;
	}
	
	public void writeToNBT(NBTTagCompound tag)
	{
		tag.setString("CreatedInVersionOfMinecraft", mcVersion);
		tag.setString("CreatedInForgeVersion", forgeVersion);
		
		tag.setString("MapDescription", description);
		tag.setBoolean("IgnoreVersionAdv", ignoreVersionAdvertisment);
		
		NBTTagList mods = new NBTTagList();
		Iterator<String> it = modIdToVersion.keySet().iterator();
		while(it.hasNext())
		{
			String modId = it.next();
			String modversion = modIdToVersion.get(modId);
			NBTTagCompound mod = new NBTTagCompound();
			mod.setString("ModId", modId);
			mod.setString("ModVersion", modversion);
			mods.appendTag(mod);
		}
		tag.setTag("ModsList", mods);
		
		NBTTagList packs = new NBTTagList();
		for(Entry pack : usedResourcePacks)
		{
			NBTTagCompound pck = new NBTTagCompound();
			pck.setString("PackName", pack.getResourcePackName());
			packs.appendTag(pck);
		}
		tag.setTag("ResourcePacks", packs);
		
		tag.setInteger("SaveFormatVersion", currentSaveFormatVersion);
	}

	public String getMcVersion()
	{
		return mcVersion;
	}
	
	public void setMcVersion(String nw)
	{
		mcVersion = nw;
	}
	
	public boolean isMcVersionKnow()
	{
		return !MwoUtil.isStringEmpty(mcVersion) && !mcVersion.equalsIgnoreCase("Unknown");
	}
	
	public String getColoredMcVersionComparedToCurrent()
	{
		if(!isMcVersionKnow()) return EnumChatFormatting.RED + "Unknown Minecraft version" + EnumChatFormatting.RESET;
		String[] current = Loader.MC_VERSION.split("\\.");
		String[] result = mcVersion.split("\\.");
		
		EnumChatFormatting parentState = null;
		int cur;
		int res;
		for(int i = 0 ; i < 3 ; i++)
		{
			cur = Integer.valueOf(current[i]);
			res = Integer.valueOf(result[i]);
			if(parentState != null)
			{
				result[i] = "" + parentState + res + EnumChatFormatting.RESET;
			}
			else if(cur == res)
			{}
			else if(cur < res)
			{
				parentState = EnumChatFormatting.DARK_RED;
				result[i] = "" + parentState + res + EnumChatFormatting.RESET;
			}
			else
			{
				parentState = EnumChatFormatting.GOLD;
				result[i] = "" + parentState + res + EnumChatFormatting.RESET;
			}
		}
		
		return result[0] + "." + result[1] + "." + result[2];
	}
	
	/**
	 * @return 0 = no change, -2 = unknown save version, -1 down-grade, 1 = little upgrade (corrective change), 2 = big upgrade (corrective isn't count)
	 */
	public int compareMcVersionToCurrent()
	{
		if(!isMcVersionKnow()) return -2;
		String[] current = Loader.MC_VERSION.split("\\.");
		String[] result = mcVersion.split("\\.");
		
		int cur;
		int res;
		for(int i = 0 ; i < 3 ; i++)
		{
			cur = Integer.valueOf(current[i]);
			res = Integer.valueOf(result[i]);
			if(cur == res) continue;
			if(cur < res) return -1;
			else if(i == 2) return 1;
			else return 2;
		}
		return 0;
	}
	
	public List<ModInformation> getLostAndNewMods()
	{
		List<ModInformation> map = new ArrayList<MwoWorldInfo.ModInformation>();
		List<ModContainer> list = Loader.instance().getModList();
		Map<String, ModContainer> otherMods = new HashMap<String, ModContainer>();
		for(ModContainer mod : list)
		{
			String id = mod.getModId();
			String name = mod.getName();
			String version = mod.getVersion();
			if(!modIdToVersion.containsKey(id))
			{
				map.add(new ModInformation(1, null, null, mod));
				continue;
			}
			otherMods.put(id, mod);
			String saveVersion = modIdToVersion.get(id);
			if(!version.equals(saveVersion))  map.add(new ModInformation(0, id, saveVersion, mod));
		}
		for(String saveId : modIdToVersion.keySet())
		{
			if(!otherMods.containsKey(saveId))
			{
				map.add(new ModInformation(-1, saveId, modIdToVersion.get(saveId), null));
			}
		}
		return map;
	}
	
	public List<Entry> getResourcePacks()
	{
		return usedResourcePacks;
	}
	
	public boolean arePacksDifferentsWithMc(Minecraft mc)
	{
		return TexturesHelper.arePacksDifferentsWithMcPacks(usedResourcePacks, mc);
	}
	
	public void loadResourcesPacks(Minecraft mc)
	{
		try
		{
			TexturesHelper.loadResourcePacks(usedResourcePacks, mc);
			this.save(mc);
		}
		catch (IOException e)
		{
			AdditionnalErrorInfo add = AdditionnalErrorInfo.createAddionnalInfo("Used packs : " + usedResourcePacks, e);
	        ErrorsManager.thrownError("PACK_LOAD&UNK_ERROR", "MwoWorldInfo.loadResourcePacks(), first catch", add);
			try
			{
				mc.loadingScreen.displayLoadingString("An error occured loading a pack, loading default packs");
				usedResourcePacks.clear();
				usedResourcePacks.addAll(mc.getResourcePackRepository().getRepositoryEntries());
				TexturesHelper.loadResourcePacks(usedResourcePacks, mc);
			}
			catch (IOException e1)
			{
				AdditionnalErrorInfo add2 = AdditionnalErrorInfo.createAddionnalInfo("Used packs : " + usedResourcePacks, e1);
		        ErrorsManager.thrownError("PACK_LOAD&UNK_ERROR", "MwoWorldInfo.loadResourcePacks(), second catch", add2);
			}
		}
	}
	
	public void setDescription(String descr)
	{
		this.description = descr;
	}
	
	public String getDescription()
	{
		return this.description;
	}
	
	public void save(Minecraft mc)
	{
    	try
		{
			SaveFormatHelper.saveMwoWorldInfoTo(this, ResourcesHelper.savesDir, mc.getSaveLoader(), fileName);
			throw new FileNotFoundException();
		}
    	catch (IOException e)
		{
			AdditionnalErrorInfo add = AdditionnalErrorInfo.createAddionnalInfo("File name : " + fileName, e);
	        ErrorsManager.thrownError("MWO&WORLD_INFO&SAVE_ERROR", "MwoWorldInfo.save()", add);
		}
	}
	
	@Override
	public int compareTo(MwoWorldInfo other)
	{
		return this.lastTimePlayed < other.lastTimePlayed ? 1 : (this.lastTimePlayed > other.lastTimePlayed ? -1 : this.fileName.compareTo(other.fileName));
	}
	
	public static class ModInformation
	{
		private final String modIdTr = I18n.format("expression.mod.id") + ": ";//Do not put static, it will not be reload when the language changes !
		private final String modNameTr = I18n.format("expression.mod.name") + ": ";//Do not put static, it will not be reload when the language changes !
		private final String saveVersionTr = ", " + I18n.format("expression.mod.saveVersion") + " ";//Do not put static, it will not be reload when the language changes !
		private final String currentVersionTr = ", " + I18n.format("expression.mod.currentVersion") + " ";//Do not put static, it will not be reload when the language changes !
		
		/** -1 = lost, 0 = version changed, 1 = new */
		public final int status;
		
		public final String saveModId;
		public final String saveVersion;
		
		public final ModContainer loadedMod;
		
		public ModInformation(int status, String saveModId, String saveVersion, ModContainer loadedMod)
		{
			this.status = status;
			this.saveModId = saveModId;
			this.saveVersion = saveVersion;
			this.loadedMod = loadedMod;
		}
		
		@Override
		public String toString()
		{
			if(status == -1)
			{
				return modIdTr + saveModId + saveVersionTr + saveVersion;
			}
			else if(status == 0)
			{
				return modNameTr + loadedMod.getName() + ", " + modIdTr + loadedMod.getModId() + saveVersionTr + saveVersion + currentVersionTr + loadedMod.getVersion();
			}
			else if(status == 1)
			{
				return modNameTr + loadedMod.getName() + ", " + modIdTr + loadedMod.getModId() + currentVersionTr + loadedMod.getVersion();
			}
			return super.toString();
		}
	}
}
