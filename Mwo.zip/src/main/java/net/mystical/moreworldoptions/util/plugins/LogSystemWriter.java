package net.mystical.moreworldoptions.util.plugins;

import java.io.File;
import java.io.FileWriter;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.google.common.collect.Queues;

import net.mystical.moreworldoptions.util.error.ErrorsManager;

/**
 * This is an interface for log-writing : this write in other thread for no long ticks when have lot of things to write
 * This system is thread-safe
 * 
 * @author LordPhantom
 * @since LogSystem V0.8
 */
public class LogSystemWriter 
{
	/** The name of the logger */
	private String name;
	
	/** The file where it will write the text */
	private File file;
	
	/** The run status of the writer 3 = not yet started, 2 = running, 1 = waiting to stop, 0 = stopped */
	private int isRun = 3;
	
	/** All things to be written */
	private BlockingDeque<String> queue = Queues.newLinkedBlockingDeque();
	
	/** The writer thread instance */
	private Future ticker;
	
	/**
	 * @param name The name of the logger
	 */
	public LogSystemWriter(String name)
	{
		this.name = name;
		this.file = new File("logs" + File.separator + name + "-log.txt");
	}
	
	/**
	 * Adds an message to the message queue
	 * 
	 * @param message The message
	 */
	public synchronized void enqueue(String message)
	{
		message = LogSystem.getDatePrefix() + LogSystem.getThreadPrefix() + message;
		queue.offerLast(message);
		
		if(this.isStopped()) // New ticker instance needed
		{
			isRun = 2;
			
			ExecutorService ex = Executors.newSingleThreadExecutor();
			ticker = ex.submit(new Ticker(this));
			ex.shutdown();
		}
	}
	
	/**
	 * Stops the writer thread, used when the game crashes
	 */
	public void stopTickerThread()
	{
		this.isRun = 1;
	}
	
	/**
	 * @return True if the writer thread isn't running
	 */
	public boolean isStopped()
	{
		if(isRun != 2 || ticker == null)
		{
			return true;
		}
		return ticker.isDone();
	}
	
	/**
	 * The writer thread
	 */
	private static class Ticker implements Runnable
	{
		/** The parent object, to get messages */
		private LogSystemWriter parent;
		
		public Ticker(LogSystemWriter parent)
		{
			this.parent = parent;
		}
		
		@Override
		public void run()
		{
			try 
			{
				//While must run
				while(parent.isRun >= 1)
				{
					//Check if stop is needed
					if(parent.isRun == 1)
					{
						parent.isRun = 0; //Stop at the next execution
					}
					
					//Write all messages of the queue
					while(!parent.queue.isEmpty())
					{
						fileWrite(parent.queue.removeFirst());
					}
					Thread.currentThread().sleep(500); //Sleep 500 ms for limit the cpu charge, Minecraft must run before this
				}
			}
			catch (Exception e) 
			{
				ErrorsManager.thrownError("EXEC&LSW&RUN", "LSW.Ticker.run", e);
			}
		}
		
		/**
		 * Writes the given string in the log file
		 * 
		 * @param str The str to be written
		 * @return True if works
		 */
		private synchronized boolean fileWrite(String str)
		{
			boolean works = true;
			try
			{
				parent.file.createNewFile();
				FileWriter writer = new FileWriter(parent.file, true);
				try
				{
					writer.write(str);
					String line = System.getProperty("line.separator");
					writer.write(line);				
				}
				finally
				{
					writer.close();
				}
			}
			catch (Exception e) 
			{
				System.err.println("[" + parent.name + "] [FATAL ERROR] Cannot create and edit the log file !");
				e.printStackTrace(System.err);
				works = false;
			}
			return works;
		}
	}
}
