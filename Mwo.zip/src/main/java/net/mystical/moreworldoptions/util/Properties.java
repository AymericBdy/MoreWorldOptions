package net.mystical.moreworldoptions.util;

public class Properties
{
	/*====================== MOD PROPERTIES ======================*/
	
	public static final int MAJOR = 1;
	public static final int MINOR = 1;
	public static final int CORRECTIVE = 0;
	public static final int buildNumber = 11;
	public static final String SUFFIX = "BETA";
	
	public static final String modid = "more_world_options";
	public static final String modname = "MoreWorldOptions";
	public static final String modversion = MAJOR + "." + MINOR + "." + CORRECTIVE + "-" + SUFFIX;
	public static final String[] supportedMcVersions = new String[] {"1.8.9"};
	
	public static final String modFileName = modname + "-" + modversion/* + "-R" + modReleaseVersion*/ + "-" + supportedMcVersions[0];
	
	/*==================== CONTENT PROPERTIES ====================*/
}