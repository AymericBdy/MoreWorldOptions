package net.mystical.moreworldoptions.util;

import net.minecraft.world.WorldSettings.GameType;
import net.minecraft.world.storage.SaveFormatComparator;

public class ZippedWorldSaveFormatComparator extends SaveFormatComparator
{
	public ZippedWorldSaveFormatComparator(String fileNameIn, String displayNameIn, long lastTimePlayedIn, long sizeOnDiskIn, GameType theEnumGameTypeIn, boolean requiresConversionIn, boolean hardcoreIn, boolean cheatsEnabledIn)
	{
		super(fileNameIn, displayNameIn, lastTimePlayedIn, sizeOnDiskIn, theEnumGameTypeIn, requiresConversionIn, hardcoreIn, cheatsEnabledIn); 
	}
	
	@Override
	public int compareTo(SaveFormatComparator toCompare)
	{
		if(toCompare instanceof ZippedWorldSaveFormatComparator)
		{
			return super.compareTo(toCompare);
		}
		return 1;
	}
}
