package net.mystical.moreworldoptions.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.ReflectionHelper;
import net.minecraftforge.fml.relauncher.ReflectionHelper.UnableToAccessFieldException;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.mystical.moreworldoptions.client.gui.GuiSelectWorldWithOptions;
import net.mystical.moreworldoptions.mod.MoreWorldOptions;
import net.mystical.moreworldoptions.util.error.AdditionnalErrorInfo;
import net.mystical.moreworldoptions.util.error.ErrorsManager;

@SideOnly(Side.CLIENT)
public class MoreWorldOptionsEventHandlerClient
{
	private static Minecraft mc = Minecraft.getMinecraft();
	
	@SubscribeEvent
	public void onPreDisplayGui(GuiScreenEvent.InitGuiEvent.Pre event)
	{
		if(event.gui instanceof GuiSelectWorld)
		{
			GuiScreen parent;
			try
			{
				parent = ReflectionHelper.getPrivateValue(GuiSelectWorld.class, (GuiSelectWorld) event.gui, "parentScreen");
			}
			catch (UnableToAccessFieldException e)
			{
				MoreWorldOptions.log.info("[MoreWorldOptionsEventHandlerClient] Field 'parentScreen' wasn't found in the vanilla GuiSelectWorld, searching for 'field_146632_a'");
				try
				{
					parent = ReflectionHelper.getPrivateValue(GuiSelectWorld.class, (GuiSelectWorld) event.gui, "field_146632_a");
				}
				catch (UnableToAccessFieldException e2)
				{
					MoreWorldOptions.log.fatal("[MoreWorldOptionsEventHandlerClient] We are unable to access to the parentScreen field of the vanilla GuiSelectWorld, will will create a new GuiMainMenu");
					parent = new GuiMainMenu();
				}
			}
			event.setCanceled(true);
			Minecraft.getMinecraft().displayGuiScreen(new GuiSelectWorldWithOptions(parent));
		}
	}
}
