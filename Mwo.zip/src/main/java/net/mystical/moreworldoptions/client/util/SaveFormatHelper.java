package net.mystical.moreworldoptions.client.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.commons.lang3.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.io.Files;

import net.minecraft.client.AnvilConverterException;
import net.minecraft.nbt.CompressedStreamTools;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.storage.ISaveFormat;
import net.minecraft.world.storage.SaveFormatComparator;
import net.minecraft.world.storage.WorldInfo;
import net.mystical.moreworldoptions.mod.MoreWorldOptions;
import net.mystical.moreworldoptions.util.MwoWorldInfo;
import net.mystical.moreworldoptions.util.ZippedWorldSaveFormatComparator;

public class SaveFormatHelper
{
    public static List<SaveFormatComparator> getSaveList(File savesDirectory, ISaveFormat format) throws AnvilConverterException
    {
        if (savesDirectory != null && savesDirectory.exists() && savesDirectory.isDirectory())
        {
            List<SaveFormatComparator> list = Lists.<SaveFormatComparator>newArrayList();
            File[] afile = savesDirectory.listFiles();

            for (File file1 : afile)
            {
                String s = file1.getName();
                if (file1.isDirectory())
                {
                    WorldInfo worldinfo = format.getWorldInfo(s);
                    if (worldinfo != null && (worldinfo.getSaveVersion() == 19132 || worldinfo.getSaveVersion() == 19133))
                    {
                        boolean flag = worldinfo.getSaveVersion() != 19133;//this.getSaveVersion();
                        String s1 = worldinfo.getWorldName();
                        if (StringUtils.isEmpty(s1)) s1 = s;
                        long size = -1024L;
                        try
						{
							size = ResourcesHelper.calculateDirectoryLength(file1);
						} 
                        catch (IOException e)
						{
							MoreWorldOptions.log.err("An error occured calculation length of world file " + file1 + " : " + e.toString());
							e.printStackTrace();
						}
                        list.add(new SaveFormatComparator(s, s1, worldinfo.getLastTimePlayed(), size / 1024 /* Size in octects to size in ko */, worldinfo.getGameType(), flag, worldinfo.isHardcoreModeEnabled(), worldinfo.areCommandsAllowed()));
                    }
                }
            }
            return list;
        }
        else
        {
            throw new AnvilConverterException("Unable to read or access folder where game worlds are saved!");
        }
    }
    
    public static List<MwoWorldInfo> getMwoInfosList(File savesDirectory, ISaveFormat format) throws AnvilConverterException
    {
        if (savesDirectory != null && savesDirectory.exists() && savesDirectory.isDirectory())
        {
            List<MwoWorldInfo> list = Lists.<MwoWorldInfo>newArrayList();
            File[] afile = savesDirectory.listFiles();

            for (File file1 : afile)
            {
                String s = file1.getName();
                if (file1.isDirectory())
                {
					MwoWorldInfo info = getMwoWorldInfo(savesDirectory, format, s);
					if(info == null) info = MwoWorldInfo.createForExistingWorld(s, format.getWorldInfo(s).getLastTimePlayed()); //TODO Optimize how "getLastTimePlayed" is get
					list.add(info);
                }
            }
            return list;
        }
        else
        {
            throw new AnvilConverterException("Unable to read or access folder where game worlds are saved!");
        }
    }
    
    public static List<ZippedWorldSaveFormatComparator> getZippedSaveList(File savesDirectory, ISaveFormat format) throws AnvilConverterException
    {
        if (savesDirectory != null && savesDirectory.exists() && savesDirectory.isDirectory())
        {
            List<ZippedWorldSaveFormatComparator> list = Lists.<ZippedWorldSaveFormatComparator>newArrayList();
            File[] afile = savesDirectory.listFiles();

            for (File file1 : afile)
            {
                String s = file1.getName();
                if (Files.getFileExtension(s).equals("zip"))
                {
                    WorldInfo worldinfo;
					try
					{
						worldinfo = getWorldInfo(savesDirectory, format, s);
					}
					catch (IOException e)
					{
						e.printStackTrace();
						throw new AnvilConverterException("An error occured reading zipped worlds data : " + e);
					}
                    if (worldinfo != null && (worldinfo.getSaveVersion() == 19132 || worldinfo.getSaveVersion() == 19133))
                    {
                        boolean flag = worldinfo.getSaveVersion() != 19133;//this.getSaveVersion();
                        String s1 = worldinfo.getWorldName();
                        if (StringUtils.isEmpty(s1)) s1 = s;
                        list.add(new ZippedWorldSaveFormatComparator(s, s1, worldinfo.getLastTimePlayed(), file1.length() / 1024 /* Size in octects to size in ko */, worldinfo.getGameType(), flag, worldinfo.isHardcoreModeEnabled(), worldinfo.areCommandsAllowed()));
                    }
                }
            }

            return list;
        }
        else
        {
            throw new AnvilConverterException("Unable to read or access folder where game worlds are saved!");
        }
    }
    
    public static WorldInfo getWorldInfo(File savesDirectory, ISaveFormat format, String saveName) throws IOException
    {
        File file1 = new File(savesDirectory, saveName);
        File to = new File(savesDirectory, "level.dat");
        
    	ZipFile file = new ZipFile(file1);
    	ZipEntry entry = file.getEntry("level.dat");
    	if(entry == null)
    	{
    		ZipEntry entr;
    		Enumeration<? extends ZipEntry> enu = file.entries();
    		while(enu.hasMoreElements())
    		{
    			entr = enu.nextElement();
    			if(entr.getName().contains("level.dat"))
    			{
    				entry = entr;
    				break;
    			}
    		}
    		if(entry == null)
    		{
	    		file.close();
	    		MoreWorldOptions.log.err("Cannot find the level.dat file of the zipped world : " + saveName + ", searching for level.dat_old"); 
    		}
    	}
    	if(entry != null)
    	{
	    	ResourcesHelper.dezipZipEntry(file, entry, savesDirectory, false);
	    	file.close();
	        if (to.exists())
	        {
	            try
	            {
	                NBTTagCompound nbttagcompound2 = CompressedStreamTools.readCompressed(new FileInputStream(to));
	                NBTTagCompound nbttagcompound3 = nbttagcompound2.getCompoundTag("Data");
	                to.delete();
	                return new WorldInfo(nbttagcompound3);
	            }
	            catch (Exception exception1)
	            {
	            	MoreWorldOptions.log.err("Exception reading " + to + ". Error : " + exception1);
	            }
	        }
	    }

        to = new File(savesDirectory, "level.dat_old");
    	file = new ZipFile(file1);
    	entry = file.getEntry("level.dat_old");
    	if(entry == null)
    	{
    		ZipEntry entr;
    		Enumeration<? extends ZipEntry> enu = file.entries();
    		while(enu.hasMoreElements())
    		{
    			entr = enu.nextElement();
    			if(entr.getName().contains("level.dat_old"))
    			{
    				entry = entr;
    				break;
    			}
    		}
    		if(entry == null)
    		{
	    		file.close();
	    		MoreWorldOptions.log.err("Cannot find the level.dat_old file of the zipped world : " + saveName + ", world corrupted or unknow error occured"); 
    		}
    	}
    	if(entry != null)
    	{
	    	ResourcesHelper.dezipZipEntry(file, entry, savesDirectory, false);
	    	file.close();
	        if (to.exists())
	        {
	            try
	            {
	                NBTTagCompound nbttagcompound = CompressedStreamTools.readCompressed(new FileInputStream(to));
	                NBTTagCompound nbttagcompound1 = nbttagcompound.getCompoundTag("Data");
	                to.delete();
	                return new WorldInfo(nbttagcompound1);
	            }
	            catch (Exception exception)
	            {
	            	MoreWorldOptions.log.err("Exception reading " + to + ". Error : " + exception);
	            }
	        }
    	}
        return null;
    }
    
    public static void renameWorldAndWorldFile(ISaveFormat format, String dirName, String newWorldName, String newWorldFileName)
    {
    	File file1 = new File(ResourcesHelper.savesDir, dirName);
        if (file1.exists())
        {
            File file2 = new File(file1, "level.dat");
            File file3 = new File(ResourcesHelper.savesDir, newWorldFileName);
            if (file2.exists())
            {
                try
                {
                    NBTTagCompound nbttagcompound = CompressedStreamTools.readCompressed(new FileInputStream(file2));
                    NBTTagCompound nbttagcompound1 = nbttagcompound.getCompoundTag("Data");
                    nbttagcompound1.setString("LevelName", newWorldName);
                    CompressedStreamTools.writeCompressed(nbttagcompound, new FileOutputStream(file2));
                    
                    if(!file3.exists())
                    {
                    	file1.renameTo(file3);
                    }
                }
                catch (Exception exception)
                {
                    exception.printStackTrace();
                }
            }
        }
    }
    
    public static MwoWorldInfo getMwoWorldInfo(File savesDirectory, ISaveFormat format, String saveName)
    {
    	File file1 = new File(savesDirectory, saveName);
        File inf = new File(file1, "MwoWorldData.dat");
        if (inf.exists())
        {
            try
            {
                NBTTagCompound nbttagcompound2 = CompressedStreamTools.readCompressed(new FileInputStream(inf));
                NBTTagCompound nbttagcompound3 = nbttagcompound2.getCompoundTag("WorldInformations");
                return MwoWorldInfo.createAndLoadFromNBT(nbttagcompound3, saveName, format.getWorldInfo(saveName).getLastTimePlayed()); //TODO Optimize how "getLastTimePlayed" is get
            }
            catch (Exception exception1)
            {
            	MoreWorldOptions.log.err("Exception reading " + inf + ". Error : " + exception1);
            }
        }
        WorldInfo wdInfo = format.getWorldInfo(saveName);
        if(wdInfo == null) throw new NullPointerException("The world info for " + saveName + " cannot be found, so we cannot found the MwoWorldInfo for this world !");
    	return MwoWorldInfo.createForExistingWorld(saveName, wdInfo.getLastTimePlayed()); //TODO Optimize how "getLastTimePlayed" is get
    }
    
    public static boolean saveMwoWorldInfoTo(MwoWorldInfo info, File savesDirectory, ISaveFormat format, String saveName) throws IOException
    {
    	File file1 = new File(savesDirectory, saveName);
        File inf = new File(file1, "MwoWorldData.dat");
        if(inf.exists()) inf.delete();
        inf.createNewFile();
        try
        {
        	NBTTagCompound tag = new NBTTagCompound();
        	info.writeToNBT(tag);
        	NBTTagCompound tag2 = new NBTTagCompound();
        	tag2.setTag("WorldInformations", tag);
        	CompressedStreamTools.writeCompressed(tag2, new FileOutputStream(inf));
            return true;
        }
        catch (Exception exception1)
        {
        	MoreWorldOptions.log.err("Exception writing " + inf + ". Error : " + exception1);
        	return false;
        }
    }
}
