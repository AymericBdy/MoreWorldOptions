package net.mystical.moreworldoptions.client.util;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/**
 * A simple class that contains a quadrilateral and some methods to draw it's at it's coords or check if the mouse is in of the quadrilateral
 */
@SideOnly(Side.CLIENT)
public class DrawableQuadrilateral
{
	public int[] topLeft;
	public int[] topRight;
	public int[] bottomRight;
	public int[] bottomLeft;
	
	public DrawableQuadrilateral(int startX, int startY, int sizeX, int sizeY)
	{
		set(startX, startY, sizeX, sizeY);
	}
	
	public DrawableQuadrilateral(int[] topLeft, int[] topRight, int[] bottomRight, int[] bottomLeft)
	{
		this.topLeft = topLeft;
		this.topRight = topRight;
		this.bottomLeft = bottomLeft;
		this.bottomRight = bottomRight;
	}
	
	public void drawGradient(int startColor, int endColor, float zLevel)
	{
		float f = (startColor >> 24 & 255) / 255.0F;
        float f1 = (startColor >> 16 & 255) / 255.0F;
        float f2 = (startColor >> 8 & 255) / 255.0F;
        float f3 = (startColor & 255) / 255.0F;
        float f4 = (endColor >> 24 & 255) / 255.0F;
        float f5 = (endColor >> 16 & 255) / 255.0F;
        float f6 = (endColor >> 8 & 255) / 255.0F;
        float f7 = (endColor & 255) / 255.0F;
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.shadeModel(7425);
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldrenderer = tessellator.getWorldRenderer();
        worldrenderer.begin(7, DefaultVertexFormats.POSITION_COLOR);
        worldrenderer.pos(topRight[0], topRight[1], zLevel).color(f1, f2, f3, f).endVertex();
        worldrenderer.pos(topLeft[0], topLeft[1], zLevel).color(f1, f2, f3, f).endVertex();
        worldrenderer.pos(bottomLeft[0], bottomLeft[1], zLevel).color(f5, f6, f7, f4).endVertex();
        worldrenderer.pos(bottomRight[0], bottomRight[1], zLevel).color(f5, f6, f7, f4).endVertex();
        tessellator.draw();
        GlStateManager.shadeModel(7424);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
	}
	
    public void drawRect(int color)
    {
        float f3 = (color >> 24 & 255) / 255.0F;
        float f = (color >> 16 & 255) / 255.0F;
        float f1 = (color >> 8 & 255) / 255.0F;
        float f2 = (color & 255) / 255.0F;
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldrenderer = tessellator.getWorldRenderer();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(f, f1, f2, f3);
        worldrenderer.begin(7, DefaultVertexFormats.POSITION);
        worldrenderer.pos(topRight[0], topRight[1], 0D).endVertex();
        worldrenderer.pos(topLeft[0], topLeft[1], 0D).endVertex();
        worldrenderer.pos(bottomLeft[0], bottomLeft[1], 0D).endVertex();
        worldrenderer.pos(bottomRight[0], bottomRight[1], 0D).endVertex();
        tessellator.draw();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }
	
	/**
	 * Divides the current quad in 4 parts then check if the mouse is pointing in one of these parts
	 * 
	 * @param mouseX
	 * @param mouseY
	 * @return
	 */
	public boolean isMouseIn(int mouseX, int mouseY)
	{
		int width1 = (topRight[0] - topLeft[0]) / 2;
		int width2 = (bottomRight[0] - bottomLeft[0]) / 2;

		int height1 = (bottomLeft[1] - topLeft[1]) / 2;
		int height2 = (bottomRight[1] - topRight[1]) / 2;
		
		if(mouseX >= topLeft[0] && mouseX <= topLeft[0] + width1 && mouseY >= topLeft[1] && mouseY <= topLeft[1] + height1) return true;
		if(mouseX <= topRight[0] && mouseX >= topRight[0] - width1 && mouseY >= topRight[1] && mouseY <= topRight[1] + height2) return true;
		
		if(mouseX >= bottomLeft[0] && mouseX <= bottomLeft[0] + width2 && mouseY <= bottomLeft[1] && mouseY >= bottomLeft[1] - height1) return true;
		if(mouseX <= bottomRight[0] && mouseX >= bottomRight[0] - width2 && mouseY <= bottomRight[1] && mouseY >= bottomRight[1] - height2) return true;
		return false;
	}
	
	public void set(int startX, int startY, int sizeX, int sizeY)
	{
		topLeft = new int[] {startX, startY};
		topRight = new int[] {startX + sizeX, startY};
		bottomLeft = new int[] {startX, startY + sizeY};
		bottomRight = new int[] {startX + sizeX, startY + sizeY};
	}
}
