package net.mystical.moreworldoptions.client.util;

import net.minecraft.client.resources.ResourcePackListEntry;
import net.minecraft.client.resources.ResourcePackRepository;
import net.mystical.moreworldoptions.client.gui.GuiCustomizePacks;

public class ResourcePackListEntryFoundSp extends ResourcePackListEntrySp
{
	private final ResourcePackRepository.Entry pack;

    public ResourcePackListEntryFoundSp(GuiCustomizePacks resourcePacksGUIIn, ResourcePackRepository.Entry p_i45053_2_)
    {
        super(resourcePacksGUIIn);
        this.pack = p_i45053_2_;
    }

    protected void func_148313_c()
    {
        this.pack.bindTexturePackIcon(this.mc.getTextureManager());
    }

    protected int func_183019_a()
    {
        return this.pack.func_183027_f();
    }

    protected String func_148311_a()
    {
        return this.pack.getTexturePackDescription();
    }

    protected String func_148312_b()
    {
        return this.pack.getResourcePackName();
    }

    public ResourcePackRepository.Entry func_148318_i()
    {
        return this.pack;
    }
}
