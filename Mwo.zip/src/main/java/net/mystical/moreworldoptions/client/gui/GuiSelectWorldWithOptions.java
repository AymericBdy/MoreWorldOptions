package net.mystical.moreworldoptions.client.gui;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.zip.ZipFile;

import org.apache.commons.lang3.StringUtils;
import org.lwjgl.Sys;

import net.minecraft.client.AnvilConverterException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiErrorScreen;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSlot;
import net.minecraft.client.gui.GuiYesNo;
import net.minecraft.client.gui.GuiYesNoCallback;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.Util;
import net.minecraft.world.WorldSettings;
import net.minecraft.world.storage.ISaveFormat;
import net.minecraft.world.storage.SaveFormatComparator;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.mystical.moreworldoptions.client.util.ResourcesHelper;
import net.mystical.moreworldoptions.client.util.SaveFormatHelper;
import net.mystical.moreworldoptions.mod.MoreWorldOptions;
import net.mystical.moreworldoptions.util.MwoUtil;
import net.mystical.moreworldoptions.util.MwoUtil.ColorHelper;
import net.mystical.moreworldoptions.util.error.AdditionnalErrorInfo;
import net.mystical.moreworldoptions.util.error.ErrorsManager;
import net.mystical.moreworldoptions.util.plugins.StandardUpdater;
import net.mystical.moreworldoptions.util.MwoWorldInfo;
import net.mystical.moreworldoptions.util.ZippedWorldSaveFormatComparator;

@SideOnly(Side.CLIENT)
public class GuiSelectWorldWithOptions extends GuiScreen implements GuiYesNoCallback
{
	//Minecraft
    private final DateFormat dateFormat = new SimpleDateFormat();
    protected GuiScreen parent;
    protected String title = "Select world";
    public boolean hasStartedToLoadAWorld;
    private int selectionIndex;
    private GuiSelectWorldWithOptions.List worldsList;
    private String defaultWorldName;
    private String conversion;
    private String[] gameTypes = new String[4];
    private boolean externalGuiOpened;
    private GuiButton deleteButton;
    private GuiButton selectButton;
    private GuiButton modifyButton;

    private java.util.List<SaveFormatComparator> worlds;
    private java.util.List<MwoWorldInfo> mwoInfos;

    public GuiSelectWorldWithOptions(GuiScreen p_i1054_1_)
    {
        this.parent = p_i1054_1_;
    }

    @Override
	public void initGui()
    {
        this.title = I18n.format("selectWorld.title");

        this.defaultWorldName = I18n.format("selectWorld.world");
        this.conversion = I18n.format("selectWorld.conversion");
        this.gameTypes[WorldSettings.GameType.SURVIVAL.getID()] = I18n.format("gameMode.survival");
        this.gameTypes[WorldSettings.GameType.CREATIVE.getID()] = I18n.format("gameMode.creative");
        this.gameTypes[WorldSettings.GameType.ADVENTURE.getID()] = I18n.format("gameMode.adventure");
        this.gameTypes[WorldSettings.GameType.SPECTATOR.getID()] = I18n.format("gameMode.spectator");
        this.worldsList = new GuiSelectWorldWithOptions.List(this.mc);
        this.worldsList.registerScrollButtons(4, 5);
        this.addButtons();
        
        //MoreWorldOptions
        this.registerMoreWorldOptionsButtons();
        
        //World must be loaded after the world was deleted, not before because loadWorlds is operated in another thread and the list is cleared before
        if(!externalGuiOpened)
        {
            this.loadWorlds(false);
        }
        this.externalGuiOpened = false; //After display gui screen else, displayGuiScreen will reload all worlds in another thread before delete the world
        
        this.worldsList.elementClicked(selectionIndex, false, -1, -1);
    }

    @Override
	public void handleMouseInput() throws IOException
    {
        super.handleMouseInput();
        this.worldsList.handleMouseInput();
    }

    protected String getWorldFileName(int p_146621_1_)
    {
        return ((SaveFormatComparator)this.worlds.get(p_146621_1_)).getFileName();
    }

    protected String getWorldName(int p_146614_1_)
    {
        String s = ((SaveFormatComparator)this.worlds.get(p_146614_1_)).getDisplayName();

        if (StringUtils.isEmpty(s))
        {
            s = I18n.format("gui.selectWorld.world") + " " + (p_146614_1_ + 1);
        }

        return s;
    }

    public void addButtons()
    {
        this.buttonList.add(this.selectButton = new GuiButton(1, this.width / 2 - 154, this.height - 52, 150, 20, I18n.format("selectWorld.select")));
        this.buttonList.add(new GuiButton(3, this.width / 2 + 4, this.height - 52, 150, 20, I18n.format("selectWorld.create")));
        this.buttonList.add(this.modifyButton = new GuiButton(6, this.width / 2 - 76, this.height - 28, 72, 20, I18n.format("gui.selectWorld.modify")));
        this.buttonList.add(this.deleteButton = new GuiButton(2, this.width / 2 + 4, this.height - 28, 72, 20, I18n.format("selectWorld.delete")));
        this.buttonList.add(new GuiButton(0, this.width / 2 + 82, this.height - 28, 72, 20, I18n.format("gui.cancel")));
        this.selectButton.enabled = false;
        this.deleteButton.enabled = false;
        this.modifyButton.enabled = false;
    }

    @Override
	protected void actionPerformed(GuiButton button) throws IOException
    {
        if (button.enabled)
        {
            if (button.id == 2)
            {
                String s = this.getWorldName(this.selectionIndex);

                if (s != null)
                {
                    this.externalGuiOpened = true;
                    GuiYesNo guiyesno = deleteWorldRequest(this, s, this.selectionIndex);
                    this.mc.displayGuiScreen(guiyesno);
                }
            }
            else if (button.id == 1)
            {
            	if(worlds.get(selectionIndex) instanceof ZippedWorldSaveFormatComparator)
            	{
            		this.unzipWorld(this.selectionIndex);
            	}
            	else
            	{
            		this.loadAWorld(this.selectionIndex);
            	}
            }
            else if (button.id == 3)
            {
                this.externalGuiOpened = true;
                this.mc.displayGuiScreen(new GuiCreateWorldWithOptions(this));
            }
            else if (button.id == 6)
            {
                //this.externalGuiOpened = true;
                this.mc.displayGuiScreen(new GuiModifyWorld(this, this.getWorldFileName(this.selectionIndex), this.mwoInfos.get(selectionIndex)));
            }
            else if (button.id == 0)
            {
                this.mc.displayGuiScreen(this.parent);
            }
            else if(button.id == 102)//MoreWorldOptions
            {
                this.externalGuiOpened = true;
            	this.displayGuiCopyWorld(this.getWorldFileName(selectionIndex));
            }
            else if(button.id == 10000)
            {
            	this.showingZipsFiles = !this.showingZipsFiles;
            	this.reloadWorlds();
            }
            else if(button.id == 103)
            {
                String s = ResourcesHelper.savesDir.getAbsolutePath();
                if (Util.getOSType() == Util.EnumOS.OSX)
                {
                    try
                    {
                        MoreWorldOptions.log.info("Opening worlds dir on OSX : " + s);
                        Runtime.getRuntime().exec(new String[] {"/usr/bin/open", s});
                        return;
                    }
                    catch (IOException e)
                    {
                    	MoreWorldOptions.log.err("Couldn\'t open file on Mac OSX : " + e);
                    }
                }
                else if (Util.getOSType() == Util.EnumOS.WINDOWS)
                {
                    String s1 = String.format("cmd.exe /C start \"Open file\" \"%s\"", new Object[] {s});
                    try
                    {
                        Runtime.getRuntime().exec(s1);
                        return;
                    }
                    catch (IOException e)
                    {
                    	MoreWorldOptions.log.err("Couldn\'t open file on Windows : " + e);
                    }
                }
                try
                {
                	if(Desktop.isDesktopSupported())
                	{
                		Desktop.getDesktop().browse(ResourcesHelper.savesDir.toURI());
                	}
                	else
                	{
                		MoreWorldOptions.log.err("Couldn\'t open link via desktop : " + "Desktop isn't supported !");
                    	MoreWorldOptions.log.info("Opening via system class!");
                        Sys.openURL("file://" + s);
                	}
                }
                catch (IOException e)
                {
                	MoreWorldOptions.log.err("Couldn\'t open link via desktop : " + e);
                	MoreWorldOptions.log.info("Opening via system class!");
                    Sys.openURL("file://" + s);
                }
            }
            else if(button.id == 108)
            {
            	this.startLoading();
            	this.statusDisplayCounter = -1;
            	setCopyStatus("Installing the update...", ColorHelper.BLUE);
            	StandardUpdater.installNewVersion(false);
            	this.statusDisplayCounter = 0;
            	this.endLoading();
            }
            else
            {
                this.worldsList.actionPerformed(button);
            }
        }
    }
    
	public void loadAWorld()
    {
		if(selectionIndex >= 0 && selectionIndex < worlds.size())
			loadAWorld(this.selectionIndex);
    }

	public void loadAWorld(int slotIndex)
    {
        if (!this.hasStartedToLoadAWorld)
        {			
        	mc.loadingScreen.resetProgressAndMessage(I18n.format("gui.selectWorld.launch.preparing"));
        	mc.loadingScreen.displayLoadingString(I18n.format("gui.selectWorld.launch.verifyInfo"));
        	
            String s = this.getWorldFileName(slotIndex);
            if (s == null) s = "World" + slotIndex;
            String s1 = this.getWorldName(slotIndex);
            if (s1 == null) s1 = "World" + slotIndex;
            
            MwoWorldInfo info = mwoInfos.get(slotIndex);
            int compatibility = info.compareMcVersionToCurrent();
            if(compatibility == 1)
            {
            	info.setMcVersion(Loader.MC_VERSION);
            	info.save(mc);
            }
            if(compatibility == -2 || compatibility == -1 || compatibility == 2)
            {
            	this.externalGuiOpened = true;
            	mc.displayGuiScreen(new GuiWorldLoadingWarning(s1, s, compatibility, info, this));
            }
            else if (this.mc.getSaveLoader().canLoadWorld(s)) 
            {
    	    	mc.loadingScreen.displayLoadingString(I18n.format("gui.selectWorld.launching"));
                this.hasStartedToLoadAWorld = true;
            	this.externalGuiOpened = true;
            	mc.displayGuiScreen(new GuiPreparingWorldToLoad(parent, this, info, s1));
            }
        }
    }

	/**
	 * Called by the GuiYesNo, after the user have clicked
	 */
    @Override
	public void confirmClicked(boolean result, int id)
    {
        if (this.externalGuiOpened)
        {
            this.mc.displayGuiScreen(this);
            if (result)
            {
            	this.startLoading();
            	this.statusDisplayCounter = -1;
            	this.setCopyStatus(MwoUtil.translate("gui.selectWorld.deleting") + " : " + this.getWorldFileName(id), ColorHelper.getRandomEnergyColor());
            	
            	new Thread(new WorldsListLoader(this, 0, this.getWorldFileName(id))).start();
            }
        }
    }

    @Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks)
    {
        FontRenderer fr = this.fontRendererObj;
        
        this.worldsList.drawScreen(mouseX, mouseY, partialTicks);
        if(this.statusDisplayCounter != 0)
        {
            this.drawCenteredString(fr, this.title, this.width / 2, 5, 16777215);
            this.drawCenteredString(fr, copyStatus, this.width / 2, 20, copyColor.getValue());
        }
        else if(StandardUpdater.show)
        {
            this.drawCenteredString(fr, this.title, this.width / 2, 5, 16777215);
            this.drawCenteredString(fr, StandardUpdater.updateStatus.getFormattedText(), this.width / 2, 20, 16777215);
        }
        else
        {
        	this.drawCenteredString(fr, this.title, this.width / 2, 20, 16777215);
        }
        
        if(isLoading)
        {
        	String s = MwoUtil.translate("gui.selectWorld.loading");
        	fr.drawString(s, this.width / 2 - fr.getStringWidth(s) / 2, 50, ColorHelper.BURNEDORANGE.getValue());
            switch ((int)(Minecraft.getSystemTime() / 300L % 4L))
            {
                case 0:
                default:
                    s = "O o o";
                    break;
                case 1:
                case 3:
                    s = "o O o";
                    break;
                case 2:
                    s = "o o O";
            }
            fr.drawString(s, this.width / 2 - fr.getStringWidth(s) / 2, 65, ColorHelper.ORANGE.getValue());
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    public static GuiYesNo deleteWorldRequest(GuiYesNoCallback callback, String name, int clickedButton)
    {
        String s1 = I18n.format("selectWorld.deleteQuestion");
        String s2 = "\'" + name + "\' " + I18n.format("selectWorld.deleteWarning");
        String s3 = I18n.format("selectWorld.deleteButton");
        String s4 = I18n.format("gui.cancel");
        GuiYesNo guiyesno = new GuiYesNo(callback, s1, s2, s3, s4, clickedButton);
        return guiyesno;
    }

    @SideOnly(Side.CLIENT)
    class List extends GuiSlot
    {
        public List(Minecraft mcIn)
        {
            super(mcIn, GuiSelectWorldWithOptions.this.width, GuiSelectWorldWithOptions.this.height, 32, GuiSelectWorldWithOptions.this.height - 64, 36);
        }

        @Override
		protected int getSize()
        {
            return GuiSelectWorldWithOptions.this.worlds.size();
        }

        @Override
		protected void elementClicked(int slotIndex, boolean isDoubleClick, int mouseX, int mouseY)
        {
        	//MoreWorldOptions
        	if(GuiSelectWorldWithOptions.isLoading)
        	{
        		return;
        	}
            GuiSelectWorldWithOptions.this.selectionIndex = slotIndex;
            boolean flag1 = GuiSelectWorldWithOptions.this.selectionIndex >= 0 && GuiSelectWorldWithOptions.this.selectionIndex < this.getSize();
            boolean zipped = false;
            if(flag1 && worlds.get(slotIndex) instanceof ZippedWorldSaveFormatComparator)
            {
            	flag1 = false;
            	zipped = true;
            	GuiSelectWorldWithOptions.this.selectButton.displayString = MwoUtil.translate("gui.selectWorld.unzip");
            }
            else
            {
            	GuiSelectWorldWithOptions.this.selectButton.displayString = I18n.format("selectWorld.select");
            }
            GuiSelectWorldWithOptions.this.selectButton.enabled = flag1 || zipped;
            GuiSelectWorldWithOptions.this.deleteButton.enabled = flag1 || zipped;
            GuiSelectWorldWithOptions.this.modifyButton.enabled = flag1;
            
            //MoreWorldOptions
            copyButton.enabled = flag1;

            if (isDoubleClick && flag1)
            {
                GuiSelectWorldWithOptions.this.loadAWorld(slotIndex);
            }
        }

        @Override
		protected boolean isSelected(int slotIndex)
        {
            return slotIndex == GuiSelectWorldWithOptions.this.selectionIndex;
        }

        @Override
		protected int getContentHeight()
        {
            return GuiSelectWorldWithOptions.this.worlds.size() * 36;
        }

        @Override
		protected void drawBackground()
        {
            GuiSelectWorldWithOptions.this.drawDefaultBackground();
        }

        @Override
		protected void drawSlot(int entryID, int x, int y, int slotHeigth, int mouseX, int mouseY)
        {
        	if(GuiSelectWorldWithOptions.this.isLoading) return;
            SaveFormatComparator format = (SaveFormatComparator)GuiSelectWorldWithOptions.this.worlds.get(entryID);
            String s = format.getDisplayName();
            String s1 = format.getFileName();
            boolean isCompressed = format instanceof ZippedWorldSaveFormatComparator;
            
            if(isCompressed)
            {
            	s1 = s1.replace(".zip", "");
            	s1 += EnumChatFormatting.GOLD + ".zip" + EnumChatFormatting.RESET;
            }
            s1 += " (" + GuiSelectWorldWithOptions.this.dateFormat.format(new Date(format.getLastTimePlayed())) + ")";
            
            String sizeS = "Size:";
            long size = format.getSizeOnDisk();
            if(size <= 1024) sizeS += " " + size + "ko";
            else sizeS += " " + (size / 1024) + "mo";
            
            String mcVersion = "";
            String description = "";
            if(!isCompressed)
            {
                MwoWorldInfo info = mwoInfos.get(entryID);
            	mcVersion = info.getColoredMcVersionComparedToCurrent();
            	description = info.getDescription();
            }
            
            String s2 = "";
            if (format.requiresConversion())
            {
                s2 = GuiSelectWorldWithOptions.this.conversion + " " + s2;
            }
            else
            {
                s2 = GuiSelectWorldWithOptions.this.gameTypes[format.getEnumGameType().getID()];

                if (format.isHardcoreModeEnabled()) s2 = EnumChatFormatting.DARK_RED + I18n.format("gameMode.hardcore") + EnumChatFormatting.RESET;
                if (format.getCheatsEnabled()) s2 += ", " + I18n.format("selectWorld.cheats");
                
                if(isCompressed) s2 += ", " + EnumChatFormatting.GOLD + "compressed in a zip" + EnumChatFormatting.RESET;
            }

            GuiSelectWorldWithOptions.this.drawString(GuiSelectWorldWithOptions.this.fontRendererObj, s, x + 2, y + 1, 16777215);
            GuiSelectWorldWithOptions.this.drawString(GuiSelectWorldWithOptions.this.fontRendererObj, s1, x + 2, y + 12, 8421504);
            GuiSelectWorldWithOptions.this.drawString(GuiSelectWorldWithOptions.this.fontRendererObj, s2, x + 2, y + 12 + 10, 8421504);

            GuiSelectWorldWithOptions.this.drawString(GuiSelectWorldWithOptions.this.fontRendererObj, mcVersion, x + getListWidth() - fontRendererObj.getStringWidth(mcVersion) - 10, y + 1, 8421504);
            GuiSelectWorldWithOptions.this.drawString(GuiSelectWorldWithOptions.this.fontRendererObj, sizeS, x + getListWidth() - fontRendererObj.getStringWidth(sizeS) - 10, y + 22, ColorHelper.GUIsGRAY.getValue()/*4177856*/);
            
            if(this.isMouseInBounds(x, y, mouseX, mouseY) && !MwoUtil.isStringEmpty(description))
            {
            	java.util.List<String> text = new ArrayList<String>();
            	text.add(EnumChatFormatting.AQUA + I18n.format("gui.selectWorld.saveDescription"));
            	java.util.List<String> descr = fontRendererObj.listFormattedStringToWidth(description, 200);
            	text.addAll(descr);
            	GuiSelectWorldWithOptions.this.drawHoveringText(text, mouseX, mouseY, fontRendererObj);
            	GlStateManager.disableLighting();
            }
        }
        
        @Override
        public int getListWidth()
        {
        	return 300;
        }
        
        public boolean isMouseInBounds(int slotX, int slotY, int mouseX, int mouseY)
        {
            return mouseX >= slotX && mouseX <= slotX + getListWidth() - 3 && mouseY >= slotY && mouseY <= slotY + slotHeight - 4;
        }
    }
    
//	================================== MoreWorldOptions START ==================================
    
    private GuiButton copyButton;
    private GuiButton showZipsButton;
    
    private String copyStatus = "";
    private int statusDisplayCounter = 0;
    private ColorHelper copyColor = ColorHelper.WHITE;
    
    public static boolean isLoading;
    public boolean showingZipsFiles;

	private void registerMoreWorldOptionsButtons() 
	{
		String s = MwoUtil.translate("gui.selectWorld.copy");
		this.buttonList.add(copyButton = new GuiButton(102, this.width / 2 - 154, this.height - 28, 72, 20, s));
		copyButton.enabled = false;
		
		s = MwoUtil.translate("gui.selectWorld.showZips.enable");
		this.buttonList.add(showZipsButton = new GuiButton(10000, 2, height - 22, fontRendererObj.getStringWidth(s) + 8, 20, s));
		
		s = MwoUtil.translate("gui.selectWorld.openFolder");
		int l = fontRendererObj.getStringWidth(s) + 8;
		this.buttonList.add(new GuiButton(103, width - l - 2, height - 22, l, 20, s));
		
		if(StandardUpdater.show)
		{
			s = "Update";
			this.buttonList.add(new GuiButton(108, 4, 4, fontRendererObj.getStringWidth(s) + 8, 20, s));
		}
	}
	
	public void startLoading()
	{
		this.worldsList.elementClicked(-1, false, 0, 0);
		this.isLoading = true;
	}
	
	public void endLoading()
	{
		this.isLoading = false;
	}
	
	public void setDefaultDisplayCooldown()
	{
		statusDisplayCounter = MwoUtil.secondsToTicks(3);
	}
	
    //MoreWorldOptions
    public void reloadWorlds()
    {
    	this.loadWorlds(showingZipsFiles);
    }
    
    private void loadWorlds(boolean withZips)
    {
    	this.startLoading();
    	this.worlds = new ArrayList();
    	this.mwoInfos = new ArrayList();
    	new Thread(new WorldsListLoader(this, withZips ? -2 : -1)).start();
    }
	
	protected void displayGuiCopyWorld(String fileName)
	{
    	selectButton.enabled = false;
    	deleteButton.enabled = false;
    	modifyButton.enabled = false;
    	copyButton.enabled = false;
    	
    	this.selectionIndex = -1;
    	
        mc.displayGuiScreen(new GuiCopyWorld(this, fileName));
	}
	
    public void launchWorldCopy(String originalWorldFileName, String newName, boolean zipTheCopy, boolean deleteOld) 
    {
    	this.startLoading();
    	this.statusDisplayCounter = -1;
    	
    	copyStatus = "Copy in progress...";
    	copyColor = ColorHelper.ORANGE;
        
        ResourcesHelper.launchWorldCopy(this, originalWorldFileName, newName, zipTheCopy, deleteOld);
	}
    
    public void unzipWorld(int index)
    {
    	this.startLoading();
		this.statusDisplayCounter = -1;
		this.selectionIndex = -1;
		this.setCopyStatus(I18n.format("gui.selectWorld.unzipping"), ColorHelper.getRandomEnergyColor());
		
		String fileName = this.getWorldFileName(index);
		new Thread(new WorldsListLoader(this, 1, fileName)).start();
    }
    
    public void setCopyStatus(String copyStatus)
    {
    	setCopyStatus(copyStatus, copyColor);
    }
    
    public void setCopyStatus(String copyStatus, ColorHelper color)
    {
    	this.copyStatus = copyStatus;
    	this.copyColor = color;
    }
    
    public String getCopyStatus()
    {
    	return copyStatus;
    }
    
    @Override
	public void updateScreen()
    {
    	super.updateScreen();
    	if(this.statusDisplayCounter > 0)
    	{
    		this.statusDisplayCounter--;
    	}
    }
    
    private class WorldsListLoader implements Runnable
    {
    	private GuiSelectWorldWithOptions parent;
    	/** -2 = reloadWorlds with zips, -1 = reload worlds, 0 = delete world, 1 = unzipWorld, 2 = load packs for world */
    	private final int taskID;
    	private final String taskData;
    	
    	public WorldsListLoader(GuiSelectWorldWithOptions parent, int taskID)
    	{
    		this(parent, taskID, "");
    	}
    	
    	public WorldsListLoader(GuiSelectWorldWithOptions parent, int taskID, String taskData)
    	{
    		this.parent = parent;
    		this.taskID = taskID;
    		this.taskData = taskData;
    	}
    	
		@Override
		public void run()
		{
	        try
			{
				ISaveFormat isaveformat = parent.mc.getSaveLoader();
				if(taskID == 0)
				{
				    isaveformat.flushCache();
				    ResourcesHelper.deleteFileOrDirectory(new File(ResourcesHelper.savesDir, taskData));
				}
				if(taskID == 1)
				{
					File worldFile = new File(ResourcesHelper.savesDir, taskData);
					ZipFile zip = new ZipFile(worldFile);
					String name = GuiModifyWorld.getUncollidingSaveDirName(taskData.replace(".zip", ""), taskData.replace(".zip", ""), false);
					ResourcesHelper.dezipFile(zip, new File(ResourcesHelper.savesDir, name));
					zip.close();
					
					ResourcesHelper.deleteFileOrDirectory(worldFile);
					
					parent.setCopyStatus(I18n.format("gui.selectWorld.unzipping.renaming"));
					isaveformat.renameWorld(name, name);
					setCopyStatus(I18n.format("gui.selectWorld.reloading"), ColorHelper.GRASSGREEN);
				}
				if(taskID == -2 || taskID == -1 || taskID == 0 || taskID == 1) //Don't put "else" because world deleter also want to load worlds
				{
				    try
					{
				    	java.util.List<SaveFormatComparator> worlds = SaveFormatHelper.getSaveList(ResourcesHelper.savesDir, isaveformat);
						if(taskID == -2)
						{
							showingZipsFiles = true;
							showZipsButton.displayString = MwoUtil.translate("gui.selectWorld.showZips.disable");
							worlds.addAll(SaveFormatHelper.getZippedSaveList(ResourcesHelper.savesDir, isaveformat));
						}
						else
						{
							showingZipsFiles = false;
							showZipsButton.displayString = MwoUtil.translate("gui.selectWorld.showZips.enable");
						}
						parent.worlds = worlds;
						parent.mwoInfos = SaveFormatHelper.getMwoInfosList(ResourcesHelper.savesDir, isaveformat);
					}
					catch (AnvilConverterException anvilconverterexception)
					{
						MoreWorldOptions.log.err("Couldn\'t load level list : " + anvilconverterexception);
						parent.mc.displayGuiScreen(new GuiErrorScreen("Unable to load worlds", anvilconverterexception.getMessage()));
				        return;
					}
				    Collections.sort(parent.worlds);
				    Collections.sort(parent.mwoInfos);
				}
				parent.endLoading();
				parent.statusDisplayCounter = 0;
				if(taskID == 1)
				{
					parent.setCopyStatus(I18n.format("gui.selectWorld.unzip.success", taskData), ColorHelper.GRASSGREEN);
			    	parent.setDefaultDisplayCooldown();
				}
			} 
	        catch (Exception e)
			{
		        AdditionnalErrorInfo add = AdditionnalErrorInfo.createAddionnalInfo("Operation on worlds, status when errored : " + GuiSelectWorldWithOptions.this.copyStatus, e);
		        ErrorsManager.thrownError("RESS_LOAD&WORLD_LIST_LOADER&TASK", "WorldsListLoader.run() with taskID " +  taskID, add);
				parent.mc.displayGuiScreen(new GuiErrorScreen("Error occured in " + GuiSelectWorldWithOptions.this.copyStatus + ", operation were stopped", e.toString()));
			}
		}
    }
    
//	================================== MoreWorldOptions END ==================================
}
