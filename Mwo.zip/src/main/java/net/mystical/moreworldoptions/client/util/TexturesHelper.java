package net.mystical.moreworldoptions.client.util;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;

import com.google.common.collect.Lists;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreenResourcePacks;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.client.renderer.texture.ITextureObject;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.resources.IResourcePack;
import net.minecraft.client.resources.ResourcePackListEntry;
import net.minecraft.client.resources.ResourcePackListEntryFound;
import net.minecraft.client.resources.ResourcePackRepository;
import net.minecraft.client.resources.ResourcePackRepository.Entry;
import net.minecraft.client.resources.data.PackMetadataSection;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.mystical.moreworldoptions.mod.MoreWorldOptions;


@SideOnly(Side.CLIENT)
public class TexturesHelper
{
	public static boolean arePacksDifferentsWithMcPacks(List<Entry> usedResourcePacks, Minecraft mc)
	{
		List<Entry> repo = mc.getResourcePackRepository().getRepositoryEntries();
		if(repo.size() != usedResourcePacks.size()) return true;
		for(Entry repoEntry : repo)
		{
			if(!usedResourcePacks.contains(repoEntry)) return true;
		}
		for(Entry usedEntry : usedResourcePacks)
		{
			if(!repo.contains(usedEntry)) return true;
		}
		return false;
	}
	
	public static void loadResourcePacks(List<Entry> usedResourcePacks, Minecraft mc) throws IOException
	{
		Collections.reverse(usedResourcePacks);
        mc.getResourcePackRepository().setRepositories(usedResourcePacks);
        mc.gameSettings.resourcePacks.clear();
        mc.gameSettings.incompatibleResourcePacks.clear();

        for (Entry resourcepackrepository$entry : usedResourcePacks)
        {
        	MoreWorldOptions.log.info("Pack entry " + resourcepackrepository$entry + " name is " + resourcepackrepository$entry.getResourcePackName());
            mc.gameSettings.resourcePacks.add(resourcepackrepository$entry.getResourcePackName());

            if (resourcepackrepository$entry.func_183027_f() != 1)
            {
                mc.gameSettings.incompatibleResourcePacks.add(resourcepackrepository$entry.getResourcePackName());
            }
        }
        mc.gameSettings.saveOptions();
        mc.refreshResources();
	}
	
	/**
	 * This class helps to load textures who aren't in the mod jar file but in another file, for example, in the screenshots folder, it will load the texture represented by the ResourceLocation path
	 * The texture can be in any sub-folder of the .minecraft folder
	 */
	public static class ExternalTexture extends AbstractTexture
	{
	    protected final ResourceLocation textureLocation;
	
	    public ExternalTexture(ResourceLocation textureResourceLocation)
	    {
	        this.textureLocation = textureResourceLocation;
	    }
	
	    @Override
	    public void loadTexture(IResourceManager resourceManager) throws IOException
	    {
	        this.deleteGlTexture();
	        InputStream inputstream = null;
	        File file = new File(textureLocation.getResourcePath());
	        
	        try
	        {
	            inputstream = new FileInputStream(file);
	            BufferedImage bufferedimage = TextureUtil.readBufferedImage(inputstream);
	            boolean flag = false;
	            boolean flag1 = false;
	
	            TextureUtil.uploadTextureImageAllocate(this.getGlTextureId(), bufferedimage, flag, flag1);
	        }
	        finally
	        {
	            if (inputstream != null)
	            {
	                inputstream.close();
	            }
	        }
	    }
	    
		/**
		 * Binds the specified texture, can accept external textures (which domain is "external")
		 * 
		 * @param manager The texture manager to bind the texture
		 * @param resource The texture resource location
		 */
	    public static void bindOptionnalExternalTexture(TextureManager manager, ResourceLocation resource)
	    {
	    	if(resource.getResourceDomain().equalsIgnoreCase("external"))
			{
		        Object object = manager.getTexture(resource);
		
		        if (object == null)
		        {
		            object = new ExternalTexture(resource);
		            manager.loadTexture(resource, (ITextureObject)object);
		        }
			}
	    	manager.bindTexture(resource);
	    }
	}
}