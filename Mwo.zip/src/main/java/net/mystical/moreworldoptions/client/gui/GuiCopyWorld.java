package net.mystical.moreworldoptions.client.gui;

import java.io.File;
import java.io.IOException;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.resources.I18n;
import net.minecraft.world.WorldType;
import net.minecraft.world.storage.ISaveFormat;
import net.minecraftforge.fml.client.config.GuiCheckBox;
import net.mystical.moreworldoptions.client.util.ResourcesHelper;
import net.mystical.moreworldoptions.util.MwoUtil;
import net.mystical.moreworldoptions.util.MwoUtil.ColorHelper;

public class GuiCopyWorld extends GuiScreen
{
	private GuiSelectWorldWithOptions parent;
	private String fileName;
	
	private GuiTextField worldName;
	private String newName;
	
	private GuiCheckBox zipWorld;
	private GuiCheckBox deleteOld;
	
	public GuiCopyWorld(GuiSelectWorldWithOptions parent, String originalWorldFileName)
	{
		this.parent = parent;
		this.fileName = originalWorldFileName;
		this.newName = getUncollidingSaveDirName(originalWorldFileName, false);
	}

	@Override
    public void updateScreen()
    {
        this.worldName.updateCursorCounter();
    }
	
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks)
	{
        this.drawDefaultBackground();
        this.drawCenteredString(this.fontRendererObj, I18n.format("gui.copyWorld.title"), this.width / 2, 20, -1);
        
        this.drawString(this.fontRendererObj, I18n.format("gui.copyWorld.enterName"), this.width / 2 - 100, 47, -6250336);
        this.drawString(this.fontRendererObj, I18n.format("gui.copyWorld.oldName") + " " + this.fileName, this.width / 2 - 100, 85, -6250336);
        this.drawString(this.fontRendererObj, I18n.format("selectWorld.resultFolder") + " " + this.newName, this.width / 2 - 100, 100, ColorHelper.TURQUOISEBLUE.getValue());
        
        this.worldName.drawTextBox();
        
        super.drawScreen(mouseX, mouseY, partialTicks);
	}
	
	@Override
	public void initGui()
	{
        Keyboard.enableRepeatEvents(true);
        
		worldName = new GuiTextField(0, fontRendererObj, width / 2 - 100, 60, 200, 20);
		worldName.setFocused(true);
		worldName.setText(fileName);
		
		buttonList.add(new GuiButton(1, this.width / 2 - 155, this.height - 28, 150, 20, I18n.format("gui.selectWorld.copy")));
		buttonList.add(new GuiButton(2, this.width / 2 + 5, this.height - 28, 150, 20, I18n.format("gui.cancel")));
		
		buttonList.add(zipWorld = new GuiCheckBox(3, width / 2 - 100, 130, I18n.format("gui.copyWorld.zip"), false));
		buttonList.add(deleteOld = new GuiCheckBox(4, width / 2 - 100, 150, I18n.format("gui.copyWorld.deleteOld"), false));
		deleteOld.visible = false;
	}
	
	@Override
	protected void keyTyped(char typedChar, int keyCode) throws IOException
	{
		worldName.textboxKeyTyped(typedChar, keyCode);
		newName = getUncollidingSaveDirName(worldName.getText(), true);
		((GuiButton)this.buttonList.get(0)).enabled = newName.length() > 0;
	}

	@Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException
    {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        this.worldName.mouseClicked(mouseX, mouseY, mouseButton);
    }
	
	@Override
	protected void actionPerformed(GuiButton button) throws IOException
	{
		if(button.id == 1)
		{
			parent.launchWorldCopy(fileName, newName, zipWorld.isChecked(), deleteOld.isChecked());
			mc.displayGuiScreen(parent);
		}
		else if(button.id == 2)
		{
			mc.displayGuiScreen(parent);
		}
		else if(button.id == 3)
		{
			deleteOld.setIsChecked(false);
			deleteOld.visible = zipWorld.isChecked();
			newName = getUncollidingSaveDirName(worldName.getText(), true);
		}
		else if(button.id == 4)
		{
			newName = getUncollidingSaveDirName(worldName.getText(), true);
		}
	}

	@Override
    public void onGuiClosed()
    {
        Keyboard.enableRepeatEvents(false);
    }
	
    public String getUncollidingSaveDirName(String name, boolean guiInitialized)
    {
		name = name.trim();
		if(MwoUtil.isStringEmpty(name))
		{
			name = fileName + "-copy";
		}
        name = name.replaceAll("[\\./\"]", "_");
        for (String s : GuiCreateWorldWithOptions.disallowedFilenames)
        {
            if (name.equalsIgnoreCase(s))
            {
                name = "_" + name + "_";
            }
        }
        
        final String old = name;
		int index = 0;
		File fi2;
		do
		{
			name = old + (index == 0 ? "" : "-" + index) + (guiInitialized && zipWorld.isChecked() ? ".zip" : "");
			fi2 = new File(ResourcesHelper.savesDir, name);
			index++;
		}
		while(fi2.exists());
        return name;
    }
}
