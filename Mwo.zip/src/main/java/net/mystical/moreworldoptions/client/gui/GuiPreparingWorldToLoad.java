package net.mystical.moreworldoptions.client.gui;

import java.util.List;

import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraft.client.resources.I18n;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.mystical.moreworldoptions.util.MwoWorldInfo;
import net.mystical.moreworldoptions.util.MwoWorldInfo.ModInformation;

public class GuiPreparingWorldToLoad extends GuiScreen
{
	private final GuiScreen superParent;
	private final GuiSelectWorldWithOptions parent;
	private final MwoWorldInfo info;
	
	private final String saveName;
	
	public GuiPreparingWorldToLoad(GuiScreen superParent, GuiSelectWorldWithOptions parent, MwoWorldInfo info, String worldSaveName)
	{
		this.superParent = superParent;
		this.parent = parent;
		
		this.info = info;
		this.saveName = worldSaveName;
	}
	
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks)
	{
    	mc.loadingScreen.resetProgressAndMessage(I18n.format("gui.comparingMods.title", saveName));
    	mc.loadingScreen.displayLoadingString(I18n.format("gui.comparingMods.comparing"));
    	
    	List<ModInformation> changed = info.getLostAndNewMods();
    	if(!changed.isEmpty())
    	{
    		mc.displayGuiScreen(new GuiWorldLoadingWarning(saveName, info.fileName, changed, info, parent));
    		return;
    	}
		
    	mc.loadingScreen.resetProgressAndMessage(I18n.format("gui.loadingPacks.title", saveName));
    	mc.loadingScreen.displayLoadingString(I18n.format("gui.loadingPacks.comparing"));
    	boolean mustLoad = info.arePacksDifferentsWithMc(mc);
    	if(mustLoad)
    	{
    		if(info.getResourcePacks().isEmpty())
    		{
    			mc.loadingScreen.displayLoadingString(I18n.format("gui.loadingPacks.loading.vanilla"));
    		}
    		else if(info.getResourcePacks().size() == 1)
    		{
    			mc.loadingScreen.displayLoadingString(I18n.format("gui.loadingPacks.loading.off1", info.getResourcePacks().get(0).getResourcePackName()));
    		}
    		else
    		{
    			mc.loadingScreen.displayLoadingString(I18n.format("gui.loadingPacks.loading.off2", "" + info.getResourcePacks().size()));
    		}
	    	info.loadResourcesPacks(mc);
    	}
    	mc.loadingScreen.resetProgressAndMessage(I18n.format("gui.loadingPacks.launching"));
    	mc.loadingScreen.displayLoadingString("");
    	FMLClientHandler.instance().tryLoadExistingWorld(new GuiSelectWorld(this.superParent), info.fileName, saveName);
	}
}
