package net.mystical.moreworldoptions.client.util;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.mystical.moreworldoptions.util.MwoUtil.ColorHelper;
import net.mystical.moreworldoptions.util.error.AdditionnalErrorInfo;
import net.mystical.moreworldoptions.util.error.ErrorsManager;

@SideOnly(Side.CLIENT)
public class KeyInterpretor<V>
{
	private ColorHelper[] colors = new ColorHelper[] {ColorHelper.IMPERIALGREEN, ColorHelper.ORANGE, ColorHelper.BLOODRED};
	
	private EnumEntryType type;
	private V value;
	private float[] properties;
	
	private KeyInterpretorListener<V> listener = null;
	
	/**
	* 0 = ok, 1 = in edit, 2 = errored
	*/
	private int state;
	
	private KeyInterpretor(EnumEntryType type, V value, float minNb, float maxNb)
	{
		this.type = type;
		this.value = value;
		this.setProperties(new float[] {minNb, maxNb});
	}
	
	public static KeyInterpretor<Integer> newNumberInterpretor(int actual, int minNb, int maxNb)
	{
		return new KeyInterpretor(EnumEntryType.NUMBER, actual, minNb, maxNb);
	}
	
	public static KeyInterpretor<Float> newNumberInterpretor(float actual, float minNb, float maxNb)
	{
		return new KeyInterpretor(EnumEntryType.FLOAT, actual, minNb, maxNb);
	}
	
	public static KeyInterpretor<Integer> newImpairNumberInterpretor(int actual, int minNb, int maxNb)
	{
		return new KeyInterpretor(EnumEntryType.NUMBER_IMPAIR, actual, minNb, maxNb);
	}
	
	public static KeyInterpretor<String> newStringInterpretor(String actual)
	{
		return new KeyInterpretor(EnumEntryType.STRING, actual, 0, 0);
	}
	
	public void keyTyped(char typedChar, int keyCode)
	{
		try 
		{
			this.processKey(typedChar, keyCode);
		}
		catch (Exception e) 
		{
			AdditionnalErrorInfo add = AdditionnalErrorInfo.createAddionnalInfo("KeyInterpretor ; info : -Key being typed : " + typedChar + " (code : " + keyCode + ") ; -Interpretor type : " + this.type.getTypeId(), e);
			ErrorsManager.thrownError("KEY_INTERPRETOR_KEY_PROCESSS", "KeyInterpretor.keyTyped", add);
			
			this.state = 2;
		}
	}
	
	public void processKey(char typedChar, int keyCode) throws Exception
	{
		/** Equals ENTER key */
		if(keyCode == 28 || keyCode == 156)
		{
		   this.stopEdit();
		}
        else if(this.isInEdit())
        {
    		String e = String.valueOf(typedChar);
        	//Not an number but must be an number
        	if(this.type.isNumber() && (!(e.matches("[0-9]") || e.equals("-"))) && keyCode != 14) // keyCode 14 = backSpace
        	{
        		this.state = 3;
        	}
        	else
        	{
        		if(this.type.isNumber())
				{
        			if(keyCode == 14) //Delete key
        			{
        				if(this.type.isFloat())
        				{
        					Float currentVal = (Float) value;
	        				if(currentVal >= 10)
	        				{
	        					currentVal /= 10;
	        					value = (V) currentVal;
	        				}
	        				else
	        				{
	        					currentVal = 0F;
	        					value = (V) currentVal;
	        				}
        				}
        				else
        				{
        					Integer currentVal = (Integer) value;
        					if(currentVal >= 10)
        					{
        						currentVal /= 10;
        						value = (V) currentVal;
        					}
        					else
        					{
        						currentVal = 0;
        						value = (V) currentVal;
        					}
        				}
        			}
        			else if(this.type.isFloat())
        			{
        				this.insertFloat(e);
        			}
        			else
        			{
        				this.insertInt(e);
        			}
				}
        		else if(this.type.isString())
        		{
        			if(this.isAcceptedStringLetter(typedChar) || keyCode == 14)
        			{
	        			String i = (String) value;
	        			
						if(keyCode == 14) //Delete key
						{
							if(i != null && !i.isEmpty())
							{
								i = i.substring(0, i.length() - 1);
							}
						}
						else
						{
							i += e;
						}
						
	        			value = (V) i;
	        			this.state = 1;
        			}
        			else
        			{
        				this.state = 3;
        			}
        		}
        		
        		if(this.listener != null)
        		{
        			this.listener.onValueChanged(value);
        		}
        	}
        }
	}
	
	private boolean isAcceptedStringLetter(char c)
	{
		return Character.isLetterOrDigit(c) || "+-*/=(){}_ ><\"'^$€&,;:!?.#".contains(Character.toString(c).subSequence(0, 1));
	}
	
	private void insertFloat(String typedFloat)
	{
		Float currentVal = (Float) value;
		if(typedFloat.equals("-"))
		{
			if(currentVal == 0F) currentVal = 1F;
			currentVal *= -1;
			this.value = (V) currentVal;
		}
		else
		{
			if(currentVal > 0)
			{
				Float b = Float.parseFloat(typedFloat);
				
				if(currentVal >= 1)
				{
					currentVal *= 10;
				}
				currentVal += b;
				value = (V) currentVal;
			}
			else
			{
				Float b = Float.parseFloat(typedFloat);
				b /= 10;
				
				value = (V) b;
			}
		}
		currentVal = (Float) value;
		if(currentVal > getProperties()[1]) //Max
		{
			currentVal = getProperties()[1];
			value = (V) currentVal;
		}
		else if(currentVal < getProperties()[0]) //Min
		{
			currentVal = getProperties()[0];
			value = (V) currentVal;
		}
		this.state = 1;
	}
	
	private void insertInt(String typedInt)
	{
		Integer currentVal = (Integer) value;
		if(typedInt.equals("-"))
		{
			if(currentVal == 0) currentVal = 1;
			currentVal *= -1;
			this.value = (V) currentVal;
		}
		else
		{
			Integer b = Integer.parseInt(typedInt);
			if(currentVal >= 0)
			{
				if(currentVal >= 1)
				{
					currentVal *= 10;
				}
				currentVal += b;
			}
			else
			{
				if(currentVal <= -1)
				{
					currentVal *= 10;
				}
				currentVal -= b;
			}
			value = (V) currentVal;
		}
		
		currentVal = (Integer) value;
		if(currentVal > getProperties()[1]) //Max
		{
			currentVal = (int) getProperties()[1];
			value = (V) currentVal;
		}
		else if(currentVal < getProperties()[0]) //Min
		{
			currentVal = (int) getProperties()[0];
			value = (V) currentVal;
		}
		this.state = 1;
		
		if(this.type.isImpair())
		{
			String h = String.valueOf(value);
			if(h.endsWith("2") || h.endsWith("4") || h.endsWith("6") || h.endsWith("8"))
			{
				this.state = 3;
			}
		}
	}
	
	@Override
	public String toString()
	{
		return value.toString();
	}
	
	public String getStringRepresentation()
	{
		return value.toString();
	}
	
	public int getAppropriateColor()
	{
		if(state >= colors.length)
		{
			return colors[2].getValue();
		}
		return colors[state].getValue();
	}
	
	public void setValue(V value)
	{
		this.value = value;
	}

	public V getValue() 
	{
		return value;
	}
	
	public void startEdit(boolean resetValue)
	{
		this.state = 1;
		if(resetValue)
		{
			this.resetValue();
		}
		if(this.listener != null)
		{
			this.listener.onEditStart(value);
		}
	}
	
	public void resetValue()
	{
		if(this.type.isFloat())
		{
			this.value = (V) (Float) 0F;
		}
		else if(this.type.isNumber())
		{
			this.value = (V) (Integer) 0;
		}
		else if(this.type.isString())
		{
			this.value = (V) "";
		}
		
		if(this.listener != null)
		{
			this.listener.onValueChanged(value);
		}
	}
	
	public void stopEdit()
	{
		int old = this.state;
		this.state = 0;
		if(this.listener != null && old != 0)
		{
			this.listener.onEditFinished(value);
		}
	}
	
	public void setProperties(float[] fs)
	{
		this.properties = fs;
	}
	
	public float[] getProperties()
	{
		return properties;
	}
	
	public void setListener(KeyInterpretorListener<V> listener)
	{
		this.listener = listener;
	}
	
	public void setColorForNormalState(ColorHelper color)
	{
		this.colors[0] = color;
	}
	
	public void setColorForEditState(ColorHelper color)
	{
		this.colors[1] = color;
	}
	
	public void setColorForErrorState(ColorHelper color)
	{
		this.colors[2] = color;
	}
	
	public boolean isInEdit()
	{
		return state != 0;
	}
	
	private enum EnumEntryType
	{
		NUMBER(0, true),
		NUMBER_IMPAIR(1, true),
		STRING(2, false),
		FLOAT(3, true);
		
		private int id;
		private boolean isNumber;
		
		private EnumEntryType(int id, boolean isNumber)
		{
			this.id = id;
			this.isNumber = isNumber;
		}
		
		public int getTypeId()
		{
			return id;
		}
		
		public boolean isNumber()
		{
			return this.isNumber;
		}
		
		public boolean isFloat()
		{
			return this.isTypeEqual(FLOAT);
		}
		
		public boolean isImpair()
		{
			return this.isTypeEqual(NUMBER_IMPAIR);
		}
		
		public boolean isString()
		{
			return !this.isNumber;
		}
		
		private boolean isTypeEqual(EnumEntryType other)
		{
			return other.id == this.id;
		}
	}
	
	/**
	 * An simple listener for listen changes made in an KeyInterpretor
	 *
	 * @param <V> The type of the value
	 */
	public static abstract class KeyInterpretorListener<V>
	{
		/**
		 * Called on edit start
		 * 
		 * @param value The current value of this editor
		 */
		public abstract void onEditStart(V value);
		
		/**
		 * Called when this edit is finished, by the user or when stopEdit is called into the gui, only if the was in edit (state != 0) before of this
		 * 
		 * @param value The current value of this editor
		 */
		public abstract void onEditFinished(V value);
		
		/**
		 * Called when the value changes, when the user modify the value
		 * 
		 * @param value The current value of this editor
		 */
		public abstract void onValueChanged(V value);
	}
}