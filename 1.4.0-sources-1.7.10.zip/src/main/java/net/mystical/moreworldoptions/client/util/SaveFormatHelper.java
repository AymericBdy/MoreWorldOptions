package net.mystical.moreworldoptions.client.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.commons.lang3.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.io.Files;

import net.minecraft.client.AnvilConverterException;
import net.minecraft.nbt.CompressedStreamTools;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.storage.ISaveFormat;
import net.minecraft.world.storage.SaveFormatComparator;
import net.minecraft.world.storage.WorldInfo;
import net.mystical.moreworldoptions.mod.MoreWorldOptions;
import net.mystical.moreworldoptions.util.MwoWorldInfo;
import net.mystical.moreworldoptions.util.WorldSaveFormatComparatorCompressable;

public class SaveFormatHelper
{
	public static void loadWorldsDataLists(List<WorldSaveFormatComparatorCompressable> summaries, List<MwoWorldInfo> infos, boolean withZips, File savesDirectory, ISaveFormat format) throws AnvilConverterException
	{
		if (savesDirectory != null && savesDirectory.exists() && savesDirectory.isDirectory())
        {
            File[] afile = savesDirectory.listFiles();
            for (File saveFile : afile)
            {
                String fileName = saveFile.getName();
                if (saveFile.isDirectory())
                {
                    WorldInfo worldinfo = format.getWorldInfo(fileName);
                    if (worldinfo != null && (worldinfo.getSaveVersion() == 19132 || worldinfo.getSaveVersion() == 19133))
                    {
                        boolean flag = worldinfo.getSaveVersion() != 19133;//this.getSaveVersion();
                        String worldName = worldinfo.getWorldName();
                        if (StringUtils.isEmpty(worldName)) worldName = fileName;
                        long size;
                        try
						{
							size = ResourcesHelper.calculateDirectoryLength(saveFile);
						} 
                        catch (IOException e)
						{
							MoreWorldOptions.log.err("An error occured calculating length of world file " + saveFile + ": " + e.toString());
							e.printStackTrace();
							size = -404L;
						}
                        summaries.add(new WorldSaveFormatComparatorCompressable(fileName, worldinfo, size / 1024 /* Size in octects to size in ko */, flag, false));
    					infos.add(getMwoWorldInfo(saveFile, fileName, worldinfo));
                    }
                }
                else if(withZips && Files.getFileExtension(fileName).equals("zip"))
                {
                	WorldInfo worldinfo;
					try
					{
						worldinfo = getWorldInfoForZippedWorld(savesDirectory, format, fileName);
					}
					catch (Exception e)
					{
						e.printStackTrace();
						throw new AnvilConverterException("An error occured reading zipped worlds data for save " + fileName + ", error: " + e);
					}
                    if (worldinfo != null && (worldinfo.getSaveVersion() == 19132 || worldinfo.getSaveVersion() == 19133))
                    {
                        boolean flag = worldinfo.getSaveVersion() != 19133;//this.getSaveVersion();
                        String worldName = worldinfo.getWorldName();
                        if (StringUtils.isEmpty(worldName)) worldName = fileName;
                        summaries.add(new WorldSaveFormatComparatorCompressable(fileName, worldinfo, saveFile.length() / 1024 /* Size in octects to size in ko */, flag, true));
                    }
                }
            }
        }
        else
			throw new AnvilConverterException("Unable to read or access folder where game worlds are saved!");
	}
    
    public static WorldInfo getWorldInfoForZippedWorld(File savesDirectory, ISaveFormat format, String saveName) throws IOException
    {
        File file1 = new File(savesDirectory, saveName);
        File to = new File(savesDirectory, "level.dat");
        
    	ZipFile file = new ZipFile(file1);
    	ZipEntry entry = file.getEntry("level.dat");
    	if(entry == null)
    	{
    		ZipEntry entr;
    		Enumeration<? extends ZipEntry> enu = file.entries();
    		while(enu.hasMoreElements())
    		{
    			entr = enu.nextElement();
    			if(entr.getName().contains("level.dat"))
    			{
    				entry = entr;
    				break;
    			}
    		}
    		if(entry == null)
    		{
	    		file.close();
	    		MoreWorldOptions.log.err("Cannot find the level.dat file of the zipped world : " + saveName + ", searching for level.dat_old"); 
    		}
    	}
    	if(entry != null)
    	{
	    	ResourcesHelper.dezipZipEntry(file, entry, savesDirectory, 2);
	    	file.close();
	        if (to.exists())
	        {
	            try
	            {
	                NBTTagCompound nbttagcompound2 = CompressedStreamTools.readCompressed(new FileInputStream(to));
	                NBTTagCompound nbttagcompound3 = nbttagcompound2.getCompoundTag("Data");
	                to.delete();
	                return new WorldInfo(nbttagcompound3);
	            }
	            catch (Exception exception1)
	            {
	            	MoreWorldOptions.log.err("Exception reading " + to + ". Error : " + exception1);
	            }
	        }
	    }

        to = new File(savesDirectory, "level.dat_old");
    	file = new ZipFile(file1);
    	entry = file.getEntry("level.dat_old");
    	if(entry == null)
    	{
    		ZipEntry entr;
    		Enumeration<? extends ZipEntry> enu = file.entries();
    		while(enu.hasMoreElements())
    		{
    			entr = enu.nextElement();
    			if(entr.getName().contains("level.dat_old"))
    			{
    				entry = entr;
    				break;
    			}
    		}
    		if(entry == null)
    		{
	    		file.close();
	    		MoreWorldOptions.log.err("Cannot find the level.dat_old file of the zipped world : " + saveName + ", world corrupted or unknow error occured"); 
    		}
    	}
    	if(entry != null)
    	{
	    	ResourcesHelper.dezipZipEntry(file, entry, savesDirectory, 2);
	    	file.close();
	        if (to.exists())
	        {
	            try
	            {
	                NBTTagCompound nbttagcompound = CompressedStreamTools.readCompressed(new FileInputStream(to));
	                NBTTagCompound nbttagcompound1 = nbttagcompound.getCompoundTag("Data");
	                to.delete();
	                return new WorldInfo(nbttagcompound1);
	            }
	            catch (Exception exception)
	            {
	            	MoreWorldOptions.log.err("Exception reading " + to + ". Error : " + exception);
	            }
	        }
    	}
        return null;
    }
    
    public static void renameWorldAndWorldFile(ISaveFormat format, String dirName, String newWorldName, String newWorldFileName)
    {
    	File file1 = new File(ResourcesHelper.savesDir, dirName);
        if (file1.exists())
        {
            File file2 = new File(file1, "level.dat");
            File file3 = new File(ResourcesHelper.savesDir, newWorldFileName);
            if (file2.exists())
            {
                try
                {
                    NBTTagCompound nbttagcompound = CompressedStreamTools.readCompressed(new FileInputStream(file2));
                    NBTTagCompound nbttagcompound1 = nbttagcompound.getCompoundTag("Data");
                    nbttagcompound1.setString("LevelName", newWorldName);
                    CompressedStreamTools.writeCompressed(nbttagcompound, new FileOutputStream(file2));
                    
                    if(!file3.exists())
                    	file1.renameTo(file3);
                }
                catch (Exception exception)
                {
                    exception.printStackTrace();
                }
            }
        }
    }
    
    public static MwoWorldInfo getMwoWorldInfo(File saveFile, String saveName, WorldInfo info)
    {
        File inf = new File(saveFile, "MwoWorldData.dat");
        if (inf.exists())
        {
            try
            {
                NBTTagCompound nbttagcompound2 = CompressedStreamTools.readCompressed(new FileInputStream(inf));
                NBTTagCompound nbttagcompound3 = nbttagcompound2.getCompoundTag("WorldInformations");
                return MwoWorldInfo.createAndLoadFromNBT(nbttagcompound3, saveName, info.getLastTimePlayed());
            }
            catch (Exception exception1)
            {
            	MoreWorldOptions.log.err("Exception reading " + inf + ". Error : " + exception1);
            }
        }
    	return MwoWorldInfo.createForExistingWorld(saveName, info.getLastTimePlayed());
    }
    
    public static boolean saveMwoWorldInfoTo(MwoWorldInfo info, File savesDirectory, ISaveFormat format, String saveName) throws IOException
    {
    	File file1 = new File(savesDirectory, saveName);
        File inf = new File(file1, "MwoWorldData.dat");
        if(inf.exists()) inf.delete();
        inf.createNewFile();
        try
        {
        	NBTTagCompound tag = new NBTTagCompound();
        	info.writeToNBT(tag);
        	NBTTagCompound tag2 = new NBTTagCompound();
        	tag2.setTag("WorldInformations", tag);
        	CompressedStreamTools.writeCompressed(tag2, new FileOutputStream(inf));
            return true;
        }
        catch (Exception exception1)
        {
        	MoreWorldOptions.log.err("Exception writing " + inf + ". Error : " + exception1);
        	return false;
        }
    }
}
