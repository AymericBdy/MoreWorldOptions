package net.mystical.moreworldoptions.client.gui;

import java.io.File;
import java.io.IOException;

import org.lwjgl.input.Keyboard;

import cpw.mods.fml.common.ObfuscationReflectionHelper;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiErrorScreen;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.resources.I18n;
import net.minecraft.world.storage.ISaveFormat;
import net.minecraft.world.storage.ISaveHandler;
import net.minecraft.world.storage.WorldInfo;
import net.mystical.moreworldoptions.client.util.ResourcesHelper;
import net.mystical.moreworldoptions.client.util.SaveFormatHelper;
import net.mystical.moreworldoptions.mod.MoreWorldOptions;
import net.mystical.moreworldoptions.util.MwoUtil;
import net.mystical.moreworldoptions.util.MwoWorldInfo;

public class GuiModifyWorld extends GuiScreen
{
	private GuiScreen parentScreen;
    private GuiTextField nameField;
    private final String oldWorldFileName;
    
    private String newWorldName;
    private String newFileName;
    
    private final MwoWorldInfo info;
    
    private GuiTextField description;
    private GuiButton buttonCommands;
    private GuiButton saveButton;
    
    private boolean externalGuiOpened;

    public GuiModifyWorld(GuiScreen parentScreenIn, String saveNameIn, MwoWorldInfo info)
    {
        this.parentScreen = parentScreenIn;
        this.oldWorldFileName = info.fileName;
        this.newWorldName = saveNameIn;
        this.newFileName = getUncollidingSaveDirName(info.fileName, info.fileName, true);
        
        this.info = info;
    }

    /**
     * Called from the main game loop to update the screen.
     */
    public void updateScreen()
    {
        this.nameField.updateCursorCounter();
        this.description.updateCursorCounter();
    }

    /**
     * Adds the buttons (and other controls) to the screen in question. Called when the GUI is displayed and when the
     * window resizes, the buttonList is cleared beforehand.
     */
    public void initGui()
    {
        Keyboard.enableRepeatEvents(true);
        this.buttonList.clear();
        ISaveFormat isaveformat = this.mc.getSaveLoader();
        WorldInfo worldinfo = mc.isSingleplayer() ? mc.getIntegratedServer().getEntityWorld().getWorldInfo() : isaveformat.getWorldInfo(this.oldWorldFileName);
        if(worldinfo == null)
        {
        	MoreWorldOptions.log.fatal("World info for world " + this.oldWorldFileName + " cannot be found !");
        	mc.displayGuiScreen(new GuiErrorScreen("The world info for this world cannot be found !", "World file name " + this.oldWorldFileName));
        	return;
        }
        //String s = worldinfo.getWorldName();
        int middle = this.width / 2;

        this.buttonList.add(new GuiButton(52, 4, 4, 20, 20, MwoUtil.translate("back.arrow")));
        
        GuiButton button;
        this.buttonList.add(buttonCommands = new GuiButton(8, middle - 202, this.height - 48, I18n.format(worldinfo.areCommandsAllowed() ? "gui.modifyWorld.disableCommands" : "gui.modifyWorld.enableCommands")));
        this.buttonList.add(button = new GuiButton(7, middle - 202, this.height - 24, I18n.format("selectWorld.recreate")));
        button.enabled = mc.theWorld == null;
        this.buttonList.add(new GuiButton(2, middle + 2, this.height - 48, I18n.format("gui.modifyWorld.customizePacks")));
        this.buttonList.add(saveButton = new GuiButton(1, middle + 2, this.height - 24, I18n.format("gui.save")));
        
        if(!externalGuiOpened)
        {
            this.nameField = new GuiTextField(this.fontRendererObj, middle - 100, 60, 200, 20);
            this.nameField.setText(oldWorldFileName);
            nameField.setEnabled(mc.theWorld == null);
            
	        this.description = new GuiTextField(fontRendererObj, middle - 125, 160, 250, 20);
	        description.setMaxStringLength(500);
	        description.setText(info.getDescription());
        }
        else externalGuiOpened = false;
    }

    /**
     * Called when the screen is unloaded. Used to disable keyboard repeat events
     */
    public void onGuiClosed()
    {
        Keyboard.enableRepeatEvents(false);
    }

    /**
     * Called by the controls from the buttonList when activated. (Mouse pressed for buttons)
     */
    protected void actionPerformed(GuiButton button)
    {
        if (button.enabled)
        {
            if (button.id == 1) //Save/rename
            {
            	description.setText(description.getText().trim());
            	if(!description.getText().equals(info.getDescription()))
            	{
                	info.setDescription(description.getText());
                	info.save(mc);
            	}
            	if(!oldWorldFileName.equals(newFileName))
            	{
                    ISaveFormat isaveformat = this.mc.getSaveLoader();
                    SaveFormatHelper.renameWorldAndWorldFile(isaveformat, this.oldWorldFileName, this.newWorldName, this.newFileName);
            	}
                this.mc.displayGuiScreen(this.parentScreen);
            }
            /*else if (button.id == 0)
            {
            	info.setDescription(description.getText().trim());
            	info.save(mc);
                ISaveFormat isaveformat = this.mc.getSaveLoader();
                SaveFormatHelper.renameWorldAndWorldFile(isaveformat, this.oldWorldFileName, this.newWorldName, this.newFileName);
                this.mc.displayGuiScreen(this.parentScreen);
            }*/
            else if(button.id == 2) //Customize packs
            {
            	externalGuiOpened = true;
            	mc.displayGuiScreen(new GuiCustomizePacks(this, info));
            }
            else if (button.id == 7) //Recreate
            {
            	GuiCreateWorldWithOptions guicreateworld = new GuiCreateWorldWithOptions(this);
                ISaveHandler isavehandler = this.mc.getSaveLoader().getSaveLoader(this.oldWorldFileName, false);
                WorldInfo worldinfo = isavehandler.loadWorldInfo();
                isavehandler.flush();
                guicreateworld.recreateFromExistingWorld(worldinfo);
            	externalGuiOpened = true;
                this.mc.displayGuiScreen(guicreateworld);
            }
            else if(button.id == 8) //Disable/enable commands
            {
                ISaveHandler isavehandler = this.mc.getSaveLoader().getSaveLoader(this.oldWorldFileName, false);
                WorldInfo worldinfo = isavehandler.loadWorldInfo();
                boolean allow = !worldinfo.areCommandsAllowed();
                //worldinfo.setAllowCommands(!worldinfo.areCommandsAllowed());
                ObfuscationReflectionHelper.setPrivateValue(WorldInfo.class, worldinfo, allow, "allowCommands");
                isavehandler.saveWorldInfo(worldinfo);
                
                if(mc.theWorld != null) ObfuscationReflectionHelper.setPrivateValue(WorldInfo.class, mc.theWorld.getWorldInfo(), allow, "allowCommands");
                if(mc.isSingleplayer()) ObfuscationReflectionHelper.setPrivateValue(WorldInfo.class, mc.getIntegratedServer().getEntityWorld().getWorldInfo(), allow, "allowCommands");
                
                buttonCommands.displayString = I18n.format(worldinfo.areCommandsAllowed() ? "gui.modifyWorld.disableCommands" : "gui.modifyWorld.enableCommands");
            }
            else if(button.id == 52) //Cancel
            {
            	this.mc.displayGuiScreen(this.parentScreen);
            }
        }
    }

    /**
     * Fired when a key is typed (except F11 which toggles full screen). This is the equivalent of
     * KeyListener.keyTyped(KeyEvent e). Args : character (character on the key), keyCode (lwjgl Keyboard key code)
     */
    protected void keyTyped(char typedChar, int keyCode)
    {
        this.nameField.textboxKeyTyped(typedChar, keyCode);
        newWorldName = this.nameField.getText().trim();
        newFileName = getUncollidingSaveDirName(this.nameField.getText().trim(), oldWorldFileName, true);
        ((GuiButton)this.buttonList.get(0)).enabled = newFileName.length() > 0 && newWorldName.length() > 0;
        
        description.textboxKeyTyped(typedChar, keyCode);
        this.updateSaveButtonText();
    }
    
    public void updateSaveButtonText()
    {
    	boolean descChange = !description.getText().trim().equals(info.getDescription());
    	boolean nameChange = !oldWorldFileName.equals(newFileName);
    	if(descChange && nameChange)
    	{
    		saveButton.displayString = MwoUtil.translate("gui.modifyWorld.renameAndSave");
    	}
    	else if(nameChange)
    	{
    		saveButton.displayString = MwoUtil.translate("selectWorld.renameButton");
    	}
    	else
    	{
    		saveButton.displayString = MwoUtil.translate("gui.save");
    	}
    }

    /**
     * Called when the mouse is clicked. Args : mouseX, mouseY, clickedButton
     */
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton)
    {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        this.nameField.mouseClicked(mouseX, mouseY, mouseButton);
        
        description.mouseClicked(mouseX, mouseY, mouseButton);
    }

    /**
     * Draws the screen and all the components in it. Args : mouseX, mouseY, renderPartialTicks
     */
    public void drawScreen(int mouseX, int mouseY, float partialTicks)
    {
        int middle = this.width / 2;
        this.drawDefaultBackground();
        
        this.drawCenteredString(this.fontRendererObj, I18n.format("gui.modifyWorld.title", oldWorldFileName), middle, 20, 16777215);
        this.drawString(this.fontRendererObj, I18n.format("selectWorld.enterName"), middle - 100, 47, 16777215);
        this.drawString(this.fontRendererObj, I18n.format("gui.selectWorld.newWorldName", newWorldName), middle - 130, 90, 10526880);
        this.drawString(this.fontRendererObj, I18n.format("gui.selectWorld.newFileName", newFileName), middle - 130, 105, 10526880);
        this.nameField.drawTextBox();
        
        this.drawString(fontRendererObj, I18n.format("gui.selectWorld.saveDescription"), this.width / 2 - 120, 145, 10526880);
        this.description.drawTextBox();
        
        super.drawScreen(mouseX, mouseY, partialTicks);
        this.drawRect(middle - 125, 129, middle + 125, 130, -00000001);
    }
    
    public static String getUncollidingSaveDirName(String name, String originalWorldName, boolean oldSaveWillBeDeleted)
    {
    	name = name.trim();
		if(MwoUtil.isStringEmpty(name))
		{
			name = "Copy of " + originalWorldName;
		}
        name = name.replaceAll("[\\./\"]", "_");
        for (String s : GuiCreateWorldWithOptions.disallowedFilenames)
        {
            if (name.equalsIgnoreCase(s))
            {
                name = "_" + name + "_";
            }
        }
        
        String old = name;
		int index = 0;
		File fi2;
		do
		{
			name = old + (index == 0 ? "" : "-" + index);
			fi2 = new File(ResourcesHelper.savesDir, name);
			index++;
		}
		while(fi2.exists() && (!oldSaveWillBeDeleted || !name.equalsIgnoreCase(originalWorldName)));
        return name;
    }
}
