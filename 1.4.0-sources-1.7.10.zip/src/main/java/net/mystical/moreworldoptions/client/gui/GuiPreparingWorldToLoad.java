package net.mystical.moreworldoptions.client.gui;

import java.util.List;

import cpw.mods.fml.client.FMLClientHandler;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraft.client.resources.I18n;
import net.minecraft.world.WorldSettings;
import net.mystical.moreworldoptions.util.MwoWorldInfo;
import net.mystical.moreworldoptions.util.MwoWorldInfo.ModInformation;

public class GuiPreparingWorldToLoad extends GuiScreen
{
	private final GuiScreen superParent;
	private final Object parentOrSettings;
	private final MwoWorldInfo info;
	
	private final String saveName;
	
	/**
	 * Will do all things to load a world
	 */
	public GuiPreparingWorldToLoad(GuiScreen superParent, GuiSelectWorldWithOptions parent, MwoWorldInfo info, String worldSaveName)
	{
		this.superParent = superParent;
		this.parentOrSettings = parent;
		
		this.info = info;
		this.saveName = worldSaveName;
	}
	/**
	 * Will do all thing to create a world
	 */
	public GuiPreparingWorldToLoad(GuiScreen superParent, WorldSettings settings, MwoWorldInfo info, String worldSaveName)
	{
		this.superParent = superParent;
		this.parentOrSettings = settings;
		
		this.info = info;
		this.saveName = worldSaveName;
	}
	
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks)
	{
    	mc.loadingScreen.resetProgressAndMessage(I18n.format("gui.comparingMods.title", saveName));
    	mc.loadingScreen.resetProgresAndWorkingMessage(I18n.format("gui.comparingMods.comparing"));
    	
    	List<ModInformation> changed = info.getLostAndNewMods();
    	if(!changed.isEmpty())
    	{
    		mc.displayGuiScreen(new GuiWorldLoadingWarning(saveName, info.fileName, changed, info, (GuiSelectWorldWithOptions) parentOrSettings));
    		return;
    	}
		
    	mc.loadingScreen.resetProgressAndMessage(I18n.format("gui.loadingPacks.title", saveName));
    	mc.loadingScreen.resetProgresAndWorkingMessage(I18n.format("gui.loadingPacks.comparing"));
    	boolean mustLoad = info.arePacksDifferentsWithMc(mc);
    	if(mustLoad)
    	{
    		if(info.getResourcePacks().isEmpty())
    		{
    			mc.loadingScreen.resetProgresAndWorkingMessage(I18n.format("gui.loadingPacks.loading.vanilla"));
    		}
    		else if(info.getResourcePacks().size() == 1)
    		{
    			mc.loadingScreen.resetProgresAndWorkingMessage(I18n.format("gui.loadingPacks.loading.off1", info.getResourcePacks().get(0).getResourcePackName()));
    		}
    		else
    		{
    			mc.loadingScreen.resetProgresAndWorkingMessage(I18n.format("gui.loadingPacks.loading.off2", "" + info.getResourcePacks().size()));
    		}
	    	info.loadResourcesPacks(mc);
    	}
    	mc.loadingScreen.resetProgressAndMessage(I18n.format("gui.loadingPacks.launching"));
    	mc.loadingScreen.resetProgresAndWorkingMessage("");
    	if(parentOrSettings instanceof WorldSettings)
    		this.mc.launchIntegratedServer(info.fileName, saveName, (WorldSettings) parentOrSettings);
    	else
    		FMLClientHandler.instance().tryLoadExistingWorld(new GuiSelectWorld(this.superParent), info.fileName, saveName);
	}
}
