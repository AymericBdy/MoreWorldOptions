package net.mystical.moreworldoptions.client.util;

import static org.lwjgl.opengl.GL11.GL_ALPHA_TEST;
import static org.lwjgl.opengl.GL11.GL_BLEND;
import static org.lwjgl.opengl.GL11.GL_COLOR_BUFFER_BIT;
import static org.lwjgl.opengl.GL11.GL_DEPTH_TEST;
import static org.lwjgl.opengl.GL11.GL_GREATER;
import static org.lwjgl.opengl.GL11.GL_LEQUAL;
import static org.lwjgl.opengl.GL11.GL_LIGHTING;
import static org.lwjgl.opengl.GL11.GL_ONE_MINUS_SRC_ALPHA;
import static org.lwjgl.opengl.GL11.GL_SRC_ALPHA;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.glAlphaFunc;
import static org.lwjgl.opengl.GL11.glBlendFunc;
import static org.lwjgl.opengl.GL11.glClear;
import static org.lwjgl.opengl.GL11.glClearColor;
import static org.lwjgl.opengl.GL11.glDepthFunc;
import static org.lwjgl.opengl.GL11.glDisable;
import static org.lwjgl.opengl.GL11.glEnable;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.Thread.UncaughtExceptionHandler;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.imageio.ImageIO;

import org.apache.logging.log4j.Level;
import org.lwjgl.LWJGLException;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.Drawable;
import org.lwjgl.opengl.SharedDrawable;

import cpw.mods.fml.client.SplashProgress;
import cpw.mods.fml.common.FMLLog;
import cpw.mods.fml.common.ObfuscationReflectionHelper;
import cpw.mods.fml.common.ProgressManager;
import cpw.mods.fml.common.ProgressManager.ProgressBar;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.client.renderer.texture.ITextureObject;
import net.minecraft.client.renderer.texture.SimpleTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.resources.ResourcePackRepository.Entry;
import net.minecraft.util.ResourceLocation;
import net.mystical.moreworldoptions.client.gui.CustomLoadingScreen;;


@SideOnly(Side.CLIENT)
public class TexturesHelper
{
	private static Drawable d;
    private static final Lock lock = new ReentrantLock(true);
    private static boolean done;
    private static Semaphore mutex;
    
	public static boolean arePacksDifferentsWithMcPacks(List<Entry> usedResourcePacks, Minecraft mc)
	{
		List<Entry> repo = mc.getResourcePackRepository().getRepositoryEntries();
		if(repo.size() != usedResourcePacks.size()) return true;
		for(Entry repoEntry : repo)
		{
			if(!usedResourcePacks.contains(repoEntry)) return true;
		}
		for(Entry usedEntry : usedResourcePacks)
		{
			if(!repo.contains(usedEntry)) return true;
		}
		return false;
	}
	
	public static void loadResourcePacks(List<Entry> usedResourcePacks, final Minecraft mc) throws IOException
	{
		Collections.reverse(usedResourcePacks);
        mc.getResourcePackRepository().func_148527_a(usedResourcePacks);
        mc.gameSettings.resourcePacks.clear();
        //mc.gameSettings.incompatibleResourcePacks.clear();

        int progress = 5;
        for (Entry resourcepackrepository$entry : usedResourcePacks)
        {
            ((CustomLoadingScreen)mc.loadingScreen).setLoadingProgress(progress, false);
            mc.gameSettings.resourcePacks.add(resourcepackrepository$entry.getResourcePackName());
            /*if (resourcepackrepository$entry.func_183027_f() != 1)
            	mc.gameSettings.incompatibleResourcePacks.add(resourcepackrepository$entry.getResourcePackName());*/
            if(progress > 15)
            	progress = 15;
        }
        mc.gameSettings.saveOptions();
        ((CustomLoadingScreen)mc.loadingScreen).setLoadingProgress(20, false);
        done = false;
        final int totalSize = 80;
        Thread thread = new Thread(new Runnable()
        {
        	private int lastProgress = 0;
        	
            public void run()
            {
                setGL();
                while(!done)
                {
                    ProgressBar first = null, second = null, third = null;
                    Iterator<ProgressBar> i = ProgressManager.barIterator();
                    while(i.hasNext())
                    {
                    	ProgressBar b = i.next();
                        if(first == null) first = b;
                        else if(second == null) second = b;
                        else if(third == null) third = b;
                    }
                    glClear(GL_COLOR_BUFFER_BIT);
                    glEnable(GL_TEXTURE_2D);
                    if(third != null)
                    {
	                    float factor = totalSize / third.getSteps();
	                    lastProgress = (int) (third.getStep() * factor);
	                }
                    // We use mutex to indicate safely to the main thread that we're taking the display global lock
                    // So the main thread can skip processing messages while we're updating.
                    // There are system setups where this call can pause for a while, because the GL implementation
                    // is trying to impose a framerate or other thing is occurring. Without the mutex, the main
                    // thread would delay waiting for the same global display lock
                    mutex.acquireUninterruptibly();
                    if(!(mc.loadingScreen instanceof CustomLoadingScreen))
                    	mc.loadingScreen = new CustomLoadingScreen(mc);
                    ((CustomLoadingScreen)mc.loadingScreen).setLoadingProgress(20 + lastProgress, false);
                    //Display.update();
                    // As soon as we're done, we release the mutex. The other thread can now ping the processmessages
                    // call as often as it wants until we get get back here again
                    mutex.release();
                    Display.sync(60);
                }
                clearGL();
            }
            private void setGL()
            {
                lock.lock();
                try
                {
                    Display.getDrawable().makeCurrent();
                }
                catch (LWJGLException e)
                {
                    e.printStackTrace();
                    throw new RuntimeException("[&2] LWJGL error making drawable context as current ! " + e);
                }
                //glClearColor((float)((backgroundColor >> 16) & 0xFF) / 0xFF, (float)((backgroundColor >> 8) & 0xFF) / 0xFF, (float)(backgroundColor & 0xFF) / 0xFF, 1);
                glDisable(GL_LIGHTING);
                glDisable(GL_DEPTH_TEST);
                glEnable(GL_BLEND);
                glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            }
            private void clearGL()
            {
                Minecraft mc = Minecraft.getMinecraft();
                mc.displayWidth = Display.getWidth();
                mc.displayHeight = Display.getHeight();
                mc.resize(mc.displayWidth, mc.displayHeight);
                glClearColor(1, 1, 1, 1);
                glEnable(GL_DEPTH_TEST);
                glDepthFunc(GL_LEQUAL);
                glEnable(GL_ALPHA_TEST);
                glAlphaFunc(GL_GREATER, .1f);
                try
                {
                    Display.getDrawable().releaseContext();
                }
                catch (LWJGLException e)
                {
                    e.printStackTrace();
                    throw new RuntimeException("[&3] LWJGL error releasing drawable context from loading render thread ! " + e);
                }
                finally
                {
                    lock.unlock();
                }
            }
        });
        thread.setUncaughtExceptionHandler(new UncaughtExceptionHandler()
        {
            public void uncaughtException(Thread t, Throwable e)
            {
                FMLLog.log(Level.ERROR, e, "Packs loading listener thread Exception");
            }
        });
        try
		{
			try
			{
				mutex = ObfuscationReflectionHelper.getPrivateValue(SplashProgress.class, SplashProgress.class.newInstance(), "mutex");
			} 
			catch (Exception e)
			{
				e.printStackTrace();
				throw new RuntimeException("Cannot get the mutex of the SplashProgress, so cannot update the progress bar ! " + e.toString());
			}
        	d = new SharedDrawable(Display.getDrawable());
			Display.getDrawable().releaseContext();
			d.makeCurrent();
	        ((CustomLoadingScreen)mc.loadingScreen).startReloadTextures();
	        thread.start();
		} 
        catch (LWJGLException e2)
		{
			e2.printStackTrace();
			throw new RuntimeException("[&1] LWJGL exception releasing the drawable context ! " + e2.toString());
		}
        mc.refreshResources();        
        if(!(mc.loadingScreen instanceof CustomLoadingScreen))
        	mc.loadingScreen = new CustomLoadingScreen(mc);
        ((CustomLoadingScreen)mc.loadingScreen).endReloadTextures();
        done = true;
        try
		{
			thread.join(10000);
		} 
        catch (InterruptedException e1) {}
        try
		{
        	d.releaseContext();
			Display.getDrawable().makeCurrent();
		} 
        catch (LWJGLException e1)
		{
        	e1.printStackTrace();
            throw new RuntimeException("[&4] LWJGL exception giving the drawable context to the main thread ! " + e1.toString());
		}
        if(!(mc.loadingScreen instanceof CustomLoadingScreen))
        	mc.loadingScreen = new CustomLoadingScreen(mc);
        ((CustomLoadingScreen)mc.loadingScreen).setLoadingProgress(100, true);
	}
	
	/**
	 * This class helps to load textures who aren't in the mod jar file but in another file, for example, in the screenshots folder, it will load the texture represented by the ResourceLocation path
	 * The texture can be in any sub-folder of the .minecraft folder
	 */
	public static class ExternalTexture extends AbstractTexture
	{
	    protected final ResourceLocation textureLocation;
	
	    public ExternalTexture(ResourceLocation textureResourceLocation)
	    {
	        this.textureLocation = textureResourceLocation;
	    }
	
	    @Override
	    public void loadTexture(IResourceManager resourceManager) throws IOException
	    {
	        this.deleteGlTexture();
	        InputStream inputstream = null;
	        File file = new File(textureLocation.getResourcePath());
	        
	        try
	        {
	            inputstream = new FileInputStream(file);
	            BufferedImage bufferedimage = ImageIO.read(inputstream);//TextureUtil.readBufferedImage(inputstream);
	            boolean flag = false;
	            boolean flag1 = false;
	
	            TextureUtil.uploadTextureImageAllocate(this.getGlTextureId(), bufferedimage, flag, flag1);
	        }
	        finally
	        {
	            if (inputstream != null)
	            {
	                inputstream.close();
	            }
	        }
	    }
	    
		/**
		 * Binds the specified texture, can accept external textures (which domain is "external")
		 * 
		 * @param manager The texture manager to bind the texture
		 * @param resource The texture resource location
		 */
	    public static void bindOptionnalExternalTexture(TextureManager manager, ResourceLocation resource)
	    {
	    	if(resource.getResourceDomain().equalsIgnoreCase("external"))
			{
		        Object object = manager.getTexture(resource);
		
		        if (object == null)
		        {
		            object = new ExternalTexture(resource);
		            manager.loadTexture(resource, (ITextureObject)object);
		        }
			}	
	    	manager.bindTexture(resource);
	    }
	}
	/**
	 * Gets a unique gl texture id for the specified resource, didn't affected by the reloading of resources
	 * Do not forgot to delete the id after use
	 */
    public static int getUniqueTextureIdFor(TextureManager manager, ResourceLocation resource) throws IOException
    {
    	SimpleTexture object = new SimpleTexture(resource);
        object.loadTexture(Minecraft.getMinecraft().getResourceManager());
        return object.getGlTextureId();
    }
}