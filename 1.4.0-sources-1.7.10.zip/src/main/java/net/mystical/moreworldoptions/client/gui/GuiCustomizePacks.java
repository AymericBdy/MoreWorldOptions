package net.mystical.moreworldoptions.client.gui;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.Sys;

import com.google.common.collect.Lists;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiOptionButton;
import net.minecraft.client.gui.GuiResourcePackAvailable;
import net.minecraft.client.gui.GuiResourcePackSelected;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.resources.IResourcePack;
import net.minecraft.client.resources.ResourcePackListEntry;
import net.minecraft.client.resources.ResourcePackRepository;
import net.minecraft.client.resources.ResourcePackRepository.Entry;
import net.minecraft.util.Util;
import net.mystical.moreworldoptions.client.util.ResourcePackListEntryDefaultSp;
import net.mystical.moreworldoptions.client.util.ResourcePackListEntryFoundSp;
import net.mystical.moreworldoptions.client.util.ResourcePackListEntrySp;
import net.mystical.moreworldoptions.mod.MoreWorldOptions;
import net.mystical.moreworldoptions.util.MwoUtil;
import net.mystical.moreworldoptions.util.MwoWorldInfo;

public class GuiCustomizePacks extends GuiScreen
{
	private static final Logger logger = LogManager.getLogger();
    private final GuiScreen parentScreen;
    private List<ResourcePackListEntry> availableResourcePacks;
    private List<ResourcePackListEntry> selectedResourcePacks;
    /** List component that contains the available resource packs */
    private GuiResourcePackAvailable availableResourcePacksList;
    /** List component that contains the selected resource packs */
    private GuiResourcePackSelected selectedResourcePacksList;
    private boolean changed = false;
    
    private final MwoWorldInfo info;
    private final List<Entry> bakedSelectedPacks;

	public GuiCustomizePacks(GuiScreen parent, MwoWorldInfo info)
	{
		this.parentScreen = parent;
		this.info = info;
		this.bakedSelectedPacks = info.getResourcePacks();
	}
	public GuiCustomizePacks(GuiScreen parent, List<Entry> packs)
	{
		this.parentScreen = parent;
		this.info = null;
		this.bakedSelectedPacks = packs;
	}
	
    /**
     * Adds the buttons (and other controls) to the screen in question. Called when the GUI is displayed and when the
     * window resizes, the buttonList is cleared beforehand.
     */
    public void initGui()
    {
        this.buttonList.add(new GuiOptionButton(2, this.width / 2 - 154, this.height - 48, I18n.format("resourcePack.openFolder", new Object[0])));
        this.buttonList.add(new GuiOptionButton(1, this.width / 2 + 4, this.height - 48, I18n.format("gui.done", new Object[0])));
		this.buttonList.add(new GuiButton(0, 4, 4, 20, 20, MwoUtil.translate("back.arrow")));

        if (!this.changed)
        {
            this.availableResourcePacks = Lists.<ResourcePackListEntry>newArrayList();
            this.selectedResourcePacks = Lists.<ResourcePackListEntry>newArrayList();
            ResourcePackRepository resourcepackrepository = this.mc.getResourcePackRepository();
            resourcepackrepository.updateRepositoryEntriesAll();
            List<ResourcePackRepository.Entry> list = Lists.newArrayList(resourcepackrepository.getRepositoryEntriesAll());
            list.removeAll(bakedSelectedPacks);

            for (ResourcePackRepository.Entry resourcepackrepository$entry : list)
            {
                this.availableResourcePacks.add(new ResourcePackListEntryFoundSp(this, resourcepackrepository$entry));
            }
            for(Entry entry : bakedSelectedPacks)
            {
            	this.selectedResourcePacks.add(new ResourcePackListEntryFoundSp(this, entry));
            }

            this.selectedResourcePacks.add(new ResourcePackListEntryDefaultSp(this));
        }

        this.availableResourcePacksList = new GuiResourcePackAvailable(this.mc, 200, this.height, this.availableResourcePacks);
        this.availableResourcePacksList.setSlotXBoundsFromLeft(this.width / 2 - 4 - 200);
        this.availableResourcePacksList.registerScrollButtons(7, 8);
        this.selectedResourcePacksList = new GuiResourcePackSelected(this.mc, 200, this.height, this.selectedResourcePacks);
        this.selectedResourcePacksList.setSlotXBoundsFromLeft(this.width / 2 + 4);
        this.selectedResourcePacksList.registerScrollButtons(7, 8);
    }

    /**
     * Handles mouse input.
     */
    public void handleMouseInput()
    {
        super.handleMouseInput();
        //this.selectedResourcePacksList.handleMouseInput();
        //this.availableResourcePacksList.handleMouseInput();
    }

    public boolean hasResourcePackEntry(ResourcePackListEntrySp resourcePackListEntrySp)
    {
        return this.selectedResourcePacks.contains(resourcePackListEntrySp);
    }

    public List<ResourcePackListEntry> getListContaining(ResourcePackListEntrySp p_146962_1_)
    {
        return this.hasResourcePackEntry(p_146962_1_) ? this.selectedResourcePacks : this.availableResourcePacks;
    }

    public List<ResourcePackListEntry> getAvailableResourcePacks()
    {
        return this.availableResourcePacks;
    }

    public List<ResourcePackListEntry> getSelectedResourcePacks()
    {
        return this.selectedResourcePacks;
    }

    /**
     * Called by the controls from the buttonList when activated. (Mouse pressed for buttons)
     */
    protected void actionPerformed(GuiButton button)
    {
        if (button.enabled)
        {
            if (button.id == 2)
            {
                File file1 = this.mc.getResourcePackRepository().getDirResourcepacks();
                String s = file1.getAbsolutePath();

                if (Util.getOSType() == Util.EnumOS.OSX)
                {
                    try
                    {
                        logger.info(s);
                        Runtime.getRuntime().exec(new String[] {"/usr/bin/open", s});
                        return;
                    }
                    catch (IOException ioexception1)
                    {
                        logger.error((String)"Couldn\'t open file", (Throwable)ioexception1);
                    }
                }
                else if (Util.getOSType() == Util.EnumOS.WINDOWS)
                {
                    String s1 = String.format("cmd.exe /C start \"Open file\" \"%s\"", new Object[] {s});

                    try
                    {
                        Runtime.getRuntime().exec(s1);
                        return;
                    }
                    catch (IOException ioexception)
                    {
                        logger.error((String)"Couldn\'t open file", (Throwable)ioexception);
                    }
                }

                boolean flag = false;

                try
                {
                    Class<?> oclass = Class.forName("java.awt.Desktop");
                    Object object = oclass.getMethod("getDesktop", new Class[0]).invoke((Object)null, new Object[0]);
                    oclass.getMethod("browse", new Class[] {URI.class}).invoke(object, new Object[] {file1.toURI()});
                }
                catch (Throwable throwable)
                {
                    logger.error("Couldn\'t open link", throwable);
                    flag = true;
                }

                if (flag)
                {
                    logger.info("Opening via system class!");
                    Sys.openURL("file://" + s);
                }
            }
            else if(button.id == 1)
            {
                if (this.changed)
                {
                	List<Entry> list = new ArrayList<Entry>();
                	for(ResourcePackListEntry entry : this.selectedResourcePacks)
                	{
                		if(entry instanceof ResourcePackListEntryFoundSp)
                		{
                			list.add(((ResourcePackListEntryFoundSp)entry).func_148318_i());
                		}
                	}
            		bakedSelectedPacks.clear();
            		bakedSelectedPacks.addAll(list);
                	if(info != null)
                	{
	                	info.save(mc);
	                	if(mc.theWorld != null) //Running
	                	{
	                		mc.loadingScreen = new CustomLoadingScreen(mc);
	                		mc.loadingScreen.resetProgressAndMessage(I18n.format("gui.loadingPacks.title", info.fileName));
	                    	mc.loadingScreen.resetProgresAndWorkingMessage(I18n.format("gui.loadingPacks.comparing"));
	                    	boolean mustLoad = info.arePacksDifferentsWithMc(mc);
	                    	if(mustLoad)
	                    	{
	                    		if(info.getResourcePacks().isEmpty())
	                    		{
	                    			mc.loadingScreen.resetProgresAndWorkingMessage(I18n.format("gui.loadingPacks.loading.vanilla"));
	                    		}
	                    		else if(info.getResourcePacks().size() == 1)
	                    		{
	                    			mc.loadingScreen.resetProgresAndWorkingMessage(I18n.format("gui.loadingPacks.loading.off1", info.getResourcePacks().get(0).getResourcePackName()));
	                    		}
	                    		else
	                    		{
	                    			mc.loadingScreen.resetProgresAndWorkingMessage(I18n.format("gui.loadingPacks.loading.off2", "" + info.getResourcePacks().size()));
	                    		}
	                	    	info.loadResourcesPacks(mc);
	                    	}
	                    	mc.loadingScreen.resetProgressAndMessage("");
	                    	mc.loadingScreen.resetProgresAndWorkingMessage("");
	                	}
                	}
                }
                this.mc.displayGuiScreen(this.parentScreen);
            }
            else if(button.id == 0)
            {
            	this.mc.displayGuiScreen(this.parentScreen);
            }
        }
    }

    /**
     * Called when the mouse is clicked. Args : mouseX, mouseY, clickedButton
     */
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton)
    {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        this.availableResourcePacksList.func_148179_a(mouseX, mouseY, mouseButton);
        this.selectedResourcePacksList.func_148179_a(mouseX, mouseY, mouseButton);
    }

    @Override
    protected void mouseMovedOrUp(int mouseX, int mouseY, int mouseButton) 
    {
    	super.mouseMovedOrUp(mouseX, mouseY, mouseButton);
        this.availableResourcePacksList.func_148181_b(mouseX, mouseY, mouseButton);
        this.selectedResourcePacksList.func_148181_b(mouseX, mouseY, mouseButton);
    }

    /**
     * Draws the screen and all the components in it. Args : mouseX, mouseY, renderPartialTicks
     */
    public void drawScreen(int mouseX, int mouseY, float partialTicks)
    {
        this.drawBackground(0);
        this.availableResourcePacksList.drawScreen(mouseX, mouseY, partialTicks);
        this.selectedResourcePacksList.drawScreen(mouseX, mouseY, partialTicks);
        this.drawCenteredString(this.fontRendererObj, I18n.format("customizePack.title", new Object[0]), this.width / 2, 16, 16777215);
        //this.drawCenteredString(this.fontRendererObj, I18n.format("resourcePack.folderInfo", new Object[0]), this.width / 2 - 77, this.height - 26, 8421504);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    /**
     * Marks the selected resource packs list as changed to trigger a resource reload when the screen is closed
     */
    public void markChanged()
    {
        this.changed = true;
    }
}
