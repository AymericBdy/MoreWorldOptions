package net.mystical.moreworldoptions.client.gui;

import java.util.ArrayList;
import java.util.List;

import cpw.mods.fml.common.Loader;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiErrorScreen;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;
import net.mystical.moreworldoptions.util.MwoUtil;
import net.mystical.moreworldoptions.util.MwoUtil.ColorHelper;
import net.mystical.moreworldoptions.util.MwoWorldInfo;
import net.mystical.moreworldoptions.util.MwoWorldInfo.ModInformation;

public class GuiWorldLoadingWarning extends GuiScreen
{
	private final String worldName;
	private final String worldFileName;
	
	private final int compatibility;
	private MwoWorldInfo info;
	
	private final GuiSelectWorldWithOptions parent;
	private final List<ModInformation> lostAndNewMods;
	
	private ListSection lostSection = null;
	private ListSection changedSection = null;
	private ListSection newsSection = null;
	
	public GuiWorldLoadingWarning(String worldName, String worldFileName, int compatibility, MwoWorldInfo info, GuiSelectWorldWithOptions parent)
	{
		this.worldName = worldName;
		this.worldFileName = worldFileName;
		this.compatibility = compatibility;
		this.info = info;
		
		this.parent = parent;
		parent.hasStartedToLoadAWorld = false;
		
		this.lostAndNewMods = null;
	}
	
	public GuiWorldLoadingWarning(String worldName, String worldFileName, List<ModInformation> lostAndNewMods, MwoWorldInfo info, GuiSelectWorldWithOptions parent)
	{
		this.worldName = worldName;
		this.worldFileName = worldFileName;
		this.compatibility = -10;
		this.info = info;
		
		this.parent = parent;
		parent.hasStartedToLoadAWorld = false;
		
		this.lostAndNewMods = lostAndNewMods;
	}
	
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks)
	{
		this.drawDefaultBackground();
		
		if(compatibility == -10)
		{
			String line = I18n.format("warning.modPack.change");
			this.drawCenteredString(fontRendererObj, line, width / 2, 40, ColorHelper.ELECTRICALBLUE.getValue());
			
			int y = 80;
			if(lostSection != null)
			{
				lostSection.draw(fontRendererObj, this.width / 2, y, 16777215, 8421504);
				y += lostSection.getSectionHeight();
			}
			if(changedSection != null)
			{
				changedSection.draw(fontRendererObj, this.width / 2, y, 16777215, 8421504);
				y += changedSection.getSectionHeight();
			}
			if(newsSection != null)
			{
				newsSection.draw(fontRendererObj, this.width / 2, y, 16777215, 8421504);
				y += newsSection.getSectionHeight();
			}
		}
		else if(compatibility == -2)
		{
			String line = I18n.format("warning.incompatibility." + compatibility + ".1");
			this.drawCenteredString(fontRendererObj, line, width / 2, 40, 16777215);
			
			line = MwoUtil.translate("warning.incompatibility." + compatibility + ".2");
			this.drawCenteredString(fontRendererObj, line, width / 2, 60, 8421504);
			
			line = MwoUtil.translate("warning.incompatibility." + compatibility + ".3");
			this.drawCenteredString(fontRendererObj, line, width / 2, 90, 8421504);
		}
		else
		{
			String line = I18n.format("warning.incompatibility." + compatibility + ".1", info.getMcVersion(), Loader.MC_VERSION);
			this.drawCenteredString(fontRendererObj, line, width / 2, 40, 16777215);
			
			line = I18n.format("warning.incompatibility." + compatibility + ".2", worldName);
			this.drawCenteredString(fontRendererObj, line, width / 2, 60, 8421504);
			
			line = MwoUtil.translate("warning.incompatibility." + compatibility + ".3");
			this.drawCenteredString(fontRendererObj, line, width / 2, 90, 8421504);
		}
		
		super.drawScreen(mouseX, mouseY, partialTicks);
	}
	
	@Override
	public void initGui()
	{
		super.initGui();
		
		int yPos = height - 40;
		
		String text = MwoUtil.translate("warning.loadAnyway");
		int len = fontRendererObj.getStringWidth(text) + 6;
		
		String text1 = MwoUtil.translate("warning.copy");
		int len1 = fontRendererObj.getStringWidth(text1) + 6;
		
		this.buttonList.add(new GuiButton(0, width / 2 - len - 4, yPos, len, 20, text));
		this.buttonList.add(new GuiButton(1, width / 2, yPos, len1, 20, text1));
		this.buttonList.add(new GuiButton(2, 4, 4, 20, 20, MwoUtil.translate("back.arrow")));
		
		if(compatibility == -10)
		{
			lostSection = null;
			changedSection = null;
			newsSection = null;
			int width = this.width / 4 * 3;
			for(ModInformation inf : lostAndNewMods)
			{
				if(inf.status == -1)
				{
					if(lostSection == null) lostSection = new ListSection(I18n.format("warning.mods.lost.title"), fontRendererObj).setMaxComponentWidth(width);
					lostSection.addElement("- " + inf.toString());
				}
				else if(inf.status == 0)
				{
					if(changedSection == null) changedSection = new ListSection(I18n.format("warning.mods.changed.title"), fontRendererObj).setMaxComponentWidth(width);
					changedSection.addElement("- " + inf.toString());
				}
				else if(inf.status == 1)
				{
					if(newsSection == null) newsSection = new ListSection(I18n.format("warning.mods.new.title"), fontRendererObj).setMaxComponentWidth(width);
					newsSection.addElement("- " + inf.toString());
				}
			}
		}
	}
	
	@Override
	protected void actionPerformed(GuiButton button)
	{
		super.actionPerformed(button);
		
		switch (button.id)
		{
		case 0:
			mc.loadingScreen.resetProgressAndMessage(I18n.format("gui.selectWorld.launch.preparing"));
	    	mc.loadingScreen.resetProgresAndWorkingMessage(I18n.format("gui.selectWorld.launch.saveInfo"));
			if(compatibility == -2 || compatibility == -10) info.setDataToCurrentMcConfig();
			info.setMcVersion(Loader.MC_VERSION);
			info.save(mc);
	    	mc.loadingScreen.resetProgresAndWorkingMessage(I18n.format("gui.selectWorld.launching"));
			if (this.mc.getSaveLoader().canLoadWorld(worldFileName)) 
            {
				parent.loadAWorld();
            }
			else mc.displayGuiScreen(new GuiErrorScreen("The world " + worldFileName + " cannot be loaded by the Mc's save loader !", ""));
			break;
		case 1:
			parent.displayGuiCopyWorld(worldFileName);
			break;
		case 2:
			mc.displayGuiScreen(parent);
			break;
		}
	}
	
	public static class ListSection extends Gui
	{
		private final String title;
		private final FontRenderer fontRender;
		
		private final List<String> components = new ArrayList<String>();
		private int maxComponentWidth = 600;
		
		public ListSection(String title, FontRenderer fontRender)
		{
			this.title = title;
			this.fontRender = fontRender;
		}
		
		public ListSection setMaxComponentWidth(int maxComponentWidth)
		{
			this.maxComponentWidth = maxComponentWidth;
			return this;
		}
		
		public void addElement(String element)
		{
			List<String> lines = fontRender.listFormattedStringToWidth(element, maxComponentWidth);
			components.addAll(lines);
		}
		
		public int getSectionHeight()
		{
			return 16 + components.size() * 14 + 4;
		}
		
		public void draw(FontRenderer rend, int x, int y, int titleColor, int componentsColor)
		{
			this.drawCenteredString(rend, title, x, y, titleColor);
			y += 16;
			for(String line : components)
			{
				this.drawCenteredString(rend, line, x, y, componentsColor);
				y += 14;
			}
		}
	}
}
