package net.mystical.moreworldoptions.client.gui;

import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;

import org.lwjgl.opengl.GL11;

import com.sun.imageio.plugins.gif.GIFImageReader;

import cpw.mods.fml.client.FMLClientHandler;
import net.minecraft.client.LoadingScreenRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.util.ResourceLocation;
import net.mystical.moreworldoptions.client.util.TexturesHelper;
import net.mystical.moreworldoptions.mod.MoreWorldOptions;
import net.mystical.moreworldoptions.util.Properties;

public class CustomLoadingScreen extends LoadingScreenRenderer
{
    private String message = "";
    /** A reference to the Minecraft object. */
    private Minecraft mc;
    /** The text currently displayed (i.e. the argument to the last call to printText or func_73722_d) */
    private String currentlyDisplayedText = "";
    /** The system's time represented in milliseconds. */
    private long systemTime = Minecraft.getSystemTime();
    /** True if the loading ended with a success */
    private boolean loadingSuccess;
    private ScaledResolution scaledResolution;
    private Framebuffer framebuffer;
    
    private int glBackgroundTextureId;
    private int glFontTextureId;
    private final LoadingFontRenderer font;
    
    public static void checkInit(Minecraft mcIn)
    {
    	if(Properties.drawAnimatedLoadingGif && textIdArray == null)
		{
			try
			{
				GIFImageReader red = new GIFImageReader(null);
				InputStream in = Minecraft.getMinecraft().getResourceManager().getResource(loadingIcon).getInputStream();
				red.setInput(ImageIO.createImageInputStream(in));
				textIdArray = new int[red.getNumImages(true)];
				for(int index = 0 ; index < textIdArray.length ; index++)
				{
					textIdArray[index] = TextureUtil.glGenTextures();
					TextureUtil.uploadTextureImageAllocate(
							textIdArray[index], 
							red.read(index), 
							false, false); // 1er false, blur. 2eme false, clamp.
				}
				iconWidth = red.getWidth(0);
				iconHeight = red.getHeight(0);
				in.close();
			}
			catch (IOException e)
			{
				MoreWorldOptions.log.fatal("An IO Exception occured reading the loading gif image: " + e.toString());
				e.printStackTrace();
				mcIn.getTextureManager().bindTexture(loadingIcon);
				textIdArray = new int[] {mcIn.getTextureManager().getTexture(loadingIcon).getGlTextureId()};
				iconWidth = 142;
				iconHeight = 142;
			}
		}
    }

    public CustomLoadingScreen(Minecraft mcIn)
    {
    	super(mcIn);
        this.mc = mcIn;
        this.scaledResolution = new ScaledResolution(mcIn, mcIn.displayWidth, mcIn.displayHeight);
        this.framebuffer = new Framebuffer(mcIn.displayWidth, mcIn.displayHeight, false);
        this.framebuffer.setFramebufferFilter(9728);
        glBackgroundTextureId = -1;
        glFontTextureId = -1;
        font = new LoadingFontRenderer(this);
        
        checkInit(mcIn);
        System.out.println("FrameBuffer status: " + OpenGlHelper.isFramebufferEnabled());
    }

    /**
     * this string, followed by "working..." and then the "% complete" are the 3 lines shown. This resets progress to 0,
     * and the WorkingString to "working...".
     */
    @Override
    public void resetProgressAndMessage(String message)
    {
        this.loadingSuccess = false;
        this.func_73722_d(message);
    }
    /**
     * Shows the 'Saving level' string.
     */
    @Override
    public void displayProgressMessage(String message)
    {
        this.loadingSuccess = true;
        this.func_73722_d(message);
    }
    @Override
    public void func_73722_d(String message)
    {
        this.currentlyDisplayedText = message;

        GL11.glClear(GL11.GL_DEPTH_BUFFER_BIT);
        GL11.glMatrixMode(GL11.GL_PROJECTION);
        GL11.glLoadIdentity();
        if (OpenGlHelper.isFramebufferEnabled())
        {
            int i = this.scaledResolution.getScaleFactor();
            GL11.glOrtho(0.0D, (double)(this.scaledResolution.getScaledWidth() * i), (double)(this.scaledResolution.getScaledHeight() * i), 0.0D, 100.0D, 300.0D);
        }
        else
        {
            ScaledResolution scaledresolution = new ScaledResolution(this.mc, mc.displayWidth, mc.displayHeight);
            GL11.glOrtho(0.0D, scaledresolution.getScaledWidth_double(), scaledresolution.getScaledHeight_double(), 0.0D, 100.0D, 300.0D);
        }
        GL11.glMatrixMode(GL11.GL_MODELVIEW);
        GL11.glLoadIdentity();
        GL11.glTranslatef(0.0F, 0.0F, -200.0F);
    }

    /**
     * Displays a string on the loading screen supposed to indicate what is being done currently.
     */
    @Override
    public void resetProgresAndWorkingMessage(String message)
    {
    	this.systemTime = 0L;
        this.message = message;
        this.setLoadingProgress(-1, Properties.drawAnimatedLoadingGif);
        this.systemTime = 0L;
    }

    // Mwo
    private static final ResourceLocation loadingIcon = new ResourceLocation(Properties.modid.toLowerCase(), "textures/box.gif");
	protected static int[] textIdArray;
	private int counter = 0;
	protected static int iconWidth;
	protected static int iconHeight;
	
    /**
     * Updates the progress bar on the loading screen to the specified amount. Args: loadProgress
     * 
     * @param animate Will display 18 frames with 40ms between each (Thread.sleep(40)), to let the user watch the animated loading gif
     */
    public void setLoadingProgress(int progress, boolean animate)
    {
    	long i = Minecraft.getSystemTime();
        if (i - this.systemTime >= 100L)
        {
	        for(int g = 0 ; g <= (animate ? 18 : 1) ; g++) //80 frames in the current gif
	        {
	            this.systemTime = i;
	            ScaledResolution scaledresolution = new ScaledResolution(this.mc, mc.displayWidth, mc.displayHeight);
	            int scaleFactor = scaledresolution.getScaleFactor();
	            int width = scaledresolution.getScaledWidth();
	            int height = scaledresolution.getScaledHeight();
	
	            if (OpenGlHelper.isFramebufferEnabled()) this.framebuffer.framebufferClear();
	            else GL11.glClear(GL11.GL_DEPTH_BUFFER_BIT);
	
	            this.framebuffer.bindFramebuffer(false);
                GL11.glMatrixMode(GL11.GL_PROJECTION);
                GL11.glLoadIdentity();
                GL11.glOrtho(0.0D, scaledresolution.getScaledWidth_double(), scaledresolution.getScaledHeight_double(), 0.0D, 100.0D, 300.0D);
                GL11.glMatrixMode(GL11.GL_MODELVIEW);
                GL11.glLoadIdentity();
                GL11.glTranslatef(0.0F, 0.0F, -200.0F);
	
	            if (!OpenGlHelper.isFramebufferEnabled()) GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
	            
	            Tessellator tessellator = Tessellator.instance;
	            if (!FMLClientHandler.instance().handleLoadingScreen(scaledresolution)) //FML Don't render while FML's pre-screen is rendering
				{
					if(glBackgroundTextureId != -1)
						GL11.glBindTexture(GL11.GL_TEXTURE_2D, glBackgroundTextureId);
					else 
						this.mc.getTextureManager().bindTexture(Gui.optionsBackground);
				    float f = 32.0F;
				    tessellator.startDrawingQuads();
				    tessellator.setColorOpaque_I(4210752);
				    tessellator.addVertexWithUV(0.0D, (double)height, 0.0D, 0.0D, (double)((float)height / f));
				    tessellator.addVertexWithUV((double)width, (double)height, 0.0D, (double)((float)width / f), (double)((float)height / f));
				    tessellator.addVertexWithUV((double)width, 0.0D, 0.0D, (double)((float)width / f), 0.0D);
				    tessellator.addVertexWithUV(0.0D, 0.0D, 0.0D, 0.0D, 0.0D);
				    tessellator.draw();

				    if (progress >= 0)
				    {
				        byte b0 = 100;
				        byte b1 = 2;
				        int j1 = width / 2 - b0 / 2;
				        int k1 = height / 2 + 16;
				        GL11.glDisable(GL11.GL_TEXTURE_2D);
				        tessellator.startDrawingQuads();
				        tessellator.setColorOpaque_I(8421504);
				        tessellator.addVertex((double)j1, (double)k1, 0.0D);
				        tessellator.addVertex((double)j1, (double)(k1 + b1), 0.0D);
				        tessellator.addVertex((double)(j1 + b0), (double)(k1 + b1), 0.0D);
				        tessellator.addVertex((double)(j1 + b0), (double)k1, 0.0D);
				        tessellator.setColorOpaque_I(8454016);
				        tessellator.addVertex((double)j1, (double)k1, 0.0D);
				        tessellator.addVertex((double)j1, (double)(k1 + b1), 0.0D);
				        tessellator.addVertex((double)(j1 + progress), (double)(k1 + b1), 0.0D);
				        tessellator.addVertex((double)(j1 + progress), (double)k1, 0.0D);
				        tessellator.draw();
				        GL11.glEnable(GL11.GL_TEXTURE_2D);
				    }

				    GL11.glEnable(GL11.GL_BLEND);
				    OpenGlHelper.glBlendFunc(770, 771, 1, 0);
				    font.drawStringWithShadow(this.currentlyDisplayedText, ((width - font.getStringWidth(this.currentlyDisplayedText)) / 2), (height / 2 - 4 - 16), 16777215);
				    font.drawStringWithShadow(this.message, ((width - font.getStringWidth(this.message)) / 2), (height / 2 - 4 + 8), 16777215);
				}
	            
	            this.framebuffer.unbindFramebuffer();
	
	            if (OpenGlHelper.isFramebufferEnabled())
	            	this.framebuffer.framebufferRender(width * scaleFactor, height * scaleFactor);
	
	            if(Properties.drawAnimatedLoadingGif)
	            {
		            // Mwo
					counter++;
					if(counter >= textIdArray.length) counter = 0;
					GL11.glBindTexture(GL11.GL_TEXTURE_2D, textIdArray[counter]);
					
					GL11.glEnable(GL11.GL_ALPHA_TEST);
		            int f1 = 80;
					int x = (width - 70) * scaleFactor;
					int y = (height - 70) * scaleFactor;
                    tessellator.startDrawingQuads();
					tessellator.addVertexWithUV(x, y + iconHeight, 150.0D, 0.0D, iconHeight / f1);
					tessellator.addVertexWithUV(x + iconWidth, y + iconHeight, 150.0D, iconWidth / f1, iconHeight / f1);
					tessellator.addVertexWithUV(x + iconWidth, y, 150.0D, iconWidth / f1, 0.0D);
					tessellator.addVertexWithUV(x, y, 150.0D, 0.0D, 0.0D);
		            tessellator.draw();
	            }
	            
	            this.mc.func_147120_f();
	            
	            if(animate)
	            {
		            try
					{
						Thread.currentThread().sleep(33);
					} 
		            catch (InterruptedException e) {}
	            }
	        }
	        /*
            try
            {
                Thread.yield();
            }
            catch (Exception var15)
            {
                ;
            }
            */
        }
    }
    /**
     * Generates unique texture ids for the used resources
     */
    public void startReloadTextures()
    {
    	if(glBackgroundTextureId == -1)
    	{
    		try
			{
				glBackgroundTextureId = TexturesHelper.getUniqueTextureIdFor(mc.getTextureManager(), Gui.optionsBackground);
			} 
    		catch (IOException e)
			{
    			glBackgroundTextureId = -1;
    			e.printStackTrace();
			}
    	}
    	if(glFontTextureId == -1)
    	{
    		try
			{
    			glFontTextureId = TexturesHelper.getUniqueTextureIdFor(mc.getTextureManager(), new ResourceLocation("textures/font/ascii.png"));
			} 
    		catch (IOException e)
			{
    			glFontTextureId = -1;
    			e.printStackTrace();
			}
    	}
    }
    /**
     * Reset unique texture ids for the used resources
     */
    public void endReloadTextures()
    {
    	if(glBackgroundTextureId != -1)
    	{
    		glBackgroundTextureId = -1;
    		TextureUtil.deleteTexture(glBackgroundTextureId);
    	}
    	if(glFontTextureId != -1)
    	{
    		glFontTextureId = -1;
    		TextureUtil.deleteTexture(glFontTextureId);
    	}
    }
    public static class LoadingFontRenderer extends FontRenderer
    {
    	private CustomLoadingScreen parent;
    	
        public LoadingFontRenderer(CustomLoadingScreen parent)
        {
            super(Minecraft.getMinecraft().gameSettings, new ResourceLocation("textures/font/ascii.png"), Minecraft.getMinecraft().getTextureManager(), false);
            this.parent = parent;
            super.onResourceManagerReload(null);
        }

        @Override
        protected void bindTexture(ResourceLocation location)
        {
            if(parent != null && parent.glFontTextureId != -1) 
            	GL11.glBindTexture(GL11.GL_TEXTURE_2D, parent.glFontTextureId);
            else 
            	super.bindTexture(location);
        }
    }
}
