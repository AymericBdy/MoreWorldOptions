package net.mystical.moreworldoptions.client;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.relauncher.ReflectionHelper;
import cpw.mods.fml.relauncher.ReflectionHelper.UnableToAccessFieldException;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.mystical.moreworldoptions.client.gui.GuiIngameMenuWithOptions;
import net.mystical.moreworldoptions.client.gui.GuiSelectWorldWithOptions;
import net.mystical.moreworldoptions.mod.MoreWorldOptions;

@SideOnly(Side.CLIENT)
public class MoreWorldOptionsEventHandlerClient
{
	private static Minecraft mc = Minecraft.getMinecraft();
	
	@SubscribeEvent
	public void onPreDisplayGui(GuiScreenEvent.InitGuiEvent.Pre event)
	{
		if(event.gui instanceof GuiSelectWorld)
		{
			GuiScreen parent;
			try
			{
				parent = ReflectionHelper.getPrivateValue(GuiSelectWorld.class, (GuiSelectWorld) event.gui, "parentScreen");
			}
			catch (UnableToAccessFieldException e)
			{
				MoreWorldOptions.log.info("[MoreWorldOptionsEventHandlerClient] Field 'parentScreen' wasn't found in the vanilla GuiSelectWorld, searching for 'field_146632_a'");
				try
				{
					parent = ReflectionHelper.getPrivateValue(GuiSelectWorld.class, (GuiSelectWorld) event.gui, "field_146632_a");
				}
				catch (UnableToAccessFieldException e2)
				{
					MoreWorldOptions.log.fatal("[MoreWorldOptionsEventHandlerClient] We are unable to access to the parentScreen field of the vanilla GuiSelectWorld, will will create a new GuiMainMenu");
					parent = new GuiMainMenu();
				}
			}
			event.setCanceled(true);
			Minecraft.getMinecraft().displayGuiScreen(new GuiSelectWorldWithOptions(parent));
		}
		else if(event.gui instanceof GuiIngameMenu)
		{
			event.setCanceled(true);
			Minecraft.getMinecraft().displayGuiScreen(new GuiIngameMenuWithOptions());
		}
	}
}
