package net.mystical.moreworldoptions.util.plugins;

import java.io.File;
import java.util.Calendar;
import java.util.Map;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.Logger;

import com.google.common.collect.Maps;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;

/**
 * This plugin permits to have a log file and it offer multiples possibilities to log yours messages
 * 
 * This code is owned by Aymericred Productions, for modify and copy this mod, you must read and accept the file "Terms And Conditions" ("Droits" FR Version).
 * 
 * @author ©2015 AymericRed Productions (aymericred@gmail.com)
 * @coder Aymericred.
 * @version 1.2
 */
public class LogSystem
{
	private LogSystemWriter writer;
	
	public final String name;
	
	private boolean debug;
	private Map<Integer, String> addons = Maps.newHashMap();
	protected Logger log;

	public LogSystem(FMLPreInitializationEvent event, String logName, boolean debug)
	{
		this.name = logName;
		this.debug = debug;
		this.log = event.getModLog();
		this.writer = new LogSystemWriter(logName);
		
		if(log instanceof org.apache.logging.log4j.core.Logger)
		{
			((org.apache.logging.log4j.core.Logger)log).setLevel(Level.ALL);
		}
		else
		{
			fatal("[LogSystem] Couldn't get the Logger object of this logger ! Some debug messages will be not logged ! Log : " + log.getClass());
		}

		initializeAddOn("LogSystem", 0);
		deleteLogFile();
		debug("Loading of LogSystem V1.2", 0);
	}
	
	public void info(Object str)
	{
		info(str, -1);
	}
	
	public void info(Object str, int addon)
	{
		log.info(getAddonPrefix(addon) + str);
		fileWrite(getAddonPrefix(addon) + "[INFO] " + str);
	}

	public void debug(Object str)
	{
		debug(str, -1);
	}
	
	public void debug(Object str, int addon)
	{
		if(this.debug)
		{
			log.debug(getAddonPrefix(addon) + str);
		}
		fileWrite(getAddonPrefix(addon) + "[DEBUG] " + str);
	}
	
	public void toChat(Object str)
	{
		toChat(str, -1);
	}
	
	public void toChat(Object str, int Addon)
	{
		log.info(getAddonPrefix(Addon) + "[CHAT] " + str);
		fileWrite(getAddonPrefix(Addon) + "[CHAT] " + str);
		
		if(FMLCommonHandler.instance().getEffectiveSide().isServer())
		{
			try 
			{
				if(str instanceof IChatComponent) MinecraftServer.getServer().getConfigurationManager().sendChatMsg((IChatComponent) str);
				else MinecraftServer.getServer().getConfigurationManager().sendChatMsg(new ChatComponentText("[" + name + "] " + str));
			} 
			catch (Exception e) 
			{
				this.err("[SERVER] Unable to write in the chat (called by : " + e.getStackTrace()[1] + e.getStackTrace()[2] + e.getStackTrace()[3] + ")", 0);
			}
		}
		else if(FMLCommonHandler.instance().getEffectiveSide().isClient())
		{
			try 
			{
				if(str instanceof IChatComponent) Minecraft.getMinecraft().thePlayer.addChatMessage((IChatComponent) str);
				else Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText("[" + name + "] " + str));
			}
			catch (Exception e)
			{
				this.err("[CLIENT] Unable to write the message in the chat (called by : " + e.getStackTrace()[1] + e.getStackTrace()[2] + e.getStackTrace()[3] + ")", 0);
			}
		}
	}

	public void err(Object str)
	{
		err(str, -1);
	}
	
	public void err(Object str, int addon)
	{
		log.error(getAddonPrefix(addon) + "[ERROR] " + str);
		fileWrite(getAddonPrefix(addon) + "[ERROR] " + str);
	}	
	
	public void fatal(Object str)
	{
		fatal(str, -1);
	}
	
	public void fatal(Object str, int addon)
	{
		log.fatal("[FATAL] An fatal error occured in " + getAddon(addon) + ", please see the report under this message");
		log.fatal("[FATAL-REPORT] " + str);
		
		fileWrite("[FATAL] An fatal error occured in " + getAddon(addon) + ", please see the report under this message");
		fileWrite("[FATAL-REPORT] " + str);
	}
	
	/**
	 * @param debug If the log must be in debug mode
	 */
	public void setDebug(boolean debug)
	{
		this.debug = debug;
	}
	
	/**
	 * Adds the specified string to the message queue
	 * @param str The string
	 */
	public void fileWrite(String str)
	{
		writer.enqueue(str);
	}

	/**
	 * Deletes the log file
	 */
	public void deleteLogFile()
	{
		String separator = System.getProperty("file.separator");
		File logFile= new File("logs" + separator + name + "-log.txt");
		if(logFile.exists())
		{
			logFile.delete();
			debug("File '" + name + "-log.txt' deleted with success !", 0);
		}
		else
		{
			err("Cannot delete the file '" + name + "-log.txt' : the file not exists ! ", 0);
		}
	}
	
	/**
	 * @return The writer instance
	 */
	public LogSystemWriter getLogWriter() 
	{
		return this.writer;
	}

	/**
	 * Loads an special sub-log of this with special name
	 * 
	 * @param Name of the addon
	 * @param Id of the addon
	 * 
	 * @return False if already loaded
	 * 
	 * For MoreWorldOptions :
	 * 
	 * 0 = LogSystem V
	 * 1 = CertificateValidator V
	 * 2 = StandardUpdater V
	 * 3 = Client_Patcher V
	 * 5 = NetworkManager V
	 * 6 = ScreenShotSaver V
	 * 7 = TvScreenImgSynchronizer V
	 * 9 = GenZoneAPI V
	 * 11 = DataLoader V
	 * 
	 * For NetworkManager :
	 * 
	 * 0 = LogSystem V
	 */
	public boolean initializeAddOn(String name, int id)
	{
		if(!this.isAddonLoaded(id))
		{
			addons.put(id, name);
			this.debug("Addon has been added ! Name = " + name + ", Id : " + id, 0);
			return true;
		}
		return false;
	}
	
	/**
	 * @param id The addon id
	 * @return True if the addon is loaded
	 */
	public boolean isAddonLoaded(int id)
	{
		return addons.containsKey(id);
	}
	
	/**
	 * @param id The addon id
	 * @return The name of the addon passed in parameter
	 */
	protected String getAddon(int id)
	{
		//The default log
		if(id == -1) return name;
		
		String result = addons.get(id);
		if(result == null)
		{
			throw new IllegalArgumentException("[LogSystem] Unregistered addon : " + id);
		}
		return result;
	}
	
	public String getAddonPrefix(int addon)
	{
		//The default log
		if(addon == -1) return "";
		return "[" + getAddon(addon) + "]";
	}
	
	protected static String getDatePrefix()
	{
		Calendar calendar = Calendar.getInstance();
		return "[" + formatForTimeNumbers(calendar.get(Calendar.HOUR_OF_DAY)) + ":" + formatForTimeNumbers(calendar.get(Calendar.MINUTE)) + " " + formatForTimeNumbers(calendar.get(Calendar.SECOND)) + "] ";
	}
	
	protected static String getThreadPrefix()
	{
		return "[" + Thread.currentThread().getName() + "] ";
	}
	
	protected static Object formatForTimeNumbers(int data)
	{
		if(data < 10) return "0" + data;
		return data;
	}
	
	public static String formatPosition(double x, double y, double z)
	{
		return "The x = '" + x + "' The y = '" + y + "' The z = '" + z + "' ";
	}
}
