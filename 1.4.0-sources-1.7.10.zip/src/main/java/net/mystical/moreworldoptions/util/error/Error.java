package net.mystical.moreworldoptions.util.error;

import java.util.Random;

import cpw.mods.fml.client.FMLClientHandler;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.FMLLog;
import cpw.mods.fml.common.Loader;
import cpw.mods.fml.common.ObfuscationReflectionHelper;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.resources.I18n;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraftforge.common.MinecraftForge;
import net.mystical.moreworldoptions.mod.MoreWorldOptions;
import net.mystical.moreworldoptions.util.Properties;

public class Error
{
	private String code;
	private EnumErrorCategory category;
	private String description;
	private ErrorAction action;
	
	public Error(String code, EnumErrorCategory category, String description, ErrorAction action)
	{
		this.code = code;
		this.category = category;
		this.description = description;
		this.action = action;
	}
	
	@SuppressWarnings("unused")
	public String generateError(String location, AdditionnalErrorInfo additionalInfo)
	{
		ReportBuilder err = new ReportBuilder();
		Throwable e = additionalInfo.getException();
		
		//Apply crash modifiers before all, for log correct information
		ErrorAction.CrashCode cod = action.getCrashCode();
		cod = additionalInfo.getCrashCode(cod);
		action.modifyCrashCode(cod);
		
		boolean mustReport = action.reportToTheAuthor();
		boolean reportSupported = action.isReportAvaible();
		
		//Build the message
		err.line();
		err.line("=================================== " + Properties.modname.toUpperCase() + " HAS THROWN AN ERROR ! ===================================");
		err.line("The modder says : '" + getRandomMessage() + "'");
		
		err.categoryTitle("Details");
		
		err.line("Error code : " + code);
		err.line("Category of this error : " + category.getDescription());
		err.line("Description of this error : " + description);
		err.line("Precisions (location) : " + location);
		
		err.categoryTitle("Additionnal info");
		err.line(additionalInfo.getAdditionnalInfo());
		
		err.subCategoryTitle("Exception");
		if(e != null)
		{
			err.line(e);
		}
		else
		{
			err.line("No exception message");
		}
		err.subCategoryTitle("StackTrace");
		if(e != null && e.getStackTrace().length > 0)
		{
			StackTraceElement[] el = e.getStackTrace();
			for(int i = 0 ; i < el.length ; i++)
			{
				err.line(el[i]);
			}
		}
		else
		{
			err.line("No exception elements");
		}
		
		err.categoryTitle("Environnement details");

		err.line("Minecraft details : ");
		err.append("Client application" + " running in version " + MinecraftForge.MC_VERSION);
		err.subCategoryTitle("Forge info");
		err.line(Loader.instance().getCrashInformation());
		err.line();
		
		err.line("System details : Running on " + System.getProperty("os.name") + " " + System.getProperty("os.arch") + " (version " + System.getProperty("os.version") + ") with java " + System.getProperty("java.version"));
		err.line("Current mod version : " + Properties.modversion + ", build : " + Properties.buildNumber);
		err.line("Current side : " + this.getSide().name());
		
		err.categoryTitle("Consequences");
		err.line(action.getCrashCode().getMessage());
		err.line();
		
		if(mustReport)
		{
			if(reportSupported) err.line("Starting the BugReporter to report the bug");
			else err.line("The BugReporter isn't supported on this mod/minecraft version, please report the bug to the author");
		}
		else
		{
			err.line("The author knows that this bug can occurs, report-it only if necessary !");
		}
		
		err.line("Thank you for your attention");
		err.line("========================================== END OF REPORT ===========================================");
		
		MoreWorldOptions.log.fatal(err);
		
		//Remove all potential errored things
		additionalInfo.removeAllErroredIfPossible();
		
		//Post chat message
		if(action.postChatMessage())
		{
			MoreWorldOptions.log.toChat("An fatal error occured in the mod, see the log for details (ERROR CODE : " + code + ")");
			if(action.getCrashCode().shutdown(this.getSide()))
			{
				MoreWorldOptions.log.toChat("[WARN] This bug is too big, Minecraft will crash (ERROR CODE : " + code + ")");
			}
			else
			{
				MoreWorldOptions.log.toChat("[INFO] This is an unimportant bug, Minecraft will continue to run, but some bugs can occurs (ERROR CODE : " + code + ")");
			}
		}
		
		//Report the bug
		if(mustReport && reportSupported)
		{
			MoreWorldOptions.log.info("Opening EBR...");
			String exept = "NoReferenced";
    		if(e != null)
    		{
    			exept = e.getMessage();
    		}
    		String s = System.getProperty("file.separator");
    		String[] args = new String[] {System.getProperty("java.home") + s + "bin"  + s + "java.exe", "-jar",
    			System.getProperty("user.dir")  + s + "mods" + s + "MoreWorldOptions" + s + "EnergyBugReporter.jar",
    			"MoreWorldOptions", Properties.modFileName, description, location, exept
    		};
    		try 
    		{
				Process p = Runtime.getRuntime().exec(args);
	    		MoreWorldOptions.log.err("THE BUG WAS REPORTED BY EBR, DON'T REPORT IT OWN !");
    		} 
    		catch (Exception e1) 
    		{
    			MoreWorldOptions.log.fatal("Exception while reporting the bug, please report the bug manually");
				e1.printStackTrace();
			}
		}
		
		//Crash
		if(action.getCrashCode().shutdown(this.getSide()))
		{
			ErrorsManager.hasCrashed = true;
			MoreWorldOptions.log.info("Starting crash section...");
			MoreWorldOptions.log.info("Waiting for LogWriter to stop...");
			MoreWorldOptions.log.getLogWriter().stopTickerThread();
			
			int maxTime = 0;
			while(!MoreWorldOptions.log.getLogWriter().isStopped() && maxTime < 100)
			{
				try 
				{
					Thread.currentThread().sleep(100);
				}
				catch (InterruptedException e1) 
				{
					MoreWorldOptions.log.fatal("Exception while waiting for writer stop");
					e1.printStackTrace();
				}
				maxTime++;
			}
			String modBalise = "[" + Properties.modname + "] ";
			FMLLog.info(modBalise + "Succesfully stopped the LogWriter, now crash Minecraft");
			
			if(true) //Client
			{
				if(net.minecraft.client.Minecraft.getMinecraft().theWorld != null)
				{
					FMLLog.info(modBalise + "Unloading world");
					this.forceUnloadWorld(modBalise);
				}
				FMLLog.info(modBalise + "Stopping the game... Closing application...");
				FMLCommonHandler.instance().handleExit(0);
			}
			else if(false) //Server
			{
				FMLLog.info(modBalise + "Stopping mc server");
				
				//From MinecraftServer.run()
				FMLCommonHandler.instance().handleServerStopping();
                FMLCommonHandler.instance().expectServerStopped(); // has to come before finalTick to avoid race conditions
                MinecraftServer.getServer().stopServer();
                FMLCommonHandler.instance().handleServerStopped();
                
                Class cl = MinecraftServer.getServer().getClass().getSuperclass();
                /*
                Field fd = cl.getDeclaredField("serverStopped");
				fd.setAccessible(true); //The field is "protected"
				fd.setBoolean(MinecraftServer.getServer(), true);
				*/
                ObfuscationReflectionHelper.setPrivateValue(cl, MinecraftServer.getServer(), true, "serverStopped");
                
				FMLLog.info(modBalise + "Stopping the game...");
				FMLCommonHandler.instance().handleExit(0);
			}
		}
		return err.toString();
	}
	
	public Side getSide()
	{
		return Side.CLIENT;
		//return FMLCommonHandler.instance().getEffectiveSide();
	}

	public String getCode()
	{
		return this.code;
	}
	
	public enum EnumErrorCategory
	{
		SECURITY(0, "SECURITY : If an file is lost, corrupted, or an unkown call by other mod"),
		REGISTRY(1, "REGISTRY : If the error occured during registry"),
		RUNNING(2, "RUNNING : If the error occured during running Minecraft"),
		INCOMPATIBILITY(3, "INCOMPATIBILITY : If the mod have an problem with one other installer mod, or with the minecraft version"),
		NETWORK(4, "NETWORK : If an error occured during sending packets"),
		LOSTBLOCK_ENTITY_TILEENTITY(5, "LOSTBLOCK_ENTITY_TILEENTITY : If an block/item/tile_entity/entity is not at its place or if an worldObj is null, can be caused by other mods"),
		BAD_MODDER(6, "BAD_MODDER : The modder don't know how to make mods");
		
		private int id;
		private String description;
		
		private EnumErrorCategory(int id, String description)
		{
			this.id = id;
			this.description = description;
		}
		
		public int getId()
		{
			return this.id;
		}
		
		public String getDescription()
		{
			return this.description;
		}
	}
	
	@SideOnly(Side.CLIENT)
	private void forceUnloadWorld(String modBalise)
	{
		Minecraft mc = Minecraft.getMinecraft();
		WorldClient theWorld = mc.theWorld;
		mc.theWorld = null;
        if (theWorld != null) net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(new net.minecraftforge.event.world.WorldEvent.Unload(theWorld));

        NetHandlerPlayClient nethandlerplayclient = mc.getNetHandler();
        if (nethandlerplayclient != null)
        {
            nethandlerplayclient.cleanup();
        }
        
        MinecraftServer srv = MinecraftServer.getServer();
        if (srv instanceof IntegratedServer)
        {
        	IntegratedServer theIntegratedServer = (IntegratedServer) srv;
            
            theIntegratedServer.initiateShutdown();
            if (mc.loadingScreen != null)
            {
            	try
            	{
            		mc.loadingScreen.resetProgresAndWorkingMessage(I18n.format("forge.client.shutdown.internal"));
            	}
            	catch(Exception e)
            	{
					//Errors can occurs if in other thread than the client thread (eg : Netty client)
            		FMLLog.warning(modBalise + "Error while unloading the world : " + e.getLocalizedMessage());
            	}
            }
            while (!theIntegratedServer.isServerStopped())
            {
                try
                {
                    Thread.sleep(10);
                }
                catch (InterruptedException ie) {}
            }
        }
        else
        {
        	FMLLog.info(modBalise + "" + srv);
        }

        ObfuscationReflectionHelper.setPrivateValue(Minecraft.class, mc, null, "theIntegratedServer");
        //mc.theIntegratedServer = null;
        mc.guiAchievement.func_146257_b();
        mc.entityRenderer.getMapItemRenderer().func_148249_a();

        mc.renderViewEntity = null;
        ObfuscationReflectionHelper.setPrivateValue(Minecraft.class, mc, null, "myNetworkManager");
        //mc.myNetworkManager = null;

        if (mc.loadingScreen != null)
        {
        	try
        	{
        		mc.loadingScreen.resetProgressAndMessage(I18n.format("forge.client.shutdown.internal"));
        		mc.loadingScreen.resetProgresAndWorkingMessage("");
        	}
        	catch(Exception e)
        	{
				//Errors can occurs if in other thread than the client thread (eg : Netty client)
        		FMLLog.warning(modBalise + "Error while unloading the world : " + e.getLocalizedMessage());
        	}
        }

        if (theWorld != null)
        {
            mc.getResourcePackRepository().func_148529_f();
            mc.setServerData((ServerData)null);
            ObfuscationReflectionHelper.setPrivateValue(Minecraft.class, mc, false, "integratedServerIsRunning");
            //mc.integratedServerIsRunning = false;
            FMLClientHandler.instance().handleClientWorldClosing(mc.theWorld);
        }

        mc.getSoundHandler().stopSounds();
        mc.theWorld = null;

        mc.getSaveLoader().flushCache();
        mc.thePlayer = null;

        System.gc();
        ObfuscationReflectionHelper.setPrivateValue(Minecraft.class, mc, 0L, "systemTime");
        //mc.systemTime = 0L;
        
        FMLLog.info(modBalise + "World succesfully unloaded");
	}
	
	public static class ReportBuilder
	{
		private final String ln;
		private String text = "";
		
		public ReportBuilder() {this(System.getProperty("line.separator"));}
		public ReportBuilder(String useLineSeparator) {this.ln = useLineSeparator;}
		
		public void append(Object txt) {append(txt.toString());}
		
		public void append(String txt)
		{
			text += txt.replaceAll("\n\t", ln);
		}
		
		public void line(Object line) {line(line.toString());}
		
		public void line(String line)
		{
			text += line.replaceAll("\n\t", ln) + ln;
		}
		
		public void line()
		{
			text += ln;
		}
		
		public void categoryTitle(String title)
		{
			text += (text.isEmpty() ? "" : ln) + title + " : " + ln;
			for(int i = 0 ; i < title.length() + " : ".length() ; i++) text += "¯";
			text += ln;
		}
		
		public void subCategoryTitle(String title)
		{
			text += ln + title + " : " + ln;
		}

		@Override
		public String toString()
		{
			return text;
		}
	}
	
	private static String[] randomMessages = new String[] {"I forgot something...", "What, you aren't satified ?!?", "I don't konw how it's works...", "Euhhh, f***", "It isn't me, you're pc have 50 years old", "What ? I've pasted this on Mojang ?!?", "Explain me why ?!?", "Choose another modder", "Do you use an modpack ?", "You're favorite youtuber ?", "We are waiting for the 1.10..."};
	
	public static String getRandomMessage()
	{
		Random rand = new Random();
		return randomMessages[rand.nextInt(randomMessages.length -1)];
	}
}