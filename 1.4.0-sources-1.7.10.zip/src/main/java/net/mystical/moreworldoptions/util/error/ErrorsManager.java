package net.mystical.moreworldoptions.util.error;

import java.util.HashMap;
import java.util.Map;

import net.mystical.moreworldoptions.mod.MoreWorldOptions;
import net.mystical.moreworldoptions.util.error.Error.EnumErrorCategory;
import net.mystical.moreworldoptions.util.error.ErrorAction.CrashCode;

public class ErrorsManager
{
	private static Map<String, Error> errors = new HashMap();
	public static boolean hasCrashed;
	
	public static void registerErrors()
	{
		//StandardUpdater
		registerError(new Error("STU&MDFILE_NTFOUND&SRV_WRN", EnumErrorCategory.SECURITY, "Sorry, but we are unable to locate your mod file, please delete it manually (maybe incorrect version nb)", new ErrorAction(ErrorAction.CrashCode.ALL, false, true)));

		//Running (user actions)
		registerError(new Error("RESS_LOAD&WORLD_COPY&PID2", EnumErrorCategory.RUNNING, "An unkown error occured while copying world, you're original world can be corrupted (statistically 0.00001% of chances)", new ErrorAction(ErrorAction.CrashCode.CLIENT_APPLICATION, false, false)));
		registerError(new Error("PACK_LOAD&UNK_ERROR", EnumErrorCategory.RUNNING, "An error occured loading the resources packs for a world", new ErrorAction(CrashCode.NO, false, false)));
		registerError(new Error("MWO&WORLD_INFO&SAVE_ERROR", EnumErrorCategory.BAD_MODDER, "An fatal error occured saving a world", new ErrorAction(CrashCode.NO, false, true)));
		
		//Runnig (Gui)
		registerError(new Error("GUI&SEL_ABSENT&MAIN", EnumErrorCategory.INCOMPATIBILITY, "I did not know why, but the GuiMainMenu of mc wasn't display, cannot display the custom MoreWorldOptions's gui ! (If you have an mod who modify the main screen, do not report it !)", new ErrorAction(ErrorAction.CrashCode.NO, false, false)));
		registerError(new Error("GUI&KEY_INTERPRET&KEYTYPED&ERR", EnumErrorCategory.RUNNING, "An error occured while processing typed key, please report this, more details in additional info", new ErrorAction(ErrorAction.CrashCode.NO, false, true)));
		registerError(new Error("RESS_LOAD&WORLD_LIST_LOADER&TASK", EnumErrorCategory.RUNNING, "An error occured while processing an operation on a save in the WorldListLoader", new ErrorAction(CrashCode.NO, false, true)));
		
		//JVM
		registerError(new Error("EXEC&LSW&RUN", EnumErrorCategory.SECURITY, "An error occured while writing in the log using the future executor, this couldn't be possible ! This can corrupt the printed data", new ErrorAction(ErrorAction.CrashCode.ALL, true, true)));
	}
	
	public static void registerError(Error error)
	{
		errors.put(error.getCode(), error);
	}
	
	public static void thrownPacketError(String packetName, AdditionnalErrorInfo add, boolean report)
	{
		String errorCode = report ? "NET&PACKET_ERR&MOD_ERR&REPORT" : "NET&PACKET_ERR&WORLD_ERR";
		thrownError(errorCode, packetName, add);
	}
	
	public static void thrownError(String errorCode, String location, Exception e)
	{
		thrownError(errorCode, location, AdditionnalErrorInfo.createAddionnalInfo(e));
	}
	
	public static void thrownError(String errorCode, String location, AdditionnalErrorInfo add)
	{
		if(hasCrashed) return;
		if(errors.containsKey(errorCode))
		{
			errors.get(errorCode).generateError(location, add);
		}
		else
		{
			MoreWorldOptions.log.err("=================== FATAL : ===================");
			MoreWorldOptions.log.err("An unregistered error occured : " + errorCode);
			MoreWorldOptions.log.err("Please report this to the mod author !");
			
			Error err = new Error("UNREG_ERR." + errorCode, EnumErrorCategory.RUNNING, "Unregistred error occured (" + errorCode + ")", new ErrorAction(ErrorAction.CrashCode.NO, false, true));
			err.generateError(location, add);
		}
	}

}