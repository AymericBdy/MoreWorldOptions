package net.mystical.moreworldoptions.util.error;

import java.util.ArrayList;
import java.util.List;

import cpw.mods.fml.relauncher.Side;
import net.minecraft.util.ChatComponentText;


public class ErrorAction
{
	/**
	 * This enum resumes all possible cases of crashes
	 * 
	 * @author LordPhantom
	 * 
	 * @see net.MoreWorldOptions.mod.error.Error
	 */
	public static enum CrashCode
	{
		NO(-1, "No shutting down (if you see this, it's an error)"),
		MC_SERVER(0, "Shutting down the server and disconnecting clients", Side.SERVER),
		CLIENT_APPLICATION(1, "Shutting down minecraft application (doesn't stops the server if dedicated)", Side.SERVER, Side.CLIENT),
		ALL(2, "Shutting down server and minecraft application", Side.CLIENT, Side.SERVER);
		
		private int id;
		private String message;
		private List<Side> affectedSides = new ArrayList();
		
		private CrashCode(int id, String message, Side... affectedSides)
		{
			this.id = id;
			this.message = message;
			
			for(Side side : affectedSides)
			{
				this.affectedSides.add(side);
			}
		}
		
		public String getMessage()
		{
			return this.message;
		}
		
		public ChatComponentText getChatMessage()
		{
			return new ChatComponentText(this.message);
		}
		
		@SuppressWarnings("unused")
		public boolean shutdown(Side side)
		{
			if((id == 1) && /*MoreWorldOptions.isDedicatedServer*/false) return false;
			return this.affectedSides.contains(side);
		}
	}

	private ErrorAction.CrashCode crash;
	private boolean chatMp;
	private boolean report;
	
	public ErrorAction(ErrorAction.CrashCode crash, boolean postChatMessage, boolean reportToTheAuthor)
	{
		this.crash = crash;
		this.chatMp = postChatMessage;
		this.report = reportToTheAuthor;
	}
	
	public void modifyCrashCode(ErrorAction.CrashCode nw)
	{
		this.crash = nw;
	}
	
	public ErrorAction.CrashCode getCrashCode()
	{
		return this.crash;
	}
	
	public boolean postChatMessage()
	{
		return this.chatMp;
	}
	
	public boolean reportToTheAuthor()
	{
		return this.report;
	}
	
	/**
	 * @return True if on an client minecraft, else, false
	 */
	public boolean isReportAvaible()
	{
		return false;//!MoreWorldOptions.isDedicatedServer;
	}
}