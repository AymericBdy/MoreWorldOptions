package net.mystical.moreworldoptions.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.google.common.collect.Lists;

import cpw.mods.fml.common.FMLCommonHandler;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.StatCollector;
import net.mystical.moreworldoptions.mod.MoreWorldOptions;

public class MwoUtil
{
	private static String lastLostTranslation = "";
	private static List knowLostTranslations = new ArrayList();
	
	public static int secondsToTicks(int seconds)
	{
		return seconds * 20;
	}
	
    public static int ticksToSeconds(int ticks)
    {
    	return ticks / 20;
    }
    
    /**
     * Thanks to micdodle8 for this method (only the first line)
     * 
     * This functions log all unknown languages the first time they aren't found (don't spam)
     * 
     * @param key : the text to translate
     * @return translation
     */
    public static String translate(String key)
	{
		String result = StatCollector.translateToLocal(key);
		
		//If wans't translated
		if(key.equals(result))
		{
			if(key.equals(lastLostTranslation)) {}
			else if(knowLostTranslations.contains(key)) {}
			else
			{
				MoreWorldOptions.log.err("[TRANSLATION] Lost one translation in language : " + FMLCommonHandler.instance().getCurrentLanguage() + " : " + key);
				
				knowLostTranslations.add(key);
			}
			
			lastLostTranslation = key;
		}
		
		return result;
	}
    
    /**
     * Is empty if =null or =" " or =""
     */
    public static boolean isStringEmpty(String str)
    {
    	return str == null ? true : str.equals("") ? true : str.equals(" ") ? true : false;
    }
    
    /**
     * An easily way to implement colors in the guis
     * Also supports get of random colors of mc/this
     * 
     * @author LordPhantom
     */
    public static enum ColorHelper
    {
    	BLACK(0x000000),
    	BLUE(0x0000ff),
    	BLOODRED(0x850606),
    	BROWN(0x582900),
    	BURNEDORANGE(0xcc5500),
    	CELESTIALBLUE(0x26c4ec),
    	ELECTRICALBLUE(0x2c75ff),
    	ENERGIZEDBLUE(0x2bd3d3),
    	GREEN(0x00ff00),
    	GRASSGREEN(0x3a9d23),
    	CLEARGREEN(0x00ff21),
    	GRAY(0x606060),
    	GUIsGRAY(4210752),
    	IMPERIALGREEN(0x00561b),
    	ORANGE(0xed7f10),
    	RED(0xff0000),
    	STEELGRAY(0xafafaf),
    	TURQUOISEBLUE(0x25fde9),
    	WHITE(0xffffff),
    	YELLOW(0xffff00),
    	PINK(0xff358b);
    	
    	private int colorhexadecimalvalue;
    	
    	private ColorHelper(int hexa)
    	{
    		colorhexadecimalvalue = hexa;
    	}
    	
    	/**
    	 * @return This hexadecimal color value
    	 */
    	public int getValue()
    	{
    		return this.colorhexadecimalvalue;
    	}
    	
		public static ColorHelper getRandomEnergyColor() 
		{
			return getRandomEnergyColor(new Random());
		}
		public static ColorHelper getRandomEnergyColor(Random rand) 
		{
			ColorHelper[] values = ColorHelper.values();
			int max = values.length;
			
			ColorHelper color = values[rand.nextInt(max)];
			
			return color;
		}
    	
		public static EnumChatFormatting getRandomMcColor() 
		{
			return getRandomMcColor(new Random());
		}
		public static EnumChatFormatting getRandomMcColor(Random rand) 
		{
			EnumChatFormatting color = EnumChatFormatting.RESET;
			String clName = null;
			try 
			{
				ArrayList colors = (ArrayList) EnumChatFormatting.getValidValues(true, false);
				int max = colors.size();
				
				clName = (String) colors.get(rand.nextInt(max));
				
				color = EnumChatFormatting.getValueByName(clName);
			}
			catch (ClassCastException e)
			{
				MoreWorldOptions.log.err("Error while getting an random color : " + e.getMessage());
			}
			return color;
		}
    }
    
    /**
     * Get all, private, protected, package and public fields of the specified class and its superclass
     * @param clazz The class
     * @param exclusiveParent The superclass to stop to explore the superclass, put Object.class if you wouldn't use this
     * @return
     */
    public static List<Field> getAllFieldsOf(Class<?> clazz, Class<?> exclusiveParent)
    {
    	List<Field> classFields = Lists.newArrayList(clazz.getDeclaredFields());
    	Class<?> parent = clazz.getSuperclass();
    	if(parent != null && !parent.equals(exclusiveParent))
    	{
    		classFields.addAll(getAllFieldsOf(parent, exclusiveParent));
    	}
    	return classFields;
    }
}