package net.mystical.moreworldoptions.util.plugins;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownHostException;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.PlayerEvent;
import cpw.mods.fml.common.gameevent.TickEvent.ClientTickEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;
import net.mystical.moreworldoptions.client.gui.GuiSelectWorldWithOptions;
import net.mystical.moreworldoptions.util.Properties;

/**
 * This plugin search updates on a page web and if it found update, it will say in the chat
 * You must had your own !!![hébergeur]!!! for the page web
 * 
 * This code is owned by LordPhantom Productions, for modify and copy this mod, you must read and accept the file "Terms And Conditions" ("Droits" FR Version).
 * 
 * @author ©2015 LordPhantom Productions (aymericb5@gmail.com)
 * @coder LordPhantom.
 * @version 1.0
 *
 */
public class StandardUpdater 
{
	/** Latest avaible version */
	private static String newestVersion;
	
	/** Latest version's build number */
	private static int buildNumber;
	
	/** Latest version's Minecraft version */
	private static String mcVersion;
	
	/** The non-formated url that contains downloads of the mod with $mc_version as mc version and $file_name as file name */
	private static String urlFormat;

	/** Message to display for update */
	public static ChatComponentText updateStatus = null;
	/** Little verion "changelog" */
	public static String inThisVersion = "NULL";

	/** If should display a message */
	public static boolean show = false;

	/** If should check updates */
	public static boolean check = true;
	
	/** If should download and install updates */
	public static boolean mustDownload = false; //TODO add option in the config
	
	/** Installation thread */
	private static Thread t;
	
	/**
	 * -1 = no download
	 * 1 = finishedDownload
	 * other = downloading
	 * -51 = user is deleting the old mod
	 */
	public static int isDownloading;
	
	private static LogSystem log;

	/**
	 * StandardUpdater initialization
	 */
	public static void init(String currentVersion, String searchUrl, LogSystem modLog) 
	{	
		log = modLog;
		if(!log.isAddonLoaded(2)) log.initializeAddOn("StandardUpdater", 2);
		log.debug("Starting StandardUpdater V1.0", 2);

		if(check)
		{
			getNewestVersion(searchUrl);
			if(newestVersion != null) 
			{
				if(newestVersion.equalsIgnoreCase("McVeAbs"))
					return;
				boolean isGoodMc = false;
				for(int i = 0 ; i < Properties.supportedMcVersions.length ; i++)
				{
					if (Properties.supportedMcVersions[i].equalsIgnoreCase(mcVersion))
					{
						isGoodMc = true;
					}
				}
				log.info(newestVersion + " for mc " + mcVersion + " in build " + buildNumber, 2);
				if(newestVersion.equalsIgnoreCase(currentVersion) && isGoodMc) 
				{
					log.info("Mod is up to date !", 2);
					return;
				}
				if(!isGoodMc)
				{
					log.info("New version avaible for mc " + mcVersion);
					show = true;
					updateStatus = toColoredChatComponent("Update avaible for Mc version " + mcVersion, EnumChatFormatting.AQUA, true, false);
				}
				else if(!newestVersion.equalsIgnoreCase(currentVersion))
				{
					show = true;
					log.info("New update is avaible: " + newestVersion + " (current version: " + currentVersion + ")");
					if(!mustDownload)
						updateStatus = toColoredChatComponent("Update avaible: " + newestVersion + " (current version: " + currentVersion + ")"/*. Please active the auto-install option."*/, EnumChatFormatting.RED, true, false);
					else installNewVersion(false, searchUrl);
				}
			}
			else
			{
				show = false; //Changed for Mwo
				updateStatus = toColoredChatComponent("Connection failed, cannot search updates, please check your internet connection !", EnumChatFormatting.RED, true, false);
				log.err("Connection failed, cannot search updates, please check your internet connection ! [CODE 005]", 2);
			}
		}
		else
		{
			log.err("The 'search updates' option isn't enabled", 2);
		}
	}

	/**
	 * Se connecte à Internet et vérifie la version
	 */
	private static void getNewestVersion(String searchUrl) 
	{	
		try 
		{
			URL url = new URL(searchUrl);
			
			InputStream stream = url.openStream();
			JsonParser parser = new JsonParser();
			JsonElement json = parser.parse(new InputStreamReader(stream, "UTF8"));
			JsonObject obj = json.getAsJsonObject();
			mcVersion = obj.get("Latest").getAsString();
			urlFormat = obj.get("UrlFormat").getAsString();
			JsonElement mcElement = obj.get(Properties.supportedMcVersions[0]);
			if(mcElement != null)
			{
				JsonObject mc = mcElement.getAsJsonObject();
				newestVersion = mc.get("FileName").getAsString();
				buildNumber = mc.get("Build").getAsInt();
				inThisVersion = mc.get("Adds").getAsString();
			}
			else newestVersion = "McVeAbs";
			
			stream.close();
		}
		catch(UnknownHostException e)
		{
			log.err("Connection failed, cannot search updates ! [CODE 002] [Host cannot be resolved]", 2);
			log.err("Probably you are in offline mode.", 2);
		}
		catch(IOException ex)
		{
			log.err("Connection failed, cannot search updates ! [CODE 004] [IO exception : " + ex.toString() + "]", 2);
			ex.printStackTrace();
			newestVersion = null;
		}
		catch(SecurityException ex) //Exception while changing the mod SHA1 finger print
		{
			throw ex;
		}
		catch(Exception e)
		{
			log.err("Connection failed, cannot search updates ! [CODE 006] [Unknow exception : " + e.toString() + "]", 2);
			e.printStackTrace();
			newestVersion = null;
		}
	}
	
	public static void installNewVersion(boolean isComand, String url)
	{
		log.debug("Preparing installation of the mod...", 2);
		updateStatus = toColoredChatComponent("Downlading latest version please wait...", EnumChatFormatting.GOLD, false, true);
		
		if(isComand)
		{
			log.toChat("Version isn't checked, searching for the latest");
			init(Properties.modFileName, url, log);
			if(mustDownload) return;//Auto-install option
		}
		t = new Thread(new InstallThread());
		t.setName(Properties.modname + "InstallationThread");
		t.start();
	}
	
	private static class InstallThread implements Runnable
	{
		@Override
		public void run()
		{
			log.info("Starting installation of the new stable version of MoreWorldOptions", 2);
			if(downloadFile(urlFormat.replace("$mc_version", mcVersion).replace("$file_name", newestVersion), newestVersion))
			{
				/*
				File old = new File("mods" + System.getProperty("file.separator") + Properties.modFileName + ".jar");
				if(old.exists()/* && mcVersion.equalsIgnoreCase(Properties.supportedMcVersions[0]))
				{
					try
					{
						ResourcesHelper.deleteJarOnExit(old);
					}
					catch (IOException e)
					{
						log.fatal("Error deleting old file " + e.toString() + ", you'll must delete it manually !...", 2);
						ErrorsManager.thrownError("STU&MDFILE_NTFOUND&SRV_WRN", "StandardUpdater.deleteOld", e);
					}
				}
				else if(!old.exists())
				{
					ErrorsManager.thrownError("STU&MDFILE_NTFOUND&SRV_WRN", "StandardUpdater.deleteOld", new FileNotFoundException(old.getAbsolutePath()));
					//ErrorsMessagesList.logRunningError("Sorry, but we are unable to locate your mod file, please delete it manually !", "StandardUpdater(delete old file)", CrashCode.SERVER, true, false, new FileNotFoundException(old.getAbsolutePath()));
				}
				*/
				updateStatus = toColoredChatComponent("New version installed, please delete the old mod then relaunch Minecraft.", EnumChatFormatting.BLUE, false, true);
				isDownloading = 1;
				StandardUpdater.show = true;
				GuiSelectWorldWithOptions.updateButton.displayString = "Open mods folder";
				return;
			}
			updateStatus = toColoredChatComponent("An error occured during the download of the new version", EnumChatFormatting.RED, false, true);
			isDownloading = 0;
			StandardUpdater.show = true;
		}
		
		public static boolean downloadFile(String host, String fileName) 
		{
			InputStream input = null;
			FileOutputStream writeFile = null;
			String fiSep = System.getProperty("file.separator");
			
			log.info("Starting file download : " + host);
			try
			{
				URL url = new URL(host);
				URLConnection connection = url.openConnection();
				int fileLength = connection.getContentLength();
				int readed = 0;
				if (fileLength == -1)
				{
					log.err("Invalid URL or haven't internet connection ! [CODE 001]: " + host);
					return false;
				}
				input = connection.getInputStream();
			//	String fileName = url.getFile().substring(url.getFile().lastIndexOf('/') + 1);
				writeFile = new FileOutputStream("mods" + fiSep + fileName + ".jar");
				byte[] buffer = new byte[1024];
				int read;

				while ((read = input.read(buffer)) > 0)
				{
					writeFile.write(buffer, 0, read);
					readed += read;
					isDownloading = Integer.divideUnsigned(readed * 100, fileLength);
				}
				writeFile.flush();
			}
			catch (IOException e)
			{
				e.printStackTrace();
				return false;
			}
			finally
			{
				try
				{
					if(writeFile != null)
						writeFile.close();
					if(input != null)
						input.close();
					log.info("Finished download, relauch minecraft for use the new version", 2);
				}
				catch (IOException e)
				{
					e.printStackTrace();
					return false;
				}
			}
			return true;
		}
	}
	
	private static ChatComponentText toColoredChatComponent(String text, EnumChatFormatting color, boolean bold, boolean italic)
	{
		//text = "[" + MoreWorldOptions.log.name + "] " + text;
		text = Properties.modname + ": " + text;
		
		ChatComponentText cht = new ChatComponentText(text);
		cht.getChatStyle().setColor(color);
		cht.getChatStyle().setBold(bold);
		cht.getChatStyle().setItalic(italic);
		
		return cht;
	}
	
	//TODO

	
	/**
	 * 
	 * Place this method in a class registered with an event FML, this is for the chat message.
	 * 
	 * Mettre cette méthode dans une classe enregistrée avec un event FML c'est pout mettre un message dans le chat
	 * 
	 */
	@SubscribeEvent
    public void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) 
	{
        if(StandardUpdater.show)
        {	
        	StandardUpdater.show = false;
        	//Ajoute un message si le mod n'est pas à jour
            event.player.addChatMessage(StandardUpdater.updateStatus);
            
            if(!StandardUpdater.inThisVersion.equals("NULL"))
            {
	            event.player.addChatMessage(new ChatComponentText("In this versions : "));
	            event.player.addChatMessage(new ChatComponentText(StandardUpdater.inThisVersion));
            }
        }
    }
	
	@SubscribeEvent
	public synchronized void onTick(ClientTickEvent event)
	{
		if(event.side.isServer())
		{
			return;
		}
		//System.out.println("Ticking..." + isDownloading);
		if(isDownloading > -1)
		{
			if(isDownloading == 1 && StandardUpdater.show && Minecraft.getMinecraft().theWorld != null)
			{
				//Ajoute un message si le mod n'est pas à jour
	            Minecraft.getMinecraft().thePlayer.addChatMessage(StandardUpdater.updateStatus);
	            
	            if(!StandardUpdater.inThisVersion.equals("NULL"))
	            {
	            	Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText("In this versions : "));
	            	Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText(StandardUpdater.inThisVersion));
	            }
	            isDownloading = 0;
	            StandardUpdater.show = false;
			}
			else if(isDownloading > 1)
			{
				//System.out.println("Ticking..." + isDownloading);
				ChatComponentText text = new ChatComponentText("Downloading : " + isDownloading + "%");
	    		text.getChatStyle().setColor(EnumChatFormatting.DARK_RED);
	    		text.getChatStyle().setItalic(true);
	    		text.getChatStyle().setBold(true);
	    		
				Minecraft.getMinecraft().ingameGUI.func_110326_a(text.getFormattedText(), false);
			}
		}
	}
	
	/**
	 * Changelog (since 0.4)
	 * 
	 * 0.4 : 
	 * - Added chat message "inThisVerions"
	 * 
	 * 0.5 : 
	 * - Added download percentage drawing
	 * 
	 * 0.6 :
	 * - Added toColoredChatComponent() function and colored messages
	 * 
	 * 0.7 :
	 * - Install from an command : always search the latest then install
	 * - Correction of bugs with colored messages
	 * - Correction of bug with "inThisVersion" message
	 * 
	 * 0.8 :
	 * - Added the name of the mod in chat messages
	 * 
	 * 0.9 :
	 * - All messages are in English
	 * 
	 * 1.0 :
	 * - Standard LogSystem support
	 */
}