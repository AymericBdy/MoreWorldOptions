package net.mystical.moreworldoptions.util;

import net.minecraft.world.storage.SaveFormatComparator;
import net.minecraft.world.storage.WorldInfo;

public class WorldSaveFormatComparatorCompressable extends SaveFormatComparator
{
	private final boolean isCompressed;
	
	public WorldSaveFormatComparatorCompressable(String fileNameIn, WorldInfo infoIn, long sizeOnDisk, boolean requiresConversionIn, boolean compressed)
	{
		super(fileNameIn, infoIn.getWorldName(), infoIn.getLastTimePlayed(), sizeOnDisk, infoIn.getGameType(), requiresConversionIn, infoIn.isHardcoreModeEnabled(), infoIn.areCommandsAllowed());
		this.isCompressed = compressed;
	}
	
	@Override
	public int compareTo(SaveFormatComparator toCompare)
	{
		if(toCompare instanceof WorldSaveFormatComparatorCompressable)
		{
			if(((WorldSaveFormatComparatorCompressable)toCompare).isCompressed() == this.isCompressed())
				return super.compareTo(toCompare);
			else if(isCompressed())
				return 1;
			else
				return -1;
		}
		return super.compareTo(toCompare);
	}
	
	public boolean isCompressed()
	{
		return isCompressed;
	}
}
